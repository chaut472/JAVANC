-- Xóa các bảng nếu chúng đã tồn tại
IF OBJECT_ID('ChiTietHoaDon', 'U') IS NOT NULL
    DROP TABLE ChiTietHoaDon;

IF OBJECT_ID('ChiTietNhapHang', 'U') IS NOT NULL
    DROP TABLE ChiTietNhapHang;

IF OBJECT_ID('HoaDon', 'U') IS NOT NULL
    DROP TABLE HoaDon;

IF OBJECT_ID('NhapHang', 'U') IS NOT NULL
    DROP TABLE NhapHang;

IF OBJECT_ID('Thuoc', 'U') IS NOT NULL
    DROP TABLE Thuoc;

IF OBJECT_ID('NhaSanXuat', 'U') IS NOT NULL
    DROP TABLE NhaSanXuat;

IF OBJECT_ID('KhachHang', 'U') IS NOT NULL
    DROP TABLE KhachHang;

-- Bảng NhaSanXuat
CREATE TABLE NhaSanXuat (
    maNhaSanXuat char(10) PRIMARY KEY,
    tenNhaSanXuat NVARCHAR(100),
    diaChi NVARCHAR(200),
    SDT VARCHAR(15)
);

-- Bảng Thuoc
CREATE TABLE Thuoc (
    maThuoc char(10) PRIMARY KEY,
    tenThuoc NVARCHAR(100),
    GiaBan DECIMAL(18,2),
    soLuongTonKho INT,
    ngaySanXuat DATE,
    hanSuDung int,
    linkAnh VARCHAR(100),
    maNhaSanXuat char(10),
    donViTinh NVARCHAR(50),
    XuatXu NVARCHAR(100),
    loaiThuoc nvarchar(50),
    FOREIGN KEY (maNhaSanXuat) REFERENCES NhaSanXuat(maNhaSanXuat)
);

-- Bảng KhachHang
CREATE TABLE KhachHang (
    maKhachHang char(10) PRIMARY KEY,
    tenKhachHang NVARCHAR(100),
    diaChi NVARCHAR(200),
    tenDangNhap NVARCHAR(50),
    matKhau NVARCHAR(100),
    soDienThoai varchar(10),
    ngaySinh date,
    email VARCHAR(50),
    isAdmin bit
);

-- Bảng HoaDon
CREATE TABLE HoaDon (
    maHD char(10) PRIMARY KEY,
    ngayTaoHoaDon DATE,
    maKH char(10),
    diaChiDatHang NVARCHAR(200),
    diaChiGiaoHang NVARCHAR(200),
    FOREIGN KEY (maKH) REFERENCES KhachHang(maKhachHang)
);

-- Bảng NhapHang
CREATE TABLE NhapHang (
    maNhapHang char(10) PRIMARY KEY,
    ngayNhap DATE
);

-- Bảng ChiTietNhapHang
CREATE TABLE ChiTietNhapHang (
    maNhapHang char(10),
    maThuoc char(10),
    soLuong INT,
    giaNhap DECIMAL(18,2),
    PRIMARY KEY (maNhapHang, maThuoc),
    FOREIGN KEY (maNhapHang) REFERENCES NhapHang(maNhapHang) ON DELETE NO ACTION,
    FOREIGN KEY (maThuoc) REFERENCES Thuoc(maThuoc) ON DELETE NO ACTION
);

-- Bảng ChiTietHoaDon
CREATE TABLE ChiTietHoaDon (
    maHoaDon char(10),
    maThuoc char(10),
    soLuong INT,
    PRIMARY KEY (maHoaDon, maThuoc),
    FOREIGN KEY (maHoaDon) REFERENCES HoaDon(maHD) ON DELETE NO ACTION,
    FOREIGN KEY (maThuoc) REFERENCES Thuoc(maThuoc) ON DELETE NO ACTION
);

-- Thêm dữ liệu mẫu
INSERT INTO NhaSanXuat VALUES('NSX001', N'Công ty Dược phẩm Hà Nội', N'Hà Nội', '0987654321');
INSERT INTO NhaSanXuat VALUES('NSX002', N'Công ty Dược phẩm TP.HCM', N'TP.HCM', '0123456789');

-- Thêm khách hàng admin
INSERT INTO KhachHang VALUES('KH001', N'Admin', N'TP.HCM', 'admin', 'admin', '0123456789', '1985-05-05', 'admin@pharmacy.com', 1);

-- Hiển thị thông báo hoàn thành
SELECT 'Tất cả các bảng đã được tạo thành công!' AS [Thông báo]; 