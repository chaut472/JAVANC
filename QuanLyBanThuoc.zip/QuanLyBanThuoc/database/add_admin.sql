-- Xóa user admin cũ nếu có
IF EXISTS (SELECT * FROM KhachHang WHERE tenDangNhap = 'admin')
    DELETE FROM KhachHang WHERE tenDangNhap = 'admin';

-- Thêm tài khoản admin mới
INSERT INTO KhachHang 
    (maKhachHang, tenKhachHang, diaChi, tenDangNhap, matKhau, soDienThoai, ngaySinh, email, isAdmin) 
VALUES 
    ('KH001', N'Admin', N'TP.HCM', 'admin', 'admin', '0123456789', '1985-05-05', 'admin@pharmacy.com', 1);

-- Kiểm tra tài khoản đã thêm
SELECT * FROM KhachHang WHERE tenDangNhap = 'admin'; 