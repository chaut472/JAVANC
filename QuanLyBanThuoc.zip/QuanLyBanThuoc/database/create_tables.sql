-- Tạo cơ sở dữ liệu QUANLY_QUAYTHUOC (bỏ qua nếu đã tồn tại)
-- CREATE DATABASE QUANLY_QUAYTHUOC;
-- GO
-- USE QUANLY_QUAYTHUOC;
-- GO

-- Bảng NhaSanXuat
CREATE TABLE NhaSanXuat (
    maNhaSanXuat char(10) PRIMARY KEY,
    tenNhaSanXuat NVARCHAR(100),
    diaChi NVARCHAR(200),
    SDT VARCHAR(15)
);

-- Bảng Thuoc
CREATE TABLE Thuoc (
    maThuoc char(10) PRIMARY KEY,
    tenThuoc NVARCHAR(100),
    GiaBan DECIMAL(18,2),
    soLuongTonKho INT,
    ngaySanXuat DATE,
    hanSuDung int,
    linkAnh VARCHAR(100),
    maNhaSanXuat char(10),
    donViTinh NVARCHAR(50),
    XuatXu NVARCHAR(100),
    loaiThuoc nvarchar(50),
    FOREIGN KEY (maNhaSanXuat) REFERENCES NhaSanXuat(maNhaSanXuat)
);

-- Bảng KhachHang
CREATE TABLE KhachHang (
    maKhachHang char(10) PRIMARY KEY,
    tenKhachHang NVARCHAR(100),
    diaChi NVARCHAR(200),
    tenDangNhap NVARCHAR(50),
    matKhau NVARCHAR(100),
    soDienThoai varchar(10),
    ngaySinh date,
    email VARCHAR(50),
    isAdmin bit
);

-- Bảng HoaDon
CREATE TABLE HoaDon (
    maHD char(10) PRIMARY KEY,
    ngayTaoHoaDon DATE,
    maKH char(10),
    diaChiDatHang NVARCHAR(200),
    diaChiGiaoHang NVARCHAR(200),
    FOREIGN KEY (maKH) REFERENCES KhachHang(maKhachHang)
);

-- Bảng NhapHang
CREATE TABLE NhapHang (
    maNhapHang char(10) PRIMARY KEY,
    ngayNhap DATE
);

-- Bảng ChiTietNhapHang
CREATE TABLE ChiTietNhapHang (
    maNhapHang char(10),
    maThuoc char(10),
    soLuong INT,
    giaNhap DECIMAL(18,2),
    PRIMARY KEY (maNhapHang, maThuoc),
    FOREIGN KEY (maNhapHang) REFERENCES NhapHang(maNhapHang) ON DELETE NO ACTION,
    FOREIGN KEY (maThuoc) REFERENCES Thuoc(maThuoc) ON DELETE NO ACTION
);

-- Bảng ChiTietHoaDon
CREATE TABLE ChiTietHoaDon (
    maHoaDon char(10),
    maThuoc char(10),
    soLuong INT,
    PRIMARY KEY (maHoaDon, maThuoc),
    FOREIGN KEY (maHoaDon) REFERENCES HoaDon(maHD) ON DELETE NO ACTION,
    FOREIGN KEY (maThuoc) REFERENCES Thuoc(maThuoc) ON DELETE NO ACTION
);

-- Thêm một số dữ liệu mẫu (bỏ comment nếu muốn thêm)
/*
-- Thêm nhà sản xuất
INSERT INTO NhaSanXuat VALUES('NSX001', N'Công ty Dược phẩm Hà Nội', N'Hà Nội', '0987654321');
INSERT INTO NhaSanXuat VALUES('NSX002', N'Công ty Dược phẩm TP.HCM', N'TP.HCM', '0123456789');

-- Thêm thuốc
INSERT INTO Thuoc VALUES('T001', N'Paracetamol', 15000, 100, '2023-01-01', 36, 'para.jpg', 'NSX001', N'Viên', N'Việt Nam', N'Thuốc giảm đau');
INSERT INTO Thuoc VALUES('T002', N'Vitamin C', 25000, 150, '2023-02-15', 24, 'vitc.jpg', 'NSX002', N'Viên', N'Việt Nam', N'Vitamin');

-- Thêm khách hàng
INSERT INTO KhachHang VALUES('KH001', N'Nguyễn Văn A', N'Hà Nội', 'nguyenvana', '123456', '0987654321', '1990-01-01', 'nguyenvana@gmail.com', 0);
INSERT INTO KhachHang VALUES('KH002', N'Admin', N'TP.HCM', 'admin', 'admin', '0123456789', '1985-05-05', 'admin@pharmacy.com', 1);
*/ 