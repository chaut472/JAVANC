package utils;

import javax.swing.*;
import javax.swing.table.*;
import javax.swing.plaf.basic.BasicScrollBarUI;
import java.awt.*;
import javax.swing.border.EmptyBorder;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class TableUtils {
    private static final Color HEADER_BACKGROUND = new Color(52, 73, 94);
    private static final Color HEADER_FOREGROUND = Color.WHITE;
    private static final Color ALTERNATE_ROW_COLOR = new Color(245, 247, 250);
    private static final Color SELECTION_BACKGROUND = new Color(41, 128, 185);
    private static final Font HEADER_FONT = new Font("Segoe UI", Font.BOLD, 13);
    private static final Font TABLE_FONT = new Font("Segoe UI", Font.PLAIN, 13);
    
    public static void setTableStyle(JTable table) {
        // Set basic table properties
        table.setFont(TABLE_FONT);
        table.setRowHeight(35);
        table.setShowGrid(false);
        table.setIntercellSpacing(new Dimension(0, 0));
        table.setFillsViewportHeight(true);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        // Style the header
        JTableHeader header = table.getTableHeader();
        header.setFont(HEADER_FONT);
        header.setBackground(HEADER_BACKGROUND);
        header.setForeground(HEADER_FOREGROUND);
        header.setPreferredSize(new Dimension(header.getPreferredSize().width, 40));
        header.setBorder(null);
        
        // Create custom header renderer
        DefaultTableCellRenderer headerRenderer = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                    boolean isSelected, boolean hasFocus, int row, int column) {
                Component comp = super.getTableCellRendererComponent(table, value,
                        isSelected, hasFocus, row, column);
                comp.setBackground(HEADER_BACKGROUND);
                comp.setForeground(HEADER_FOREGROUND);
                setBorder(new EmptyBorder(0, 10, 0, 10));
                return comp;
            }
        };
        headerRenderer.setHorizontalAlignment(JLabel.LEFT);
        
        // Apply header renderer to all columns
        for (int i = 0; i < table.getColumnCount(); i++) {
            table.getColumnModel().getColumn(i).setHeaderRenderer(headerRenderer);
        }
        
        // Create custom cell renderer
        DefaultTableCellRenderer cellRenderer = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                    boolean isSelected, boolean hasFocus, int row, int column) {
                Component comp = super.getTableCellRendererComponent(table, value,
                        isSelected, hasFocus, row, column);
                
                if (isSelected) {
                    comp.setBackground(SELECTION_BACKGROUND);
                    comp.setForeground(Color.WHITE);
                } else {
                    comp.setBackground(row % 2 == 0 ? Color.WHITE : ALTERNATE_ROW_COLOR);
                    comp.setForeground(Color.BLACK);
                }
                
                setBorder(new EmptyBorder(0, 10, 0, 10));
                return comp;
            }
        };
        cellRenderer.setHorizontalAlignment(JLabel.LEFT);
        
        // Apply cell renderer to all columns
        for (int i = 0; i < table.getColumnCount(); i++) {
            table.getColumnModel().getColumn(i).setCellRenderer(cellRenderer);
        }
        
        // Add hover effect
        table.addMouseMotionListener(new MouseAdapter() {
            @Override
            public void mouseMoved(MouseEvent e) {
                Point p = e.getPoint();
                int row = table.rowAtPoint(p);
                if (row != -1 && !table.isRowSelected(row)) {
                    table.clearSelection();
                    table.setRowSelectionInterval(row, row);
                }
            }
        });
    }
    
    public static void addIconColumn(JTable table, int columnIndex, String iconPath, int iconSize) {
        TableColumn column = table.getColumnModel().getColumn(columnIndex);
        column.setCellRenderer(new DefaultTableCellRenderer() {
            private final ImageIcon icon = createScaledIcon(iconPath, iconSize);
            
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                    boolean isSelected, boolean hasFocus, int row, int column) {
                JLabel label = (JLabel) super.getTableCellRendererComponent(table, value,
                        isSelected, hasFocus, row, column);
                label.setIcon(icon);
                label.setHorizontalAlignment(JLabel.CENTER);
                label.setText("");
                
                if (isSelected) {
                    label.setBackground(SELECTION_BACKGROUND);
                } else {
                    label.setBackground(row % 2 == 0 ? Color.WHITE : ALTERNATE_ROW_COLOR);
                }
                
                return label;
            }
        });
        column.setMaxWidth(iconSize + 20);
        column.setMinWidth(iconSize + 20);
    }
    
    public static void addButtonColumn(JTable table, int columnIndex, String text, Color buttonColor) {
        TableColumn column = table.getColumnModel().getColumn(columnIndex);
        column.setCellRenderer(new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                    boolean isSelected, boolean hasFocus, int row, int column) {
                JButton button = new JButton(text);
                button.setFont(new Font("Segoe UI", Font.BOLD, 12));
                button.setBackground(buttonColor);
                button.setForeground(Color.WHITE);
                button.setBorderPainted(false);
                button.setFocusPainted(false);
                
                return button;
            }
        });
        
        column.setCellEditor(new DefaultCellEditor(new JTextField()) {
            private final JButton button = new JButton(text);
            
            {
                button.setFont(new Font("Segoe UI", Font.BOLD, 12));
                button.setBackground(buttonColor);
                button.setForeground(Color.WHITE);
                button.setBorderPainted(false);
                button.setFocusPainted(false);
                button.addActionListener(e -> fireEditingStopped());
            }
            
            @Override
            public Component getTableCellEditorComponent(JTable table, Object value,
                    boolean isSelected, int row, int column) {
                return button;
            }
        });
    }
    
    private static ImageIcon createScaledIcon(String path, int size) {
        try {
            ImageIcon originalIcon = new ImageIcon(TableUtils.class.getResource(path));
            Image scaled = originalIcon.getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH);
            return new ImageIcon(scaled);
        } catch (Exception e) {
            System.out.println("Could not load icon: " + path);
            return null;
        }
    }
    
    public static void setupTableScrollPane(JScrollPane scrollPane) {
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        scrollPane.getViewport().setBackground(Color.WHITE);
        
        // Custom scroll bar styling
        JScrollBar verticalBar = scrollPane.getVerticalScrollBar();
        verticalBar.setUI(new BasicScrollBarUI() {
            @Override
            protected void configureScrollBarColors() {
                this.thumbColor = new Color(210, 210, 210);
                this.trackColor = Color.WHITE;
            }
            
            @Override
            protected JButton createDecreaseButton(int orientation) {
                return createZeroButton();
            }
            
            @Override
            protected JButton createIncreaseButton(int orientation) {
                return createZeroButton();
            }
            
            private JButton createZeroButton() {
                JButton button = new JButton();
                button.setPreferredSize(new Dimension(0, 0));
                button.setMinimumSize(new Dimension(0, 0));
                button.setMaximumSize(new Dimension(0, 0));
                return button;
            }
        });
    }
} 