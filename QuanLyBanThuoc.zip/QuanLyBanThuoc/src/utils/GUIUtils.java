package utils;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.plaf.basic.BasicScrollBarUI;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;

/**
 * Utility class for consistent modern web-like GUI styling across the application
 */
public class GUIUtils {
    // Modern web-like color scheme
    public static final Color PRIMARY_COLOR = new Color(66, 133, 244);      // Google Blue
    public static final Color SECONDARY_COLOR = new Color(52, 168, 235);   // Lighter Blue
    public static final Color ACCENT_COLOR = new Color(52, 168, 83);       // Google Green
    public static final Color DANGER_COLOR = new Color(234, 67, 53);       // Google Red
    public static final Color WARNING_COLOR = new Color(251, 188, 5);      // Google Yellow
    public static final Color BACKGROUND_COLOR = new Color(245, 248, 250); // Light Gray Blue
    public static final Color CARD_COLOR = Color.WHITE;                    // White for cards
    public static final Color TEXT_COLOR = new Color(60, 64, 67);          // Dark Gray for text
    public static final Color BORDER_COLOR = new Color(218, 220, 224);     // Light Gray for borders
    
    // Gradient colors for panels
    public static final Color GRADIENT_START = new Color(66, 133, 244);    // Google Blue
    public static final Color GRADIENT_END = new Color(52, 168, 235);      // Lighter Blue
    
    // Font settings - more web-like
    public static final Font TITLE_FONT = new Font("Segoe UI", Font.BOLD, 24);
    public static final Font SUBTITLE_FONT = new Font("Segoe UI", Font.BOLD, 18);
    public static final Font HEADING_FONT = new Font("Segoe UI", Font.BOLD, 16);
    public static final Font LABEL_FONT = new Font("Segoe UI", Font.PLAIN, 14);
    public static final Font BUTTON_FONT = new Font("Segoe UI", Font.PLAIN, 14);
    public static final Font FIELD_FONT = new Font("Segoe UI", Font.PLAIN, 14);
    public static final Font TABLE_HEADER_FONT = new Font("Segoe UI", Font.BOLD, 14);
    public static final Font TABLE_CELL_FONT = new Font("Segoe UI", Font.PLAIN, 13);
    
    // Padding and spacing
    public static final int PADDING = 20;
    public static final int SMALL_PADDING = 10;
    public static final int LARGE_PADDING = 30;
    
    // Common border radius
    public static final int BORDER_RADIUS = 8;
    
    /**
     * Sets up the basic application look and feel
     */
    public static void setupGUI() {
        try {
            // Use system look and feel as base
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            
            // Override specific UI elements
            UIManager.put("Panel.background", BACKGROUND_COLOR);
            UIManager.put("OptionPane.background", CARD_COLOR);
            UIManager.put("Button.font", BUTTON_FONT);
            UIManager.put("Label.font", LABEL_FONT);
            UIManager.put("Label.foreground", TEXT_COLOR);
            UIManager.put("TextField.font", FIELD_FONT);
            UIManager.put("PasswordField.font", FIELD_FONT);
            UIManager.put("ComboBox.font", FIELD_FONT);
            UIManager.put("CheckBox.font", FIELD_FONT);
            UIManager.put("RadioButton.font", FIELD_FONT);
            UIManager.put("Table.font", TABLE_CELL_FONT);
            UIManager.put("TableHeader.font", TABLE_HEADER_FONT);
            UIManager.put("OptionPane.messageFont", LABEL_FONT);
            UIManager.put("OptionPane.buttonFont", BUTTON_FONT);
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    /**
     * Creates a gradient panel with rounded corners
     */
    public static JPanel createGradientPanel() {
        return new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
                
                int w = getWidth();
                int h = getHeight();
                
                // Create gradient
                GradientPaint gp = new GradientPaint(0, 0, GRADIENT_START, w, h, GRADIENT_END);
                g2d.setPaint(gp);
                
                // Fill with rounded corners
                g2d.fill(new RoundRectangle2D.Double(0, 0, w, h, BORDER_RADIUS*2, BORDER_RADIUS*2));
            }
        };
    }
    
    /**
     * Creates a modern card panel with shadow and rounded corners
     */
    public static JPanel createCardPanel() {
        JPanel cardPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
                
                // Draw shadow
                g2d.setColor(new Color(0, 0, 0, 30));
                g2d.fillRoundRect(2, 2, getWidth()-4, getHeight()-2, BORDER_RADIUS, BORDER_RADIUS);
                
                // Draw card
                g2d.setColor(CARD_COLOR);
                g2d.fillRoundRect(0, 0, getWidth()-4, getHeight()-4, BORDER_RADIUS, BORDER_RADIUS);
                
                super.paintComponent(g);
            }
        };
        
        // Make panel background transparent to show custom painting
        cardPanel.setOpaque(false);
        cardPanel.setLayout(new BorderLayout());
        cardPanel.setBorder(BorderFactory.createEmptyBorder(PADDING, PADDING, PADDING, PADDING));
        
        return cardPanel;
    }
    
    /**
     * Creates a dashboard card with title, value and icon
     */
    public static JPanel createDashboardCard(String title, String value, Color color, Icon icon) {
        JPanel card = new JPanel(new BorderLayout(10, 10)) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
                
                // Draw shadow
                g2d.setColor(new Color(0, 0, 0, 30));
                g2d.fillRoundRect(2, 2, getWidth()-4, getHeight()-2, BORDER_RADIUS, BORDER_RADIUS);
                
                // Create gradient
                GradientPaint gp = new GradientPaint(
                    0, 0, color, 
                    getWidth(), getHeight(), color.brighter()
                );
                g2d.setPaint(gp);
                
                // Draw card
                g2d.fillRoundRect(0, 0, getWidth()-4, getHeight()-4, BORDER_RADIUS, BORDER_RADIUS);
                
                super.paintComponent(g);
            }
        };
        
        // Make panel background transparent to show custom painting
        card.setOpaque(false);
        card.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        
        // Title label
        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(LABEL_FONT);
        titleLabel.setForeground(Color.WHITE);
        
        // Value label
        JLabel valueLabel = new JLabel(value);
        valueLabel.setFont(new Font("Segoe UI", Font.BOLD, 32));
        valueLabel.setForeground(Color.WHITE);
        valueLabel.setHorizontalAlignment(JLabel.CENTER);
        
        // Add icon if provided
        if (icon != null) {
            JLabel iconLabel = new JLabel(icon);
            iconLabel.setHorizontalAlignment(JLabel.RIGHT);
            card.add(iconLabel, BorderLayout.EAST);
        }
        
        card.add(titleLabel, BorderLayout.NORTH);
        card.add(valueLabel, BorderLayout.CENTER);
        
        return card;
    }
    
    /**
     * Styles a primary button with rounded corners
     */
    public static void stylePrimaryButton(JButton button) {
        styleRoundedButton(button, PRIMARY_COLOR);
    }
    
    /**
     * Styles a secondary button with rounded corners
     */
    public static void styleSecondaryButton(JButton button) {
        styleRoundedButton(button, SECONDARY_COLOR);
    }
    
    /**
     * Styles an accent button with rounded corners
     */
    public static void styleAccentButton(JButton button) {
        styleRoundedButton(button, ACCENT_COLOR);
    }
    
    /**
     * Styles a danger button with rounded corners
     */
    public static void styleDangerButton(JButton button) {
        styleRoundedButton(button, DANGER_COLOR);
    }
    
    /**
     * Styles a warning button with rounded corners
     */
    public static void styleWarningButton(JButton button) {
        styleRoundedButton(button, WARNING_COLOR);
    }
    
    /**
     * Styles an outlined button with rounded corners
     */
    public static void styleOutlinedButton(JButton button, Color color) {
        button.setBackground(CARD_COLOR);
        button.setForeground(color);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setFont(BUTTON_FONT);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(color, 1, true),
            new EmptyBorder(8, 15, 8, 15)
        ));
        
        // Add hover effect
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(new Color(color.getRed(), color.getGreen(), color.getBlue(), 30));
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(CARD_COLOR);
            }
        });
    }
    
    /**
     * Styles a button with rounded corners
     */
    public static void styleRoundedButton(JButton button, Color color) {
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setFont(BUTTON_FONT);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setBorder(new EmptyBorder(8, 15, 8, 15));
        
        // Use custom UI to make the button rounded
        button.setUI(new javax.swing.plaf.basic.BasicButtonUI() {
            @Override
            public void paint(Graphics g, JComponent c) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                AbstractButton b = (AbstractButton) c;
                ButtonModel model = b.getModel();
                
                if (model.isPressed()) {
                    g2.setColor(color.darker());
                } else if (model.isRollover()) {
                    g2.setColor(color.brighter());
                } else {
                    g2.setColor(color);
                }
                
                g2.fillRoundRect(0, 0, c.getWidth(), c.getHeight(), BORDER_RADIUS, BORDER_RADIUS);
                
                super.paint(g, c);
                g2.dispose();
            }
        });
        
        // Add hover effect
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(color.brighter());
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(color);
            }
        });
    }
    
    /**
     * Styles a title label
     */
    public static JLabel createTitleLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(TITLE_FONT);
        label.setForeground(Color.WHITE);
        return label;
    }
    
    /**
     * Styles a subtitle label
     */
    public static JLabel createSubtitleLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(SUBTITLE_FONT);
        label.setForeground(PRIMARY_COLOR);
        return label;
    }
    
    /**
     * Styles a heading label
     */
    public static JLabel createHeadingLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(HEADING_FONT);
        label.setForeground(TEXT_COLOR);
        return label;
    }
    
    /**
     * Styles a form field label
     */
    public static JLabel createFormLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(LABEL_FONT);
        label.setForeground(Color.WHITE);
        return label;
    }
    
    /**
     * Styles a form field dark label (for light backgrounds)
     */
    public static JLabel createDarkFormLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(LABEL_FONT);
        label.setForeground(TEXT_COLOR);
        return label;
    }
    
    /**
     * Styles a text field with rounded corners
     */
    public static void styleTextField(JTextField textField) {
        textField.setFont(FIELD_FONT);
        textField.setBackground(Color.WHITE);
        textField.setForeground(TEXT_COLOR);
        textField.setBorder(BorderFactory.createCompoundBorder(
            new RoundedBorder(BORDER_COLOR, 1, BORDER_RADIUS),
            BorderFactory.createEmptyBorder(8, 10, 8, 10)
        ));
    }
    
    /**
     * Styles a password field with rounded corners
     */
    public static void stylePasswordField(JPasswordField passwordField) {
        passwordField.setFont(FIELD_FONT);
        passwordField.setBackground(Color.WHITE);
        passwordField.setForeground(TEXT_COLOR);
        passwordField.setBorder(BorderFactory.createCompoundBorder(
            new RoundedBorder(BORDER_COLOR, 1, BORDER_RADIUS),
            BorderFactory.createEmptyBorder(8, 10, 8, 10)
        ));
    }
    
    /**
     * Styles a text area with rounded corners
     */
    public static void styleTextArea(JTextArea textArea) {
        textArea.setFont(FIELD_FONT);
        textArea.setBackground(Color.WHITE);
        textArea.setForeground(TEXT_COLOR);
        textArea.setBorder(BorderFactory.createCompoundBorder(
            new RoundedBorder(BORDER_COLOR, 1, BORDER_RADIUS),
            BorderFactory.createEmptyBorder(8, 10, 8, 10)
        ));
        
        // Style scrollbars if in a scroll pane
        if (textArea.getParent() instanceof JViewport && 
            textArea.getParent().getParent() instanceof JScrollPane) {
            JScrollPane scrollPane = (JScrollPane) textArea.getParent().getParent();
            styleScrollPane(scrollPane);
        }
    }
    
    /**
     * Styles a combo box with rounded corners
     */
    public static void styleComboBox(JComboBox<?> comboBox) {
        comboBox.setFont(FIELD_FONT);
        comboBox.setBackground(Color.WHITE);
        comboBox.setForeground(TEXT_COLOR);
        comboBox.setBorder(new RoundedBorder(BORDER_COLOR, 1, BORDER_RADIUS));
    }
    
    /**
     * Styles a scroll pane
     */
    public static void styleScrollPane(JScrollPane scrollPane) {
        scrollPane.setBorder(new RoundedBorder(BORDER_COLOR, 1, BORDER_RADIUS));
        scrollPane.getVerticalScrollBar().setUI(new ModernScrollBarUI());
        scrollPane.getHorizontalScrollBar().setUI(new ModernScrollBarUI());
    }
    
    /**
     * Styles a JTable for better appearance
     */
    public static void styleTable(JTable table) {
        // Style header
        JTableHeader header = table.getTableHeader();
        header.setBackground(PRIMARY_COLOR);
        header.setForeground(Color.WHITE);
        header.setFont(TABLE_HEADER_FONT);
        header.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, BORDER_COLOR));
        
        // Style cells
        table.setFont(TABLE_CELL_FONT);
        table.setRowHeight(40);
        table.setShowGrid(false);
        table.setIntercellSpacing(new Dimension(0, 0));
        table.setFillsViewportHeight(true);
        table.setSelectionBackground(new Color(PRIMARY_COLOR.getRed(), PRIMARY_COLOR.getGreen(), PRIMARY_COLOR.getBlue(), 50));
        table.setSelectionForeground(TEXT_COLOR);
        
        // Add zebra striping
        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                Component comp = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                if (!isSelected) {
                    comp.setBackground(row % 2 == 0 ? Color.WHITE : new Color(245, 245, 250));
                }
                setBorder(new EmptyBorder(0, 10, 0, 10));
                return comp;
            }
        });
        
        // Style the containing scroll pane if present
        if (table.getParent() instanceof JViewport && 
            table.getParent().getParent() instanceof JScrollPane) {
            JScrollPane scrollPane = (JScrollPane) table.getParent().getParent();
            styleScrollPane(scrollPane);
        }
    }
    
    /**
     * Creates a styled form panel with gradient background
     */
    public static JPanel createFormPanel() {
        JPanel panel = createGradientPanel();
        panel.setLayout(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(PADDING, PADDING, PADDING, PADDING));
        return panel;
    }
    
    /**
     * Creates a content panel with the standard background color
     */
    public static JPanel createContentPanel() {
        JPanel panel = new JPanel();
        panel.setBackground(BACKGROUND_COLOR);
        panel.setBorder(BorderFactory.createEmptyBorder(PADDING, PADDING, PADDING, PADDING));
        return panel;
    }
    
    /**
     * Creates a button panel with standard spacing
     */
    public static JPanel createButtonPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        panel.setOpaque(false);
        return panel;
    }
    
    /**
     * Creates a navigation sidebar
     */
    public static JPanel createSidebar() {
        JPanel sidebar = new JPanel();
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBackground(PRIMARY_COLOR);
        sidebar.setBorder(BorderFactory.createEmptyBorder(PADDING, PADDING, PADDING, PADDING));
        return sidebar;
    }
    
    /**
     * Creates a sidebar menu item
     */
    public static JButton createSidebarButton(String text, Icon icon) {
        JButton button = new JButton(text);
        if (icon != null) {
            button.setIcon(icon);
            button.setHorizontalAlignment(SwingConstants.LEFT);
            button.setIconTextGap(10);
        }
        
        button.setFont(BUTTON_FONT);
        button.setForeground(Color.WHITE);
        button.setBackground(PRIMARY_COLOR);
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setContentAreaFilled(false);
        button.setAlignmentX(Component.LEFT_ALIGNMENT);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        // Add hover effect
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(PRIMARY_COLOR.darker());
                button.setContentAreaFilled(true);
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                button.setContentAreaFilled(false);
            }
        });
        
        return button;
    }
    
    /**
     * Adds a form field with label to a GridBagLayout panel
     */
    public static void addFormField(JPanel panel, String labelText, JComponent field, GridBagConstraints gbc, int row) {
        gbc.gridx = 0;
        gbc.gridy = row;
        gbc.anchor = GridBagConstraints.WEST;
        JLabel label = createFormLabel(labelText);
        panel.add(label, gbc);

        gbc.gridx = 1;
        gbc.weightx = 1.0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        panel.add(field, gbc);
        gbc.weightx = 0.0;
    }
    
    /**
     * Adds a form field with dark label to a GridBagLayout panel
     */
    public static void addDarkFormField(JPanel panel, String labelText, JComponent field, GridBagConstraints gbc, int row) {
        gbc.gridx = 0;
        gbc.gridy = row;
        gbc.anchor = GridBagConstraints.WEST;
        JLabel label = createDarkFormLabel(labelText);
        panel.add(label, gbc);

        gbc.gridx = 1;
        gbc.weightx = 1.0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        panel.add(field, gbc);
        gbc.weightx = 0.0;
    }
    
    /**
     * Creates a horizontal separator
     */
    public static JSeparator createSeparator() {
        JSeparator separator = new JSeparator(JSeparator.HORIZONTAL);
        separator.setForeground(BORDER_COLOR);
        return separator;
    }
    
    /**
     * Custom border with rounded corners
     */
    private static class RoundedBorder extends LineBorder {
        private int radius;
        
        RoundedBorder(Color color, int thickness, int radius) {
            super(color, thickness);
            this.radius = radius;
        }
        
        @Override
        public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(lineColor);
            g2.drawRoundRect(x, y, width-1, height-1, radius, radius);
            g2.dispose();
        }
    }
    
    /**
     * Custom modern scroll bar UI
     */
    private static class ModernScrollBarUI extends BasicScrollBarUI {
        @Override
        protected void configureScrollBarColors() {
            this.thumbColor = new Color(200, 200, 200);
            this.trackColor = Color.WHITE;
        }
        
        @Override
        protected JButton createDecreaseButton(int orientation) {
            return createZeroButton();
        }
        
        @Override
        protected JButton createIncreaseButton(int orientation) {
            return createZeroButton();
        }
        
        private JButton createZeroButton() {
            JButton button = new JButton();
            button.setPreferredSize(new Dimension(0, 0));
            button.setMinimumSize(new Dimension(0, 0));
            button.setMaximumSize(new Dimension(0, 0));
            return button;
        }
        
        @Override
        protected void paintThumb(Graphics g, JComponent c, Rectangle thumbBounds) {
            if (thumbBounds.isEmpty() || !scrollbar.isEnabled()) {
                return;
            }
            
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(thumbColor);
            
            int arc = 8;
            if (scrollbar.getOrientation() == JScrollBar.VERTICAL) {
                g2.fillRoundRect(thumbBounds.x + 2, thumbBounds.y, 
                                 thumbBounds.width - 4, thumbBounds.height, 
                                 arc, arc);
            } else {
                g2.fillRoundRect(thumbBounds.x, thumbBounds.y + 2, 
                                 thumbBounds.width, thumbBounds.height - 4, 
                                 arc, arc);
            }
            g2.dispose();
        }
    }
} 