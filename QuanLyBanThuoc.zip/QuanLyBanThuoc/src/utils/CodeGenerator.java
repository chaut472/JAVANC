package utils;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Random;

public class CodeGenerator {
    private static final String PREFIX = "KH";
    private static final Random random = new Random();
    
    public static String generateUserCode() {
        // Get current date in format YYMMDD
        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyMMdd");
        String date = now.format(formatter);
        
        // Generate 2 random digits
        String randomDigits = String.format("%02d", random.nextInt(100));
        
        // Combine to create a 10-character code: KH + YYMMDD + 2 random digits
        return PREFIX + date + randomDigits;
    }
    
    public static String generateVerificationCode() {
        // Generate 6-digit verification code
        return String.format("%06d", random.nextInt(1000000));
    }
} 