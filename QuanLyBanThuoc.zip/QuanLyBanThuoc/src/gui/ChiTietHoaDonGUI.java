/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package gui;

import bus.ChiTietHoaDonBUS;
import entity.ChiTietHoaDon;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class ChiTietHoaDonGUI extends JPanel {
    private JTable table;
    private DefaultTableModel model;
    private ChiTietHoaDonBUS bus = new ChiTietHoaDonBUS();

    public ChiTietHoaDonGUI() {
        setLayout(new BorderLayout(10, 10));

        model = new DefaultTableModel(new String[]{"Mã HĐ", "Mã Thuốc", "Tên Thuốc", "Số Lượng"}, 0);
        table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);

        // Panel chứa nút chức năng
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        JButton btnThem = new JButton("Thêm");
        JButton btnSua = new JButton("Sửa");
     
        JButton btnTaiLai = new JButton("Tải lại");

        buttonPanel.add(btnThem);
        buttonPanel.add(btnSua);
        buttonPanel.add(btnTaiLai);

// Sự kiện: Thêm
btnThem.addActionListener(e -> {
    JTextField txtMaHD = new JTextField();
    JTextField txtMaThuoc = new JTextField();
    JTextField txtSoLuong = new JTextField();

    Object[] input = {
        "Mã Chi Tiết Hóa Đơn:", txtMaHD,
        "Mã Thuốc:", txtMaThuoc,
        "Số Lượng:", txtSoLuong
    };
    int result = JOptionPane.showConfirmDialog(this, input, "Thêm Chi Tiết Hóa Đơn", JOptionPane.OK_CANCEL_OPTION);
    if (result == JOptionPane.OK_OPTION) {
        // Kiểm tra xem các trường có được nhập hay không
        if (txtMaHD.getText().trim().isEmpty() || txtMaThuoc.getText().trim().isEmpty() || txtSoLuong.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập đầy đủ thông tin!");
            return; // Dừng lại nếu có trường không hợp lệ
        }

        try {
            ChiTietHoaDon cthd = new ChiTietHoaDon(
                txtMaHD.getText(),
                txtMaThuoc.getText(),
                "", // Tên thuốc không cần nhập
                Integer.parseInt(txtSoLuong.getText())
            );
            if (bus.them(cthd)) {
                loadData();
                JOptionPane.showMessageDialog(this, "Thêm thành công!");
            } else {
                JOptionPane.showMessageDialog(this, "Thêm thất bại!");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Số lượng phải là một số!");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Dữ liệu không hợp lệ!");
        }
    }
});
        // Sự kiện: Sửa
        btnSua.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row >= 0) {
                String maHD = model.getValueAt(row, 0).toString();
                String maThuoc = model.getValueAt(row, 1).toString();
                String tenThuocHienTai = model.getValueAt(row, 2).toString();
                String soLuongHienTai = model.getValueAt(row, 3).toString();
                JTextField txtTenThuoc = new JTextField(tenThuocHienTai);
                JTextField txtSoLuong = new JTextField(soLuongHienTai);
                Object[] input = {
                    "Mã HĐ: " + maHD,
                    "Mã Thuốc: " + maThuoc,
                    "Tên Thuốc:", txtTenThuoc,
                    "Số Lượng mới:", txtSoLuong
                };
                int result = JOptionPane.showConfirmDialog(this, input, "Sửa Chi Tiết Hóa Đơn", JOptionPane.OK_CANCEL_OPTION);
                if (result == JOptionPane.OK_OPTION) {
                    try {
                        ChiTietHoaDon cthd = new ChiTietHoaDon(maHD, maThuoc, txtTenThuoc.getText(), Integer.parseInt(txtSoLuong.getText()));
                        if (bus.sua(cthd)) {
                            loadData();
                            JOptionPane.showMessageDialog(this, "Cập nhật thành công!");
                        } else {
                            JOptionPane.showMessageDialog(this, "Cập nhật thất bại!");
                        }
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(this, "Số lượng phải là một số!");
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(this, "Dữ liệu không hợp lệ!");
                    }
                }
            } else {
                JOptionPane.showMessageDialog(this, "Vui lòng chọn dòng cần sửa!");
            }
        });
        // Sự kiện: Tải lại
        btnTaiLai.addActionListener(e -> {
            if (bus == null) {
                bus = new ChiTietHoaDonBUS();
            }
            loadData();
            List<ChiTietHoaDon> list = bus.getAll();
            JOptionPane.showMessageDialog(this, "Số bản ghi: " + list.size());
        });
        // Add components to main layout
        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
        loadData();
    }

    private void loadData() {
        model.setRowCount(0);
        List<ChiTietHoaDon> list = bus.getAll();
        for (ChiTietHoaDon cthd : list) {
            model.addRow(new Object[]{
                cthd.getMaHoaDon(),
                cthd.getMaThuoc(),
                cthd.getTenThuoc(), 
                cthd.getSoLuong()
            });
        }
    }
}

