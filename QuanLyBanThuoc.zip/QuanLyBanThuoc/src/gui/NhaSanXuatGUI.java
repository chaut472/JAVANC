/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gui;

/**
 *
 * @author Cao Thi Han
 */
import bus.NhaSanXuatBUS;
import entity.NhaSanXuat;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class NhaSanXuatGUI extends JPanel {
    private NhaSanXuatBUS bus = new NhaSanXuatBUS();
    private JTable table;
    private DefaultTableModel model;

    public NhaSanXuatGUI() {
        setLayout(new BorderLayout());

        model = new DefaultTableModel();
        model.setColumnIdentifiers(new String[]{"Mã", "Tên", "Địa chỉ", "SĐT"});
        table = new JTable(model);
        loadData();

        JButton btnThem = new JButton("Thêm");
        btnThem.addActionListener(e -> showDialogToAddOrEdit(null));

        JButton btnSua = new JButton("Sửa");
        btnSua.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row >= 0) {
                String ma = model.getValueAt(row, 0).toString();
                String ten = model.getValueAt(row, 1).toString();
                String diaChi = model.getValueAt(row, 2).toString();
                String sdt = model.getValueAt(row, 3).toString();

                NhaSanXuat nsx = new NhaSanXuat(ma, ten, diaChi, sdt);
                showDialogToAddOrEdit(nsx);
            } else {
                JOptionPane.showMessageDialog(this, "Vui lòng chọn nhà sản xuất để sửa.");
            }
        });

        JButton btnXoa = new JButton("Xóa");
        btnXoa.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row >= 0) {
                String ma = model.getValueAt(row, 0).toString();
                if (bus.xoa(ma)) {
                    loadData();
                } else {
                    JOptionPane.showMessageDialog(this, "Xóa thất bại!");
                }
            }
        });

        JPanel panel = new JPanel();
        panel.add(btnThem);
        panel.add(btnSua);
        panel.add(btnXoa);

        add(new JScrollPane(table), BorderLayout.CENTER);
        add(panel, BorderLayout.SOUTH);
    }

    private void showDialogToAddOrEdit(NhaSanXuat nsx) {
        JTextField ma = new JTextField(nsx != null ? nsx.getMaNhaSanXuat() : "");
        JTextField ten = new JTextField(nsx != null ? nsx.getTenNhaSanXuat() : "");
        JTextField diaChi = new JTextField(nsx != null ? nsx.getDiaChi() : "");
        JTextField sdt = new JTextField(nsx != null ? nsx.getSdt() : "");

        Object[] input = {
            "Mã:", ma,
            "Tên:", ten,
            "Địa chỉ:", diaChi,
            "SĐT:", sdt
        };

        int result = JOptionPane.showConfirmDialog(this, input, nsx == null ? "Thêm Nhà Sản Xuất" : "Sửa Nhà Sản Xuất", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            NhaSanXuat newNSX = new NhaSanXuat(ma.getText(), ten.getText(), diaChi.getText(), sdt.getText());
            boolean success;
            if (nsx == null) {
                success = bus.themMoi(newNSX);
            } else {
                newNSX.setMaNhaSanXuat(nsx.getMaNhaSanXuat()); // giữ mã cũ
                success = bus.sua(newNSX);
            }

            if (success) {
                loadData();
            } else {
                JOptionPane.showMessageDialog(this, nsx == null ? "Thêm thất bại!" : "Sửa thất bại!");
            }
        }
    }

    private void loadData() {
        model.setRowCount(0);
        for (NhaSanXuat nsx : bus.getAll()) {
            model.addRow(new Object[] {
                nsx.getMaNhaSanXuat(),
                nsx.getTenNhaSanXuat(),
                nsx.getDiaChi(),
                nsx.getSdt()
            });
        }
    }
}
