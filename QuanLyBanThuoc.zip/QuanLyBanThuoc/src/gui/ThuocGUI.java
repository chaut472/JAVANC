/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gui;

/**
 *
 * @author Cao Thi Han
 */

import bus.ThuocBUS;
import bus.HoaDonBUS;
import bus.ChiTietHoaDonBUS;
import entity.Thuoc;
import entity.HoaDon;
import entity.ChiTietHoaDon;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import utils.TableUtils;
import java.awt.event.*;
import javax.swing.border.*;
import entity.User;
import java.util.Map;
import java.util.HashMap;
import java.sql.SQLException;

public class ThuocGUI extends JPanel {
    private ThuocBUS bus = new ThuocBUS();
    private HoaDonBUS hoaDonBUS;
    private ChiTietHoaDonBUS chiTietHoaDonBUS = new ChiTietHoaDonBUS();
    private JTable table;
    private DefaultTableModel model;
    private JTextField txtSearch;
    private Color primaryColor = new Color(41, 128, 185);
    private Color secondaryColor = new Color(52, 152, 219);
    private User currentUser;
    private JButton btnAdd;
    private JButton btnEdit;
    private JButton btnDelete;
    private JButton btnRefresh;
    private JButton btnBuy;
    private JButton btnViewOrders;
    private Thuoc selectedThuoc;

    public ThuocGUI(User user) {
        this.currentUser = user;
        try {
            this.hoaDonBUS = new HoaDonBUS();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                "Lỗi kết nối đến cơ sở dữ liệu: " + e.getMessage(),
                "Lỗi",
                JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
        setLayout(new BorderLayout());
        setBackground(Color.WHITE);
        
        // Create top panel
        createTopPanel();
        
        // Create table
        createTable();
        
        // Create bottom panel
        createBottomPanel();
        
        // Add event handlers for admin buttons
        if ("ADMIN".equalsIgnoreCase(currentUser.getVaiTro())) {
            addAdminButtonHandlers();
        }
    }
    
    private void createTopPanel() {
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBackground(Color.WHITE);
        topPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Title and search panel
        JPanel titleSearchPanel = new JPanel(new BorderLayout(20, 0));
        titleSearchPanel.setBackground(Color.WHITE);
        
        // Title
        JLabel titleLabel = new JLabel("Quản Lý Thuốc");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        titleLabel.setForeground(new Color(44, 62, 80));
        
        // Search panel
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchPanel.setBackground(Color.WHITE);
        
        txtSearch = new JTextField(20);
        txtSearch.setPreferredSize(new Dimension(200, 35));
        txtSearch.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(189, 195, 199)),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        
        JButton btnSearch = new JButton("Tìm kiếm");
        styleButton(btnSearch, primaryColor);
        
        // Add search functionality for all users
        btnSearch.addActionListener(e -> searchThuoc());
        txtSearch.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    searchThuoc();
                }
            }
        });
        
        searchPanel.add(txtSearch);
        searchPanel.add(btnSearch);
        
        titleSearchPanel.add(titleLabel, BorderLayout.WEST);
        titleSearchPanel.add(searchPanel, BorderLayout.EAST);
        
        // Action buttons panel
        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        actionPanel.setBackground(Color.WHITE);
        actionPanel.setBorder(BorderFactory.createEmptyBorder(20, 0, 0, 0));
        
        btnAdd = new JButton("Thêm thuốc mới");
        btnEdit = new JButton("Sửa");
        btnDelete = new JButton("Xóa");
        btnRefresh = new JButton("Làm mới");
        
        styleButton(btnAdd, primaryColor);
        styleButton(btnEdit, secondaryColor);
        styleButton(btnDelete, new Color(231, 76, 60));
        styleButton(btnRefresh, new Color(46, 204, 113));
        
        // Add refresh functionality
        btnRefresh.addActionListener(e -> {
            txtSearch.setText("");
            loadData();
        });
        
        // Only show CRUD buttons for admin users
        if ("ADMIN".equalsIgnoreCase(currentUser.getVaiTro())) {
            actionPanel.add(btnAdd);
            actionPanel.add(btnEdit);
            actionPanel.add(btnDelete);
        } else {
            // Add buy button for regular users
            btnBuy = new JButton("Mua thuốc");
            styleButton(btnBuy, new Color(46, 204, 113));
            btnBuy.setEnabled(false);
            btnBuy.setToolTipText("Vui lòng chọn thuốc để mua");
            
            JButton btnViewOrders = new JButton("Chi tiết đơn hàng");
            styleButton(btnViewOrders, new Color(52, 152, 219));
            btnViewOrders.addActionListener(e -> showOrderDetailsDialog());
            
            btnBuy.addActionListener(e -> {
                if (selectedThuoc != null) {
                    showBuyDialog();
                } else {
                    JOptionPane.showMessageDialog(this,
                        "Vui lòng chọn thuốc cần mua từ bảng trước!",
                        "Thông báo",
                        JOptionPane.INFORMATION_MESSAGE);
                }
            });
            actionPanel.add(btnBuy);
            actionPanel.add(btnViewOrders);
        }
        
        // Add refresh button for all users
        actionPanel.add(btnRefresh);
        
        topPanel.add(titleSearchPanel, BorderLayout.NORTH);
        topPanel.add(actionPanel, BorderLayout.CENTER);
        
        add(topPanel, BorderLayout.NORTH);
    }
    
    private void createTable() {
        // Create table model with columns
        String[] columns = {
            "", "Mã Thuốc", "Tên Thuốc", "Đơn Vị Tính", "Số Lượng", "Giá Bán", 
            "Ngày Sản Xuất", "Hạn Sử Dụng (Ngày)", "Xuất Xứ", "Mã NSX"
        };
        
        model = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        // Create table
        table = new JTable(model);
        
        // Apply modern styling
        TableUtils.setTableStyle(table);
        
        // Add icon column for medicine
        TableUtils.addIconColumn(table, 0, "/images/medicine_small.png", 24);
        
        // Enable row selection
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setRowSelectionAllowed(true);
        table.setCellSelectionEnabled(false);
        table.setColumnSelectionAllowed(false);

        // Add selection listener for immediate feedback
        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                int selectedRow = table.getSelectedRow();
                System.out.println("Selected row: " + selectedRow);
                
                selectedThuoc = getThuocFromRow(selectedRow);
                if (selectedThuoc != null) {
                    if (btnBuy != null) {
                        btnBuy.setEnabled(true);
                        btnBuy.setBackground(new Color(46, 204, 113));
                        btnBuy.setToolTipText("Nhấn để mua " + selectedThuoc.getTenThuoc());
                    }
                } else {
                    if (btnBuy != null) {
                        btnBuy.setEnabled(false);
                        btnBuy.setBackground(new Color(200, 200, 200));
                        btnBuy.setToolTipText("Vui lòng chọn thuốc để mua");
                    }
                }
            }
        });

        // Add mouse listener for better click handling
        table.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                int row = table.rowAtPoint(e.getPoint());
                System.out.println("Mouse pressed at row: " + row);
                if (row >= 0) {
                    table.setRowSelectionInterval(row, row);
                    selectedThuoc = getThuocFromRow(row);
                    if (selectedThuoc != null && btnBuy != null) {
                        btnBuy.setEnabled(true);
                        btnBuy.setBackground(new Color(46, 204, 113));
                        btnBuy.setToolTipText("Nhấn để mua " + selectedThuoc.getTenThuoc());
                    }
                }
            }
        });
        
        // Create scroll pane with custom styling
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        scrollPane.getViewport().setBackground(Color.WHITE);
        
        // Load actual data
        loadData();
        
        add(scrollPane, BorderLayout.CENTER);
    }
    
    private void createBottomPanel() {
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        bottomPanel.setBackground(Color.WHITE);
        bottomPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 20, 20));
        
        // Add pagination or status info here if needed
        
        add(bottomPanel, BorderLayout.SOUTH);
    }
    
    
    private void styleButton(JButton button, Color backgroundColor) {
        button.setFont(new Font("Segoe UI", Font.BOLD, 13));
        button.setForeground(Color.WHITE);
        button.setBackground(backgroundColor);
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setPreferredSize(new Dimension(120, 35));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        // Add hover effect
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(backgroundColor.darker());
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(backgroundColor);
            }
        });
    }
    
    private void loadData() {
        model.setRowCount(0);
        List<Thuoc> dsThuoc = bus.getAll();
        if (dsThuoc != null) {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            for (Thuoc t : dsThuoc) {
                Object[] row = {
                    "",
                    t.getMaThuoc(),
                    t.getTenThuoc(),
                    t.getDonViTinh(),
                    t.getSoLuongTonKho(),
                    String.format("%,.0f", t.getGiaBan()),
                    t.getNgaySanXuat() != null ? sdf.format(t.getNgaySanXuat()) : "",
                    t.getHanSuDung(),
                    t.getXuatXu(),
                    t.getMaNhaSanXuat()
                };
                model.addRow(row);
            }
            
            // If there are rows, select the first one by default
            if (model.getRowCount() > 0) {
                table.setRowSelectionInterval(0, 0);
            }
        }
    }

    private void addSampleData() {
        // Add some sample data to the table
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        Object[][] data = {
            {"", "T001", "Paracetamol", "Viên", 1000, "5,000", "01/01/2024", "365 ngày", "Việt Nam", "NSX001", null},
            {"", "T002", "Vitamin C", "Viên", 500, "3,000", "15/01/2024", "730 ngày", "Mỹ", "NSX002", null},
            {"", "T003", "Amoxicillin", "Hộp", 200, "25,000", "20/01/2024", "365 ngày", "Pháp", "NSX003", null},
            {"", "T004", "Omeprazole", "Viên", 300, "8,000", "10/01/2024", "548 ngày", "Đức", "NSX001", null},
            {"", "T005", "Cetirizine", "Vỉ", 150, "12,000", "05/01/2024", "730 ngày", "Anh", "NSX002", null}
        };
        
        for (Object[] row : data) {
            model.addRow(row);
        }
    }

    private void openForm(Thuoc t) {
        JTextField ma = new JTextField(t != null ? t.getMaThuoc() : "");
        JTextField ten = new JTextField(t != null ? t.getTenThuoc() : "");
        JTextField dvt = new JTextField(t != null ? t.getDonViTinh() : "");
        JTextField sl = new JTextField(t != null ? String.valueOf(t.getSoLuongTonKho()) : "");
        JTextField gia = new JTextField(t != null ? String.format("%,.0f", t.getGiaBan()) : "");
        
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        JTextField nsx = new JTextField(t != null && t.getNgaySanXuat() != null ? 
            sdf.format(t.getNgaySanXuat()) : "");
        JTextField hsd = new JTextField(t != null ? String.valueOf(t.getHanSuDung()) : "");
            
        JTextField xuatXu = new JTextField(t != null ? t.getXuatXu() : "");
        JTextField maNSX = new JTextField(t != null ? t.getMaNhaSanXuat() : "");
        JTextField linkAnh = new JTextField(t != null ? t.getLinkAnh() : "");

        if (t != null) ma.setEnabled(false);

        Object[] input = {
            "Mã thuốc:", ma,
            "Tên thuốc:", ten,
            "Đơn vị tính:", dvt,
            "Số lượng tồn:", sl,
            "Giá bán:", gia,
            "Ngày sản xuất (dd/MM/yyyy):", nsx,
            "Hạn sử dụng (số ngày):", hsd,
            "Xuất xứ:", xuatXu,
            "Mã nhà sản xuất:", maNSX,
            "Link ảnh:", linkAnh
        };

        int result = JOptionPane.showConfirmDialog(this, input, 
            t == null ? "Thêm thuốc" : "Sửa thuốc", 
            JOptionPane.OK_CANCEL_OPTION);
            
        if (result == JOptionPane.OK_OPTION) {
            try {
                // Create new Thuoc object with all fields
                Date ngaySX = null;
                if (!nsx.getText().isEmpty()) {
                    ngaySX = sdf.parse(nsx.getText());
                }

                int hanSD = 0;
                if (!hsd.getText().isEmpty()) {
                    hanSD = Integer.parseInt(hsd.getText());
                }

                double giaBan = Double.parseDouble(gia.getText().replace(",", ""));
                int soLuong = Integer.parseInt(sl.getText());

                Thuoc thuoc = new Thuoc(
                    ma.getText(),
                    ten.getText(),
                    giaBan,
                    soLuong,
                    ngaySX,
                    hanSD,
                    linkAnh.getText(),
                    maNSX.getText(),
                    dvt.getText(),
                    xuatXu.getText()
                );

                boolean success = (t == null) ? bus.themMoi(thuoc) : bus.capNhat(thuoc);
                if (success) {
                    loadData();
                    JOptionPane.showMessageDialog(this, 
                        (t == null ? "Thêm" : "Sửa") + " thành công!");
                } else {
                    JOptionPane.showMessageDialog(this, 
                        (t == null ? "Thêm" : "Sửa") + " thất bại!");
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, 
                    "Dữ liệu không hợp lệ!\nLỗi: " + ex.getMessage());
            }
        }
    }

    private Thuoc getThuocFromRow(int row) {
        try {
            if (row < 0 || row >= model.getRowCount()) {
                return null;
            }

            String ma = model.getValueAt(row, 1).toString();
            String ten = model.getValueAt(row, 2).toString();
            String dvt = model.getValueAt(row, 3).toString();
            int sl = Integer.parseInt(model.getValueAt(row, 4).toString());
            double gia = Double.parseDouble(model.getValueAt(row, 5).toString().replace(",", ""));
            
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            Date nsx = null;
            String nsxStr = model.getValueAt(row, 6).toString();
            if (!nsxStr.isEmpty()) {
                nsx = sdf.parse(nsxStr);
            }
            
            int hsd = 0;
            String hsdStr = model.getValueAt(row, 7).toString();
            if (!hsdStr.isEmpty()) {
                hsd = Integer.parseInt(hsdStr);
            }
            
            String xuatXu = model.getValueAt(row, 8).toString();
            String maNSX = model.getValueAt(row, 9).toString();

            Thuoc thuoc = new Thuoc(
                ma, ten, gia, sl, nsx, hsd,
                "", // linkAnh - không hiển thị trong bảng
                maNSX, dvt, xuatXu
            );

            System.out.println("Selected medicine: " + thuoc.getMaThuoc() + " - " + thuoc.getTenThuoc());
            return thuoc;
        } catch (Exception ex) {
            ex.printStackTrace();
            System.err.println("Error getting medicine from row " + row + ": " + ex.getMessage());
            return null;
        }
    }

    public void showAddDialog() {
        openForm(null);
    }

    private void searchThuoc() {
        String keyword = txtSearch.getText().trim().toLowerCase();
        if (keyword.isEmpty()) {
            loadData();
            return;
        }

        model.setRowCount(0);
        List<Thuoc> dsThuoc = bus.getAll();
        if (dsThuoc != null) {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            for (Thuoc t : dsThuoc) {
                // Search in multiple fields
                if (t.getMaThuoc().toLowerCase().contains(keyword) ||
                    t.getTenThuoc().toLowerCase().contains(keyword) ||
                    t.getXuatXu().toLowerCase().contains(keyword) ||
                    t.getMaNhaSanXuat().toLowerCase().contains(keyword)) {
                    
                    Object[] row = {
                        "",
                        t.getMaThuoc(),
                        t.getTenThuoc(),
                        t.getDonViTinh(),
                        t.getSoLuongTonKho(),
                        String.format("%,.0f", t.getGiaBan()),
                        t.getNgaySanXuat() != null ? sdf.format(t.getNgaySanXuat()) : "",
                        t.getHanSuDung(),
                        t.getXuatXu(),
                        t.getMaNhaSanXuat()
                    };
                    model.addRow(row);
                }
            }
        }
    }

    private void showBuyDialog() {
        // Kiểm tra kết nối HoaDonBUS
        if (hoaDonBUS == null) {
            try {
                hoaDonBUS = new HoaDonBUS();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this,
                    "Lỗi kết nối đến cơ sở dữ liệu: " + e.getMessage(),
                    "Lỗi",
                    JOptionPane.ERROR_MESSAGE);
                e.printStackTrace();
                return;
            }
        }

        // Create buy dialog
        JDialog buyDialog = new JDialog((Frame)SwingUtilities.getWindowAncestor(this), true);
        buyDialog.setTitle("Mua thuốc");
        buyDialog.setLayout(new BorderLayout(10, 10));

        // Create info panel
        JPanel infoPanel = new JPanel(new GridLayout(7, 2, 5, 5));
        infoPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Get list of all medicines
        List<Thuoc> dsThuoc = bus.getAll();
        DefaultComboBoxModel<String> medicineModel = new DefaultComboBoxModel<>();
        Map<String, Thuoc> medicineMap = new HashMap<>();
        
        for (Thuoc t : dsThuoc) {
            medicineModel.addElement(t.getTenThuoc());
            medicineMap.put(t.getTenThuoc(), t);
        }

        // Tên thuốc combobox
        infoPanel.add(new JLabel("Tên thuốc:"));
        JComboBox<String> cboThuoc = new JComboBox<>(medicineModel);
        infoPanel.add(cboThuoc);

        // Đơn vị tính label
        infoPanel.add(new JLabel("Đơn vị tính:"));
        JLabel lblDonViTinh = new JLabel();
        infoPanel.add(lblDonViTinh);

        // Giá bán label
        infoPanel.add(new JLabel("Giá bán:"));
        JLabel lblGiaBan = new JLabel();
        infoPanel.add(lblGiaBan);

        // Số lượng tồn label
        infoPanel.add(new JLabel("Số lượng tồn:"));
        JLabel lblSoLuongTon = new JLabel();
        infoPanel.add(lblSoLuongTon);

        // Số lượng mua spinner
        infoPanel.add(new JLabel("Số lượng mua:"));
        SpinnerNumberModel spinnerModel = new SpinnerNumberModel(1, 1, 1000, 1);
        JSpinner spinnerSoLuong = new JSpinner(spinnerModel);
        infoPanel.add(spinnerSoLuong);

        // Thêm trường địa chỉ đặt hàng
        infoPanel.add(new JLabel("Địa chỉ đặt hàng:"));
        JTextField txtDiaChiDat = new JTextField();
        infoPanel.add(txtDiaChiDat);

        // Thêm trường địa chỉ giao hàng
        infoPanel.add(new JLabel("Địa chỉ giao hàng:"));
        JTextField txtDiaChiGiao = new JTextField();
        infoPanel.add(txtDiaChiGiao);

        // Add change listener for combobox
        cboThuoc.addActionListener(e -> {
            String selectedName = (String) cboThuoc.getSelectedItem();
            Thuoc selectedThuoc = medicineMap.get(selectedName);
            if (selectedThuoc != null) {
                lblDonViTinh.setText(selectedThuoc.getDonViTinh());
                lblGiaBan.setText(String.format("%,.0f đ", selectedThuoc.getGiaBan()));
                lblSoLuongTon.setText(String.valueOf(selectedThuoc.getSoLuongTonKho()));
                spinnerModel.setMaximum(selectedThuoc.getSoLuongTonKho());
                
                // Reset spinner value if it's higher than new max
                if ((int)spinnerSoLuong.getValue() > selectedThuoc.getSoLuongTonKho()) {
                    spinnerSoLuong.setValue(1);
                }
            }
        });

        // Trigger initial update
        if (cboThuoc.getItemCount() > 0) {
            // If there was a selected medicine, select it in the combo box
            if (selectedThuoc != null) {
                cboThuoc.setSelectedItem(selectedThuoc.getTenThuoc());
            } else {
                cboThuoc.setSelectedIndex(0);
            }
        }

        // Create button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        JButton btnConfirm = new JButton("Xác nhận");
        JButton btnCancel = new JButton("Hủy");

        styleButton(btnConfirm, primaryColor);
        styleButton(btnCancel, new Color(231, 76, 60));

        btnConfirm.addActionListener(e -> {
            String selectedName = (String) cboThuoc.getSelectedItem();
            Thuoc selectedThuoc = medicineMap.get(selectedName);
            int soLuongMua = (int) spinnerSoLuong.getValue();
            
            if (selectedThuoc != null) {
                if (soLuongMua > selectedThuoc.getSoLuongTonKho()) {
                    JOptionPane.showMessageDialog(buyDialog,
                        "Số lượng mua vượt quá số lượng hiện có!",
                        "Lỗi",
                        JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Validate địa chỉ
                String diaChiDat = txtDiaChiDat.getText().trim();
                String diaChiGiao = txtDiaChiGiao.getText().trim();
                
                if (diaChiDat.isEmpty() || diaChiGiao.isEmpty()) {
                    JOptionPane.showMessageDialog(buyDialog,
                        "Vui lòng nhập đầy đủ địa chỉ đặt hàng và địa chỉ giao hàng!",
                        "Lỗi",
                        JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Tạo mã hóa đơn mới
                String maHD = generateNewMaHD();
                
                // Tạo hóa đơn mới
                HoaDon hoaDon = new HoaDon(
                    maHD,
                    new java.sql.Date(System.currentTimeMillis()),
                    currentUser.getMaUser(),
                    diaChiDat,
                    diaChiGiao
                );

                try {
                    // Lưu hóa đơn
                    if (hoaDonBUS.them(hoaDon)) {
                        // Tạo chi tiết hóa đơn
                        ChiTietHoaDon chiTiet = new ChiTietHoaDon(
                            maHD,
                            selectedThuoc.getMaThuoc(),
                            selectedThuoc.getTenThuoc(),
                            soLuongMua
                        );

                        // Lưu chi tiết hóa đơn
                        if (chiTietHoaDonBUS.them(chiTiet)) {
                            // Cập nhật số lượng tồn kho
                            int soLuongMoi = selectedThuoc.getSoLuongTonKho() - soLuongMua;
                            if (bus.capNhatSoLuong(selectedThuoc.getMaThuoc(), soLuongMoi)) {
                                double tongTien = selectedThuoc.getGiaBan() * soLuongMua;
                                String message = String.format(
                                    "Đã mua thành công:\n" +
                                    "- Mã hóa đơn: %s\n" +
                                    "- Số lượng: %d %s\n" +
                                    "- Tên thuốc: %s\n" +
                                    "- Tổng tiền: %,.0f đ\n" +
                                    "- Địa chỉ đặt: %s\n" +
                                    "- Địa chỉ giao: %s",
                                    maHD,
                                    soLuongMua,
                                    selectedThuoc.getDonViTinh(),
                                    selectedThuoc.getTenThuoc(),
                                    tongTien,
                                    diaChiDat,
                                    diaChiGiao
                                );
                                JOptionPane.showMessageDialog(buyDialog,
                                    message,
                                    "Thành công",
                                    JOptionPane.INFORMATION_MESSAGE);
                                
                                // Refresh data
                                loadData();
                                buyDialog.dispose();
                            } else {
                                JOptionPane.showMessageDialog(buyDialog,
                                    "Lỗi cập nhật số lượng tồn kho!",
                                    "Lỗi",
                                    JOptionPane.ERROR_MESSAGE);
                            }
                        } else {
                            JOptionPane.showMessageDialog(buyDialog,
                                "Lỗi tạo chi tiết hóa đơn!",
                                "Lỗi",
                                JOptionPane.ERROR_MESSAGE);
                        }
                    } else {
                        JOptionPane.showMessageDialog(buyDialog,
                            "Lỗi tạo hóa đơn!",
                            "Lỗi",
                            JOptionPane.ERROR_MESSAGE);
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(buyDialog,
                        "Lỗi xử lý: " + ex.getMessage(),
                        "Lỗi",
                        JOptionPane.ERROR_MESSAGE);
                    ex.printStackTrace();
                }
            }
        });

        btnCancel.addActionListener(e -> buyDialog.dispose());

        buttonPanel.add(btnConfirm);
        buttonPanel.add(btnCancel);

        // Add panels to dialog
        buyDialog.add(infoPanel, BorderLayout.CENTER);
        buyDialog.add(buttonPanel, BorderLayout.SOUTH);

        // Set dialog size and location
        buyDialog.setSize(400, 500);
        buyDialog.setLocationRelativeTo(this);
        buyDialog.setVisible(true);
    }

    private String generateNewMaHD() {
        List<HoaDon> dsHoaDon = hoaDonBUS.getAll();
        int maxNumber = 0;
        
        for (HoaDon hd : dsHoaDon) {
            String maHD = hd.getMaHD();
            if (maHD != null && maHD.startsWith("HD")) {
                try {
                    int number = Integer.parseInt(maHD.substring(2));
                    maxNumber = Math.max(maxNumber, number);
                } catch (NumberFormatException e) {
                    // Ignore invalid format
                }
            }
        }
        
        return String.format("HD%08d", maxNumber + 1);
    }

    private void addAdminButtonHandlers() {
        // Add new medicine
        btnAdd.addActionListener(e -> {
            openForm(null);
        });

        // Edit medicine
        btnEdit.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow < 0) {
                JOptionPane.showMessageDialog(this,
                    "Vui lòng chọn thuốc cần sửa!",
                    "Thông báo",
                    JOptionPane.WARNING_MESSAGE);
                return;
            }
            
            Thuoc selectedThuoc = getThuocFromRow(selectedRow);
            if (selectedThuoc != null) {
                openForm(selectedThuoc);
            } else {
                JOptionPane.showMessageDialog(this,
                    "Không thể lấy thông tin thuốc!",
                    "Lỗi",
                    JOptionPane.ERROR_MESSAGE);
            }
        });

        // Delete medicine
        btnDelete.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow < 0) {
                JOptionPane.showMessageDialog(this,
                    "Vui lòng chọn thuốc cần xóa!",
                    "Thông báo",
                    JOptionPane.WARNING_MESSAGE);
                return;
            }

            String maThuoc = model.getValueAt(selectedRow, 1).toString();
            String tenThuoc = model.getValueAt(selectedRow, 2).toString();

            int confirm = JOptionPane.showConfirmDialog(this,
                "Bạn có chắc chắn muốn xóa thuốc " + tenThuoc + " (" + maThuoc + ")?",
                "Xác nhận xóa",
                JOptionPane.YES_NO_OPTION);

            if (confirm == JOptionPane.YES_OPTION) {
                boolean success = bus.xoa(maThuoc);
                if (success) {
                    model.removeRow(selectedRow);
                    JOptionPane.showMessageDialog(this,
                        "Xóa thuốc thành công!",
                        "Thông báo",
                        JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(this,
                        "Xóa thuốc thất bại!",
                        "Lỗi",
                        JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        // Refresh button
        btnRefresh.addActionListener(e -> {
            txtSearch.setText("");
            loadData();
        });
    }

    private void showOrderDetailsDialog() {
        // Kiểm tra kết nối HoaDonBUS
        if (hoaDonBUS == null) {
            try {
                hoaDonBUS = new HoaDonBUS();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this,
                    "Lỗi kết nối đến cơ sở dữ liệu: " + e.getMessage(),
                    "Lỗi",
                    JOptionPane.ERROR_MESSAGE);
                e.printStackTrace();
                return;
            }
        }

        JDialog dialog = new JDialog((Frame)SwingUtilities.getWindowAncestor(this), "Chi tiết đơn hàng", true);
        dialog.setLayout(new BorderLayout(10, 10));
        dialog.setBackground(Color.WHITE);

        // Create table model for orders
        String[] columns = {"Mã HĐ", "Ngày tạo", "Tên thuốc", "Số lượng", "Đơn giá", "Thành tiền", "Địa chỉ giao"};
        DefaultTableModel model = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        JTable table = new JTable(model);
        TableUtils.setTableStyle(table);

        // Get user's orders
        List<HoaDon> userOrders = hoaDonBUS.getByUser(currentUser);
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");

        // For each order, get its details
        for (HoaDon hd : userOrders) {
            List<ChiTietHoaDon> details = chiTietHoaDonBUS.getByHoaDon(hd.getMaHD());
            
            for (ChiTietHoaDon detail : details) {
                Thuoc thuoc = bus.getByMa(detail.getMaThuoc());
                if (thuoc != null) {
                    double donGia = thuoc.getGiaBan();
                    double thanhTien = donGia * detail.getSoLuong();
                    
                    Object[] row = {
                        hd.getMaHD(),
                        sdf.format(hd.getNgayTao()),
                        detail.getTenThuoc(),
                        detail.getSoLuong(),
                        String.format("%,.0f đ", donGia),
                        String.format("%,.0f đ", thanhTien),
                        hd.getDiaChiGiaoHang()
                    };
                    model.addRow(row);
                }
            }
        }

        // Add table to scroll pane
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Add close button
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.setBackground(Color.WHITE);
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(0, 10, 10, 10));

        JButton btnClose = new JButton("Đóng");
        styleButton(btnClose, new Color(231, 76, 60));
        btnClose.addActionListener(e -> dialog.dispose());
        buttonPanel.add(btnClose);

        // Add components to dialog
        dialog.add(scrollPane, BorderLayout.CENTER);
        dialog.add(buttonPanel, BorderLayout.SOUTH);

        // Set dialog size and location
        dialog.setSize(900, 500);
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }
}
