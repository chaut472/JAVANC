/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gui;

/**
 *
 * @author Cao Thi Han
 */


import bus.KhachHangBUS;
import entity.KhachHang;
import entity.User;
import utils.TableUtils;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.util.List;
import java.text.SimpleDateFormat;
import java.util.Date;

public class KhachHangGUI extends JPanel {
    private KhachHangBUS bus = new KhachHangBUS();
    private JTable table;
    private DefaultTableModel model;
    private JTextField txtSearch;
    private Color primaryColor = new Color(41, 128, 185);
    private Color secondaryColor = new Color(52, 152, 219);
    private User currentUser;
    public KhachHangGUI(User user) {
        this.currentUser= user;
        setLayout(new BorderLayout());
        setBackground(Color.WHITE);
        
        // Create top panel
        createTopPanel();
        
        // Create table
        createTable();
        
        // Create bottom panel
        createBottomPanel();
    }
    
    private void createTopPanel() {
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBackground(Color.WHITE);
        topPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Title and search panel
        JPanel titleSearchPanel = new JPanel(new BorderLayout(20, 0));
        titleSearchPanel.setBackground(Color.WHITE);
        
        // Title
        JLabel titleLabel = new JLabel("Quản Lý Khách Hàng");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        titleLabel.setForeground(new Color(44, 62, 80));
        
        // Search panel
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchPanel.setBackground(Color.WHITE);
        
        txtSearch = new JTextField(20);
        txtSearch.setPreferredSize(new Dimension(200, 35));
        txtSearch.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(189, 195, 199)),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        
        JButton btnSearch = new JButton("Tìm kiếm");
        styleButton(btnSearch, primaryColor);
        if("ADMIN".equalsIgnoreCase(currentUser.getVaiTro())){
             searchPanel.add(txtSearch);
             searchPanel.add(btnSearch);
        }
       
        
        titleSearchPanel.add(titleLabel, BorderLayout.WEST);
        titleSearchPanel.add(searchPanel, BorderLayout.EAST);
        
        // Action buttons panel
        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        actionPanel.setBackground(Color.WHITE);
        actionPanel.setBorder(BorderFactory.createEmptyBorder(20, 0, 0, 0));
        
        JButton btnAdd = new JButton("Thêm khách hàng");
        JButton btnEdit = new JButton("Sửa");
        JButton btnDelete = new JButton("Xóa");
        JButton btnRefresh = new JButton("Làm mới");
        
        styleButton(btnAdd, primaryColor);
        styleButton(btnEdit, secondaryColor);
        styleButton(btnDelete, new Color(231, 76, 60));
        styleButton(btnRefresh, new Color(46, 204, 113));
           
       
       
       
       
//         if("ADMIN".equalsIgnoreCase(currentUser.getVaiTro())){
//             searchPanel.add(txtSearch);
//             searchPanel.add(btnSearch);
//        }
//        actionPanel.add(btnRefresh);
//        
//        topPanel.add(titleSearchPanel, BorderLayout.NORTH);
//        topPanel.add(actionPanel, BorderLayout.CENTER);
//        
//        add(topPanel, BorderLayout.NORTH);
//        
//        // Add action listeners
//        btnAdd.addActionListener(e -> openForm(null));
//        btnEdit.addActionListener(e -> {
//            int row = table.getSelectedRow();
//            if (row >= 0) {
//                KhachHang kh = getKhachHangFromRow(row);
//                if (kh != null) openForm(kh);
//                } else {
//                JOptionPane.showMessageDialog(this, "Vui lòng chọn khách hàng cần sửa!");
//            }
//        });
//        btnDelete.addActionListener(e -> {
//            int row = table.getSelectedRow();
//            if (row >= 0) {
//                String maKH = table.getValueAt(row, 1).toString();
//                int confirm = JOptionPane.showConfirmDialog(this, 
//                    "Bạn có chắc muốn xóa khách hàng này?", 
//                    "Xác nhận xóa", 
//                    JOptionPane.YES_NO_OPTION);
//                if (confirm == JOptionPane.YES_OPTION) {
//                    if (bus.xoa(maKH)) {
//                        loadData();
//                        JOptionPane.showMessageDialog(this, "Xóa thành công!");
//                    } else {
//                        JOptionPane.showMessageDialog(this, "Xóa thất bại!");
//                    }
//                }
//            } else {
//                JOptionPane.showMessageDialog(this, "Vui lòng chọn khách hàng cần xóa!");
//            }
//        });
//        btnRefresh.addActionListener(e -> loadData());
//        
//        // Add search functionality
//        txtSearch.addKeyListener(new KeyAdapter() {
//            @Override
//            public void keyReleased(KeyEvent e) {
//                String searchText = txtSearch.getText().toLowerCase();
//                filterTable(searchText);
//            }
//        });
//    }
// Add action listeners
        if ("ADMIN".equalsIgnoreCase(currentUser.getVaiTro())) {
            btnAdd.addActionListener(e -> openForm(null));
            btnDelete.addActionListener(e -> {
                int row = table.getSelectedRow();
                if (row >= 0) {
                    String maKH = table.getValueAt(row, 1).toString();
                    int confirm = JOptionPane.showConfirmDialog(this, 
                        "Bạn có chắc muốn xóa khách hàng này?", 
                        "Xác nhận xóa", 
                        JOptionPane.YES_NO_OPTION);
                    if (confirm == JOptionPane.YES_OPTION) {
                        if (bus.xoa(maKH)) {
                            loadData();
                            JOptionPane.showMessageDialog(this, "Xóa thành công!");
                        } else {
                            JOptionPane.showMessageDialog(this, "Xóa thất bại!");
                        }
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "Vui lòng chọn khách hàng cần xóa!");
                }
            });
        }

        btnRefresh.addActionListener(e -> loadData());
        
        // Add search functionality only for admin
        if ("ADMIN".equalsIgnoreCase(currentUser.getVaiTro())) {
            txtSearch.addKeyListener(new KeyAdapter() {
                @Override
                public void keyReleased(KeyEvent e) {
                    String searchText = txtSearch.getText().toLowerCase();
                    filterTable(searchText);
                }
            });
        }
    }
//    
    private void createTable() {
        // Create table model with columns
        String[] columns = {
            "", "Mã KH", "Họ Tên", "Địa Chỉ", "Tài Khoản", "Mật Khẩu", 
            "Số Điện Thoại", "Ngày Sinh", "Email", "Thao Tác"
        };
        model = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 9; // Only action column is editable
            }
        };
        
        // Create table
        table = new JTable(model);
        
        // Apply modern styling
        TableUtils.setTableStyle(table);
        
        // Add icon column for customer
        TableUtils.addIconColumn(table, 0, "/images/customer_small.png", 24);
        
        // Add action buttons column
        TableUtils.addButtonColumn(table, 9, "Chi tiết", primaryColor);
        
        // Create scroll pane
        JScrollPane scrollPane = new JScrollPane(table);
        TableUtils.setupTableScrollPane(scrollPane);
        
        // Load actual data
                    loadData();
        
        add(scrollPane, BorderLayout.CENTER);
    }
    
    private void createBottomPanel() {
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        bottomPanel.setBackground(Color.WHITE);
        bottomPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 20, 20));
        
        add(bottomPanel, BorderLayout.SOUTH);
    }
    
    private void styleButton(JButton button, Color backgroundColor) {
        button.setFont(new Font("Segoe UI", Font.BOLD, 13));
        button.setForeground(Color.WHITE);
        button.setBackground(backgroundColor);
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setPreferredSize(new Dimension(120, 35));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        // Add hover effect
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(backgroundColor.darker());
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(backgroundColor);
            }
        });
    }

   private void loadData() {
        model.setRowCount(0);
        // Always get all customers
        List<KhachHang> list = bus.getAll();
        
        if (list != null) {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            for (KhachHang kh : list) {
                // For non-admin users, highlight their own information
                boolean isOwnInfo = !("ADMIN".equalsIgnoreCase(currentUser.getVaiTro())) && 
                                  kh.getMaKhachHang().equals(currentUser.getMaUser());
                
                Object[] rowData = {
                    "", 
                    kh.getMaKhachHang(),
                    kh.getTenKhachHang(),
                    kh.getDiaChi(),
                    kh.getTenDangNhap(),
                    "••••••••",  // Hide password
                    kh.getSoDienThoai(),
                    kh.getNgaySinh() != null ? sdf.format(kh.getNgaySinh()) : "",
                    kh.getEmail()
                };
                
                model.addRow(rowData);
                
                // Highlight user's own information
                if (isOwnInfo) {
                    int row = model.getRowCount() - 1;
                    for (int col = 1; col < model.getColumnCount(); col++) { // Skip icon column
                        table.setValueAt("➤ " + table.getValueAt(row, col), row, col);
                    }
                }
            }
        }
    }
    
    private void filterTable(String searchText) {
        model.setRowCount(0);
        List<KhachHang> list = bus.getAll();
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        for (KhachHang kh : list) {
            if (kh.getTenKhachHang().toLowerCase().contains(searchText) ||
                kh.getMaKhachHang().toLowerCase().contains(searchText) ||
                kh.getSoDienThoai().contains(searchText)) {
                model.addRow(new Object[]{
                    "", 
                    kh.getMaKhachHang(),
                    kh.getTenKhachHang(),
                    kh.getDiaChi(),
                    kh.getTenDangNhap(),
                    "••••••••",  // Hide password
                    kh.getSoDienThoai(),
                    kh.getNgaySinh() != null ? sdf.format(kh.getNgaySinh()) : "",
                    kh.getEmail(),
                    null
                });
            }
        }
    }

    private void openForm(KhachHang kh) {
        JTextField ma = new JTextField(kh != null ? kh.getMaKhachHang() : "");
        JTextField ten = new JTextField(kh != null ? kh.getTenKhachHang() : "");
        JTextField diaChi = new JTextField(kh != null ? kh.getDiaChi() : "");
        JTextField tenDangNhap = new JTextField(kh != null ? kh.getTenDangNhap() : "");
        JPasswordField matKhau = new JPasswordField(kh != null ? kh.getMatKhau() : "");
        JTextField sdt = new JTextField(kh != null ? kh.getSoDienThoai() : "");
        JTextField email = new JTextField(kh != null ? kh.getEmail() : "");
        
        // Date spinner for birth date
        SpinnerDateModel dateModel = new SpinnerDateModel();
        JSpinner ngaySinh = new JSpinner(dateModel);
        JSpinner.DateEditor dateEditor = new JSpinner.DateEditor(ngaySinh, "dd/MM/yyyy");
        ngaySinh.setEditor(dateEditor);
        if (kh != null && kh.getNgaySinh() != null) {
            ngaySinh.setValue(kh.getNgaySinh());
        }

        if (kh != null) ma.setEnabled(false);

        Object[] input = {
            "Mã khách hàng:", ma,
            "Họ tên:", ten,
            "Địa chỉ:", diaChi,
            "Tài khoản:", tenDangNhap,
            "Mật khẩu:", matKhau,
            "Số điện thoại:", sdt,
            "Ngày sinh:", ngaySinh,
            "Email:", email
        };

        int result = JOptionPane.showConfirmDialog(this, input, 
            kh == null ? "Thêm khách hàng" : "Sửa khách hàng", 
            JOptionPane.OK_CANCEL_OPTION);
            
        if (result == JOptionPane.OK_OPTION) {
            try {
                KhachHang khachHang = new KhachHang(
                    ma.getText(),
                    ten.getText(),
                    diaChi.getText(),
                    tenDangNhap.getText(),
                    new String(matKhau.getPassword()),
                    sdt.getText(),
                    (Date) ngaySinh.getValue(),
                    email.getText()
                );

                boolean success = (kh == null) ? bus.them(khachHang) : bus.sua(khachHang);
                if (success) {
                    loadData();
                    JOptionPane.showMessageDialog(this, 
                        (kh == null ? "Thêm" : "Sửa") + " thành công!");
                } else {
                    JOptionPane.showMessageDialog(this, 
                        (kh == null ? "Thêm" : "Sửa") + " thất bại!");
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Dữ liệu không hợp lệ!");
                ex.printStackTrace();
            }
        }
    }

    private KhachHang getKhachHangFromRow(int row) {
        try {
            String ma = model.getValueAt(row, 1).toString();
            String ten = model.getValueAt(row, 2).toString();
            String diaChi = model.getValueAt(row, 3).toString();
            String tenDangNhap = model.getValueAt(row, 4).toString();
            String matKhau = ""; // We don't show the actual password in the table
            String sdt = model.getValueAt(row, 6).toString();
            Date ngaySinh = new SimpleDateFormat("dd/MM/yyyy").parse(model.getValueAt(row, 7).toString());
            String email = model.getValueAt(row, 8).toString();

            return new KhachHang(ma, ten, diaChi, tenDangNhap, matKhau, sdt, ngaySinh, email);
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }
}
