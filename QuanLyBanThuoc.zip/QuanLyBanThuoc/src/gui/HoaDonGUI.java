/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gui;

/**
 *
 * @author Cao Thi Han
 */
import bus.HoaDonBUS;
import entity.HoaDon;
import entity.User;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Date;
import java.sql.SQLException;
import java.util.List;
import java.util.ArrayList;


public class HoaDonGUI extends JPanel {
    private JTable table;
    private DefaultTableModel model;
    private HoaDonBUS bus;
    private User currentUser;
    public HoaDonGUI(User user) {
                this.currentUser = user;
        setLayout(new BorderLayout(10, 10));

        // Table + Model
        model = new DefaultTableModel(new String[]{"Mã HĐ", "Ngày Tạo", "Mã KH", "Địa Chỉ Đặt", "Địa Chỉ Giao"}, 0);
        table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);

        // Button Panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));

        JButton btnThem = new JButton("Thêm");
        JButton btnSua = new JButton("Sửa");
        JButton btnXoa = new JButton("Xóa");
        JButton btnTaiLai = new JButton("Tải lại");

        buttonPanel.add(btnThem);
        buttonPanel.add(btnSua);
        buttonPanel.add(btnXoa);
        buttonPanel.add(btnTaiLai);

        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        // Initialize BUS
        try {
            bus = new HoaDonBUS();
            // Load data
            loadData();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, 
                "Lỗi kết nối database: " + e.getMessage(), 
                "Lỗi", 
                JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }

        // Add new HoaDon
        btnThem.addActionListener(e -> {
            if (bus == null) {
                JOptionPane.showMessageDialog(this, "Không thể kết nối đến database!");
                return;
            }
            
            JTextField maHD = new JTextField();
            JTextField ngay = new JTextField();
            JTextField maKH = new JTextField();
            JTextField dcDat = new JTextField();
            JTextField dcGiao = new JTextField();
            Object[] input = {
                    "Mã HĐ:", maHD,
                    "Ngày tạo (yyyy-mm-dd):", ngay,
                    "Mã KH:", maKH,
                    "Địa chỉ đặt:", dcDat,
                    "Địa chỉ giao:", dcGiao
            };
            int result = JOptionPane.showConfirmDialog(this, input, "Thêm Hóa Đơn", JOptionPane.OK_CANCEL_OPTION);
            if (result == JOptionPane.OK_OPTION) {
                // Validate input
                String maHDText = maHD.getText().trim();
                String ngayText = ngay.getText().trim();
                String maKHText = maKH.getText().trim();
                String dcDatText = dcDat.getText().trim();
                String dcGiaoText = dcGiao.getText().trim();
                
                if (maHDText.isEmpty() || ngayText.isEmpty() || maKHText.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Vui lòng nhập đầy đủ thông tin bắt buộc (Mã HĐ, Ngày tạo, Mã KH)!");
                    return;
                }
                
                try {
                    HoaDon hd = new HoaDon(
                            maHDText,
                            Date.valueOf(ngayText),
                            maKHText,
                            dcDatText,
                            dcGiaoText
                    );
                    if (bus.them(hd)) {
                        JOptionPane.showMessageDialog(this, "Thêm thành công!");
                        loadData();
                    } else {
                        JOptionPane.showMessageDialog(this, "Thêm thất bại!");
                    }
                } catch (IllegalArgumentException ex) {
                    JOptionPane.showMessageDialog(this, "Định dạng ngày không hợp lệ! Vui lòng nhập theo định dạng yyyy-mm-dd");
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(this, "Lỗi nhập dữ liệu: " + ex.getMessage());
                    ex.printStackTrace();
                }
            }
        });

        // Edit HoaDon
        btnSua.addActionListener(e -> {
            if (bus == null) {
                JOptionPane.showMessageDialog(this, "Không thể kết nối đến database!");
                return;
            }
            
            int row = table.getSelectedRow();
            if (row >= 0) {
                String oldMaHD = model.getValueAt(row, 0).toString();
                JTextField maHD = new JTextField(oldMaHD);
                JTextField ngay = new JTextField(model.getValueAt(row, 1).toString());
                JTextField maKH = new JTextField(model.getValueAt(row, 2).toString());
                JTextField dcDat = new JTextField(model.getValueAt(row, 3) != null ? model.getValueAt(row, 3).toString() : "");
                JTextField dcGiao = new JTextField(model.getValueAt(row, 4) != null ? model.getValueAt(row, 4).toString() : "");

                maHD.setEditable(false); // Disable editing of the HoaDon ID

                Object[] input = {
                        "Mã HĐ:", maHD,
                        "Ngày tạo (yyyy-mm-dd):", ngay,
                        "Mã KH:", maKH,
                        "Địa chỉ đặt:", dcDat,
                        "Địa chỉ giao:", dcGiao
                };
                int result = JOptionPane.showConfirmDialog(this, input, "Sửa Hóa Đơn", JOptionPane.OK_CANCEL_OPTION);
                if (result == JOptionPane.OK_OPTION) {
                    // Validate input
                    String maHDText = maHD.getText().trim();
                    String ngayText = ngay.getText().trim();
                    String maKHText = maKH.getText().trim();
                    String dcDatText = dcDat.getText().trim();
                    String dcGiaoText = dcGiao.getText().trim();
                    
                    if (maHDText.isEmpty() || ngayText.isEmpty() || maKHText.isEmpty()) {
                        JOptionPane.showMessageDialog(this, "Vui lòng nhập đầy đủ thông tin bắt buộc (Mã HĐ, Ngày tạo, Mã KH)!");
                        return;
                    }
                    
                    try {
                        HoaDon hd = new HoaDon(
                                maHDText,
                                Date.valueOf(ngayText),
                                maKHText,
                                dcDatText,
                                dcGiaoText
                        );
                        if (bus.sua(hd)) {
                            JOptionPane.showMessageDialog(this, "Sửa thành công!");
                            loadData();
                        } else {
                            JOptionPane.showMessageDialog(this, "Sửa thất bại!");
                        }
                    } catch (IllegalArgumentException ex) {
                        JOptionPane.showMessageDialog(this, "Định dạng ngày không hợp lệ! Vui lòng nhập theo định dạng yyyy-mm-dd");
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(this, "Lỗi nhập dữ liệu: " + ex.getMessage());
                        ex.printStackTrace();
                    }
                }
            } else {
                JOptionPane.showMessageDialog(this, "Vui lòng chọn hóa đơn để sửa.");
            }
        });

        // Delete HoaDon
        btnXoa.addActionListener(e -> {
            if (bus == null) {
                JOptionPane.showMessageDialog(this, "Không thể kết nối đến database!");
                return;
            }
            
            int row = table.getSelectedRow();
            if (row >= 0) {
                String ma = model.getValueAt(row, 0).toString();
                int confirm = JOptionPane.showConfirmDialog(this, "Xác nhận xoá hóa đơn " + ma + "?", "Xác nhận", JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    if (bus.xoa(ma)) {
                        JOptionPane.showMessageDialog(this, "Xoá thành công!");
                        loadData();
                    } else {
                        JOptionPane.showMessageDialog(this, "Xoá thất bại!");
                    }
                }
            } else {
                JOptionPane.showMessageDialog(this, "Vui lòng chọn hóa đơn để xoá.");
            }
        });
        
        // Reload data
        btnTaiLai.addActionListener(e -> {
            try {
                if (bus == null) {
                    bus = new HoaDonBUS();
                }
                loadData();
                JOptionPane.showMessageDialog(this, "Đã tải lại dữ liệu!");
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, 
                    "Lỗi kết nối database: " + ex.getMessage(), 
                    "Lỗi", 
                    JOptionPane.ERROR_MESSAGE);
                ex.printStackTrace();
            }
        });
    }
public void showAddDialog() {
        if (bus == null) {
            JOptionPane.showMessageDialog(this, "Không thể kết nối đến database!");
            return;
        }
        
        JTextField maHD = new JTextField();
        JTextField ngay = new JTextField(new java.text.SimpleDateFormat("yyyy-MM-dd").format(new java.util.Date()));
        JTextField maKH = new JTextField();
        JTextField dcDat = new JTextField();
        JTextField dcGiao = new JTextField();
        
        // For non-admin users, set and lock their own customer ID
        if (!"ADMIN".equalsIgnoreCase(currentUser.getVaiTro())) {
            maKH.setText(currentUser.getMaUser());
            maKH.setEditable(false);
        }
        
        Object[] input = {
            "Mã HĐ:", maHD,
            "Ngày tạo (yyyy-mm-dd):", ngay,
            "Mã KH:", maKH,
            "Địa chỉ đặt:", dcDat,
            "Địa chỉ giao:", dcGiao
        };
        
        int result = JOptionPane.showConfirmDialog(this, input, "Thêm Hóa Đơn", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            // Validate input
            String maHDText = maHD.getText().trim();
            String ngayText = ngay.getText().trim();
            String maKHText = maKH.getText().trim();
            String dcDatText = dcDat.getText().trim();
            String dcGiaoText = dcGiao.getText().trim();
            
            if (maHDText.isEmpty() || ngayText.isEmpty() || maKHText.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Vui lòng nhập đầy đủ thông tin bắt buộc (Mã HĐ, Ngày tạo, Mã KH)!");
                return;
            }
            
            try {
                HoaDon hd = new HoaDon(
                    maHDText,
                    Date.valueOf(ngayText),
                    maKHText,
                    dcDatText,
                    dcGiaoText
                );
                if (bus.them(hd)) {
                    JOptionPane.showMessageDialog(this, "Thêm thành công!");
                    loadData();
                } else {
                    JOptionPane.showMessageDialog(this, "Thêm thất bại!");
                }
            } catch (IllegalArgumentException ex) {
                JOptionPane.showMessageDialog(this, "Định dạng ngày không hợp lệ! Vui lòng nhập theo định dạng yyyy-mm-dd");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Lỗi nhập dữ liệu: " + ex.getMessage());
                ex.printStackTrace();
            }
        }
    }
    private void loadData() {
        model.setRowCount(0);
        if (bus == null) {
            return;
        }
        
        List<HoaDon> list = bus.getAll();
        if (list == null) {
            list = new ArrayList<>();
        }
        
        for (HoaDon hd : list) {
            model.addRow(new Object[]{
                    hd.getMaHD(),
                    hd.getNgayTao(),
                    hd.getMaKH(),
                    hd.getDiaChiDatHang(),
                    hd.getDiaChiGiaoHang()
            });
        }
    }
}
