package gui;

import bus.KhachHangBUS;
import entity.KhachHang;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;

public class DangKyGUI extends JDialog {
    private JTextField txtTenKhachHang, txtDiaChi, txtTenDangNhap, txtSoDienThoai, txtEmail;
    private JPasswordField txtMatKhau;
    private JSpinner spnNgaySinh;
    private JButton btnDangKy, btnHuy;
    private KhachHangBUS khachHangBUS;

    public DangKyGUI(Frame parent) {
        super(parent, "Đăng ký tài khoản", true);
        khachHangBUS = new KhachHangBUS();
        initUI();
    }

    private void initUI() {
        setLayout(new BorderLayout(10, 10));
        JPanel panel = new JPanel(new GridLayout(8, 2, 10, 10));

        panel.add(new JLabel("Tên khách hàng:"));
        txtTenKhachHang = new JTextField();
        panel.add(txtTenKhachHang);

        panel.add(new JLabel("Địa chỉ:"));
        txtDiaChi = new JTextField();
        panel.add(txtDiaChi);

        panel.add(new JLabel("Tên đăng nhập:"));
        txtTenDangNhap = new JTextField();
        panel.add(txtTenDangNhap);

        panel.add(new JLabel("Mật khẩu:"));
        txtMatKhau = new JPasswordField();
        panel.add(txtMatKhau);

        panel.add(new JLabel("Số điện thoại:"));
        txtSoDienThoai = new JTextField();
        panel.add(txtSoDienThoai);

        panel.add(new JLabel("Ngày sinh:"));
        spnNgaySinh = new JSpinner(new SpinnerDateModel());
        spnNgaySinh.setEditor(new JSpinner.DateEditor(spnNgaySinh, "dd/MM/yyyy"));
        panel.add(spnNgaySinh);

        panel.add(new JLabel("Email:"));
        txtEmail = new JTextField();
        panel.add(txtEmail);

        btnDangKy = new JButton("Đăng ký");
        btnHuy = new JButton("Hủy");
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        btnPanel.add(btnDangKy);
        btnPanel.add(btnHuy);

        add(panel, BorderLayout.CENTER);
        add(btnPanel, BorderLayout.SOUTH);

        btnDangKy.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                xuLyDangKy();
            }
        });

        btnHuy.addActionListener(e -> dispose());

        setSize(400, 350);
        setLocationRelativeTo(getParent());
    }

    private void xuLyDangKy() {
        try {
            String maKhachHang = khachHangBUS.taoMaKhachHangTuDong();
            String tenKhachHang = txtTenKhachHang.getText().trim();
            String diaChi = txtDiaChi.getText().trim();
            String tenDangNhap = txtTenDangNhap.getText().trim();
            String matKhau = new String(txtMatKhau.getPassword());
            String soDienThoai = txtSoDienThoai.getText().trim();
            Date ngaySinh = (Date) spnNgaySinh.getValue();
            String email = txtEmail.getText().trim();

            if (tenKhachHang.isEmpty() || diaChi.isEmpty() || tenDangNhap.isEmpty() || matKhau.isEmpty() || soDienThoai.isEmpty() || email.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Vui lòng nhập đầy đủ thông tin!");
                return;
            }

            KhachHang kh = new KhachHang(maKhachHang, tenKhachHang, diaChi, tenDangNhap, matKhau, soDienThoai, ngaySinh, email);
            boolean result = khachHangBUS.dangKy(kh);
            if (result) {
                JOptionPane.showMessageDialog(this, "Đăng ký thành công! Mã khách hàng: " + maKhachHang);
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Đăng ký thất bại!");
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Lỗi: " + ex.getMessage());
        }
    }
}
