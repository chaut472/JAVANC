/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gui;

import database.DatabaseConnection;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class DangNhapGUI extends JDialog {
    private String tenDangNhap;
    private boolean isAdmin;
    private JTextField txtTenDangNhap;
    private JPasswordField txtMatKhau;
    private JButton btnDangNhap;
    private JButton btnDangKy;
    private boolean loginSuccess = false;
    private String maUser;
    private Frame parentFrame;
    private Color primaryColor = new Color(41, 128, 185);
    private Color secondaryColor = new Color(52, 152, 219);
    private Color backgroundColor = new Color(245, 247, 250);
    private Font mainFont = new Font("Segoe UI", Font.PLAIN, 16);
    private Font titleFont = new Font("Segoe UI", Font.BOLD, 32);
    private Font subtitleFont = new Font("Segoe UI", Font.PLAIN, 18);
    private Font buttonFont = new Font("Segoe UI", Font.BOLD, 16);
    private Font labelFont = new Font("Segoe UI", Font.BOLD, 14);

    public DangNhapGUI(Frame parent) {
        super(parent, "Đăng nhập", true);
        this.parentFrame = parent;
        initUIComponents();
    }
public String getMaUser(){
        String maUser = null;
    return maUser;
}
    private void initUIComponents() {
        setSize(900, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        
        // Main panel with two sections
        JPanel mainPanel = new JPanel(new GridLayout(1, 2));
        mainPanel.setBackground(backgroundColor);
        
        // Left panel - Blue background with logo and title
        JPanel leftPanel = new JPanel(new GridBagLayout());
        leftPanel.setBackground(primaryColor);
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.insets = new Insets(20, 20, 20, 20);
        
        // Add logo
        ImageIcon logoIcon = new ImageIcon(getClass().getResource("/images/pharmacy_icon.png"));
        if (logoIcon.getImageLoadStatus() == MediaTracker.COMPLETE) {
            Image scaledImage = logoIcon.getImage().getScaledInstance(200, 200, Image.SCALE_SMOOTH);
            JLabel logoLabel = new JLabel(new ImageIcon(scaledImage));
            leftPanel.add(logoLabel, gbc);
        }
        
        // Add title
        JLabel titleLabel = new JLabel("QUẢN LÝ HIỆU THUỐC");
        titleLabel.setFont(titleFont);
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        leftPanel.add(titleLabel, gbc);
        
        // Add subtitle
        JLabel subtitleLabel = new JLabel("Chăm sóc sức khỏe - Tận tâm phục vụ");
        subtitleLabel.setFont(subtitleFont);
        subtitleLabel.setForeground(new Color(236, 240, 241));
        subtitleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        leftPanel.add(subtitleLabel, gbc);
        
        // Right panel - Login form
        JPanel rightPanel = new JPanel();
        rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.Y_AXIS));
        rightPanel.setBackground(backgroundColor);
        rightPanel.setBorder(new EmptyBorder(40, 60, 40, 60));
        
        // Login form panel with white background and shadow
        JPanel loginFormPanel = new JPanel();
        loginFormPanel.setLayout(new BoxLayout(loginFormPanel, BoxLayout.Y_AXIS));
        loginFormPanel.setBackground(Color.WHITE);
        loginFormPanel.setBorder(BorderFactory.createCompoundBorder(
            new SoftBevelBorder(SoftBevelBorder.RAISED, Color.WHITE, Color.LIGHT_GRAY),
            new EmptyBorder(25, 35, 25, 35)
        ));
        
        // Login title
        JLabel loginTitle = new JLabel("Đăng Nhập");
        loginTitle.setFont(new Font("Segoe UI", Font.BOLD, 28));
        loginTitle.setForeground(primaryColor);
        loginTitle.setAlignmentX(Component.CENTER_ALIGNMENT);
        loginFormPanel.add(loginTitle);
        
        loginFormPanel.add(Box.createVerticalStrut(25));
        
        // Input fields container
        JPanel inputContainer = new JPanel();
        inputContainer.setLayout(new BoxLayout(inputContainer, BoxLayout.Y_AXIS));
        inputContainer.setBackground(Color.WHITE);
        inputContainer.setMaximumSize(new Dimension(300, Integer.MAX_VALUE));
        
        // Username field panel
        JPanel usernamePanel = new JPanel(new BorderLayout(8, 4));
        usernamePanel.setBackground(Color.WHITE);
        usernamePanel.setBorder(new EmptyBorder(0, 0, 0, 0));
        
        JLabel lblUsername = new JLabel("Tên đăng nhập");
        lblUsername.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lblUsername.setForeground(new Color(52, 73, 94));
        usernamePanel.add(lblUsername, BorderLayout.NORTH);
        
        JPanel userInputPanel = new JPanel(new BorderLayout(8, 0));
        userInputPanel.setBackground(Color.WHITE);
        
        txtTenDangNhap = createStyledTextField();
        userInputPanel.add(txtTenDangNhap, BorderLayout.CENTER);
        
        usernamePanel.add(userInputPanel, BorderLayout.CENTER);
        inputContainer.add(usernamePanel);
        
        inputContainer.add(Box.createVerticalStrut(12));
        
        // Password field panel
        JPanel passwordPanel = new JPanel(new BorderLayout(8, 4));
        passwordPanel.setBackground(Color.WHITE);
        passwordPanel.setBorder(new EmptyBorder(0, 0, 0, 0));
        
        JLabel lblPassword = new JLabel("Mật khẩu");
        lblPassword.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lblPassword.setForeground(new Color(52, 73, 94));
        passwordPanel.add(lblPassword, BorderLayout.NORTH);
        
        JPanel passInputPanel = new JPanel(new BorderLayout(8, 0));
        passInputPanel.setBackground(Color.WHITE);
        
        txtMatKhau = createStyledPasswordField();
        passInputPanel.add(txtMatKhau, BorderLayout.CENTER);
        
        passwordPanel.add(passInputPanel, BorderLayout.CENTER);
        inputContainer.add(passwordPanel);
        
        // Add input container to login form with center alignment
        JPanel inputWrapperPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 0));
        inputWrapperPanel.setBackground(Color.WHITE);
        inputWrapperPanel.add(inputContainer);
        loginFormPanel.add(inputWrapperPanel);
        
        loginFormPanel.add(Box.createVerticalStrut(25));
        
        // Buttons panel
        JPanel buttonPanel = new JPanel(new GridLayout(1, 2, 10, 0));
        buttonPanel.setBackground(Color.WHITE);
        buttonPanel.setMaximumSize(new Dimension(300, 35));
        
        btnDangNhap = createStyledButton("ĐĂNG NHẬP", primaryColor);
        btnDangKy = createStyledButton("ĐĂNG KÝ", secondaryColor);
        
        buttonPanel.add(btnDangNhap);
        buttonPanel.add(btnDangKy);
        
        // Add button panel with center alignment
        JPanel buttonWrapperPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 0));
        buttonWrapperPanel.setBackground(Color.WHITE);
        buttonWrapperPanel.add(buttonPanel);
        loginFormPanel.add(buttonWrapperPanel);
        
        // Add login form panel to right panel with vertical centering
        rightPanel.add(Box.createVerticalGlue());
        rightPanel.add(loginFormPanel);
        rightPanel.add(Box.createVerticalGlue());
        
        // Add panels to main panel
        mainPanel.add(leftPanel);
        mainPanel.add(rightPanel);
        
        add(mainPanel);
        
        // Add event listeners
        btnDangNhap.addActionListener(e -> xuLyDangNhap());
        
        btnDangKy.addActionListener(e -> {
            setVisible(false);
            DangKyGUI dangKyForm = new DangKyGUI(parentFrame);
            dangKyForm.setLocationRelativeTo(this);
            dangKyForm.setVisible(true);
            setVisible(true);
        });
        
        // Add hover effects
        addHoverEffect(btnDangNhap);
        addHoverEffect(btnDangKy);
        
        // Add Enter key listener
        KeyAdapter enterKeyListener = new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    xuLyDangNhap();
                }
            }
        };
        txtTenDangNhap.addKeyListener(enterKeyListener);
        txtMatKhau.addKeyListener(enterKeyListener);
    }
    
    private JTextField createStyledTextField() {
        JTextField field = new JTextField(20);
        field.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        field.setPreferredSize(new Dimension(0, 32));
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(189, 195, 199), 1),
            new EmptyBorder(4, 8, 4, 8)
        ));
        field.setBackground(Color.WHITE);
        
        return field;
    }
    
    private JPasswordField createStyledPasswordField() {
        JPasswordField field = new JPasswordField(20);
        field.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        field.setPreferredSize(new Dimension(0, 32));
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(189, 195, 199), 1),
            new EmptyBorder(4, 8, 4, 8)
        ));
        field.setBackground(Color.WHITE);
        
        return field;
    }
    
    private JButton createStyledButton(String text, Color backgroundColor) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.BOLD, 13));
        button.setForeground(Color.WHITE);
        button.setBackground(backgroundColor);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setPreferredSize(new Dimension(140, 35));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return button;
    }
    
    private void addHoverEffect(JButton button) {
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(button.getBackground().darker());
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(button.getBackground().brighter());
            }
        });
    }

   private void xuLyDangNhap() {
    String username = txtTenDangNhap.getText().trim();
    String password = new String(txtMatKhau.getPassword());

    if (username.isEmpty() || password.isEmpty()) {
            showErrorMessage("Vui lòng nhập đầy đủ thông tin!");
        return;
    }

    // Kiểm tra tài khoản admin
    if (username.equals("admin") && password.equals("admin")) {
        loginSuccess = true;
        tenDangNhap = username;
        isAdmin = true;
            showSuccessMessage("Đăng nhập thành công!\nXin chào Admin");
        dispose();
        return;
    }

    try (Connection conn = DatabaseConnection.getConnection()) {
        String sql = "SELECT maKhachHang, tenKhachHang, isAdmin FROM KhachHang WHERE tenDangNhap = ? AND matKhau = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, username);
            ps.setString(2, password);
            
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    loginSuccess = true;
                    tenDangNhap = username;
                    isAdmin = rs.getBoolean("isAdmin");
                    String tenKhachHang = rs.getString("tenKhachHang");

                    if (isAdmin) {
                            showSuccessMessage("Đăng nhập thành công!\nXin chào " + tenKhachHang);
                    }
                    
                    dispose();
                } else {
                        showErrorMessage("Tên đăng nhập hoặc mật khẩu không đúng!");
                    txtMatKhau.setText("");
                    txtMatKhau.requestFocusInWindow();
                }
            }
        }
    } catch (SQLException ex) {
        ex.printStackTrace();
            showErrorMessage("Lỗi kết nối database: " + ex.getMessage());
        }
    }
    
    private void showErrorMessage(String message) {
        JOptionPane.showMessageDialog(this,
            message,
            "Lỗi",
            JOptionPane.ERROR_MESSAGE);
    }
    
    private void showSuccessMessage(String message) {
        JOptionPane.showMessageDialog(this,
            message,
            "Thông báo",
            JOptionPane.INFORMATION_MESSAGE);
}

    public String getTenDangNhap() {
        return tenDangNhap;
    }
    
    public boolean isAdmin() {
        return isAdmin;
    }
    
    public boolean isLoginSuccess() {
        return loginSuccess;
    }
}
