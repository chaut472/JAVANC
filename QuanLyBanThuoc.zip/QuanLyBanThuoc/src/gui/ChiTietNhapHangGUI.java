package gui;

import dao.ChiTietNhapHangDAO;
import dao.ThuocDAO;
import dao.NhapHangDAO;
import entity.ChiTietNhapHang;
import entity.Thuoc;
import entity.NhapHang;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;
import java.sql.SQLException;

public class ChiTietNhapHangGUI extends JPanel {
    private JTable table;
    private DefaultTableModel model;
    private JTextField txtMaNhapHang, txtMaThuoc, txtSoLuong, txtGiaNhap;
    private ChiTietNhapHangDAO dao;
    private ThuocDAO thuocDAO;
    private NhapHangDAO nhapHangDAO;

    public ChiTietNhapHangGUI() {
        try {
            dao = new ChiTietNhapHangDAO();
            thuocDAO = new ThuocDAO();
            nhapHangDAO = new NhapHangDAO();
            initComponents();
            loadData();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Lỗi kết nối database: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void initComponents() {
        setLayout(new BorderLayout());

        // ==== Bảng ====
        model = new DefaultTableModel();
        model.setColumnIdentifiers(new String[]{"Mã Nhập Hàng", "Mã Thuốc", "Số Lượng", "Giá Nhập"});
        table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        // ==== Nhập liệu ====
        JPanel inputPanel = new JPanel(new GridLayout(4, 2, 5, 5));
        inputPanel.setBorder(BorderFactory.createTitledBorder("Thông tin chi tiết nhập"));

        txtMaNhapHang = new JTextField();
        txtMaThuoc = new JTextField();
        txtSoLuong = new JTextField();
        txtGiaNhap = new JTextField();

        inputPanel.add(new JLabel("Mã Nhập Hàng:"));
        inputPanel.add(txtMaNhapHang);
        inputPanel.add(new JLabel("Mã Thuốc:"));
        inputPanel.add(txtMaThuoc);
        inputPanel.add(new JLabel("Số Lượng:"));
        inputPanel.add(txtSoLuong);
        inputPanel.add(new JLabel("Giá Nhập:"));
        inputPanel.add(txtGiaNhap);

        add(inputPanel, BorderLayout.NORTH);

        // ==== Nút ====
        JPanel buttonPanel = new JPanel();

        JButton btnThem = new JButton("Thêm");
        JButton btnSua = new JButton("Sửa");
        JButton btnXoa = new JButton("Xóa");
        JButton btnTaiLai = new JButton("Tải lại");

        buttonPanel.add(btnThem);
        buttonPanel.add(btnSua);
        buttonPanel.add(btnXoa);
        buttonPanel.add(btnTaiLai);

        add(buttonPanel, BorderLayout.SOUTH);

        // ==== Sự kiện ====
        btnThem.addActionListener(e -> {
            ChiTietNhapHang ct = getFormData();
            if (ct != null) {
                if (dao.add(ct)) {
                    JOptionPane.showMessageDialog(this, "Thêm thành công!");
                    loadData();
                } else {
                    JOptionPane.showMessageDialog(this, "Thêm thất bại! Kiểm tra lại thông tin.");
                }
            }
        });

        btnSua.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row >= 0) {
                ChiTietNhapHang ct = getFormData();
                if (ct != null) {
                    if (dao.update(ct)) {
                        JOptionPane.showMessageDialog(this, "Sửa thành công!");
                        loadData();
                    } else {
                        JOptionPane.showMessageDialog(this, "Sửa thất bại! Kiểm tra lại thông tin.");
                    }
                }
            } else {
                JOptionPane.showMessageDialog(this, "Vui lòng chọn dòng cần sửa.");
            }
        });

        btnXoa.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row >= 0) {
                String maNhap = model.getValueAt(row, 0).toString();
                String maThuoc = model.getValueAt(row, 1).toString();
                int confirm = JOptionPane.showConfirmDialog(this, 
                    "Bạn có chắc muốn xóa chi tiết nhập hàng này?", 
                    "Xác nhận xóa", 
                    JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    if (dao.delete(maNhap, maThuoc)) {
                        JOptionPane.showMessageDialog(this, "Xóa thành công!");
                        loadData();
                    } else {
                        JOptionPane.showMessageDialog(this, "Xóa thất bại!");
                    }
                }
            } else {
                JOptionPane.showMessageDialog(this, "Vui lòng chọn dòng cần xóa.");
            }
        });

        btnTaiLai.addActionListener(e -> {
            loadData();
        });

        table.getSelectionModel().addListSelectionListener(e -> {
            int row = table.getSelectedRow();
            if (row >= 0) {
                txtMaNhapHang.setText(model.getValueAt(row, 0).toString());
                txtMaThuoc.setText(model.getValueAt(row, 1).toString());
                txtSoLuong.setText(model.getValueAt(row, 2).toString());
                txtGiaNhap.setText(model.getValueAt(row, 3).toString());
            }
        });
    }

    private ChiTietNhapHang getFormData() {
        try {
            String maNhap = txtMaNhapHang.getText().trim();
            String maThuoc = txtMaThuoc.getText().trim();
            String soLuongStr = txtSoLuong.getText().trim();
            String giaNhapStr = txtGiaNhap.getText().trim();

            // Kiểm tra dữ liệu trống
            if (maNhap.isEmpty() || maThuoc.isEmpty() || soLuongStr.isEmpty() || giaNhapStr.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Vui lòng nhập đầy đủ thông tin!");
                return null;
            }

            // Kiểm tra mã nhập hàng tồn tại
            NhapHang nhapHang = nhapHangDAO.getByMa(maNhap);
            if (nhapHang == null) {
                JOptionPane.showMessageDialog(this, "Mã nhập hàng không tồn tại!");
                return null;
            }

            // Kiểm tra mã thuốc tồn tại
            Thuoc thuoc = thuocDAO.getByMa(maThuoc);
            if (thuoc == null) {
                JOptionPane.showMessageDialog(this, "Mã thuốc không tồn tại!");
                return null;
            }

            // Kiểm tra số lượng
            int soLuong = Integer.parseInt(soLuongStr);
            if (soLuong <= 0) {
                JOptionPane.showMessageDialog(this, "Số lượng phải lớn hơn 0!");
                return null;
            }

            // Kiểm tra giá nhập
            double giaNhap = Double.parseDouble(giaNhapStr);
            if (giaNhap <= 0) {
                JOptionPane.showMessageDialog(this, "Giá nhập phải lớn hơn 0!");
                return null;
            }

            return new ChiTietNhapHang(maNhap, maThuoc, soLuong, giaNhap);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Số lượng và giá nhập phải là số!");
            return null;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Lỗi: " + e.getMessage());
            return null;
        }
    }

    private void loadData() {
        try {
            model.setRowCount(0);
            List<ChiTietNhapHang> list = dao.getAll();
            for (ChiTietNhapHang ct : list) {
                model.addRow(new Object[]{
                    ct.getMaNhapHang(),
                    ct.getMaThuoc(),
                    ct.getSoLuong(),
                    ct.getGiaNhap()
                });
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Lỗi tải dữ liệu: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
