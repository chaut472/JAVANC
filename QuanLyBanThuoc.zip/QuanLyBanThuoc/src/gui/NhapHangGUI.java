/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gui;

/**
 *
 * @author Cao Thi Han
    */import bus.NhapHangBUS;
import entity.NhapHang;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Date;
import java.sql.SQLException;
import java.util.List;

public class NhapHangGUI extends JPanel {
    private JTextField txtMaNhapHang, txtNgayNhap;
    private JButton btnThem, btnSua, btnXoa;
    private JTable tblNhapHang;
    private DefaultTableModel model;
    private NhapHangBUS bus;

    public NhapHangGUI() {
        try {
            bus = new NhapHangBUS();
            initComponents();
            loadTable();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, 
                "Lỗi kết nối database: " + e.getMessage(), 
                "Lỗi", 
                JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, 
                "Lỗi khởi tạo: " + e.getMessage(), 
                "Lỗi", 
                JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }
    
    private void initComponents() {
        setLayout(new BorderLayout());

        // Panel trên: nhập liệu
        JPanel panelTop = new JPanel(new GridLayout(2, 2, 5, 5));
        panelTop.setBorder(BorderFactory.createTitledBorder("Thông tin Nhập hàng"));
        panelTop.add(new JLabel("Mã Nhập Hàng:"));
        txtMaNhapHang = new JTextField();
        panelTop.add(txtMaNhapHang);

        panelTop.add(new JLabel("Ngày Nhập (yyyy-mm-dd):"));
        txtNgayNhap = new JTextField();
        panelTop.add(txtNgayNhap);

        // Panel nút chức năng
        btnThem = new JButton("Thêm");
        btnSua = new JButton("Sửa");
        btnXoa = new JButton("Xóa");
        JPanel panelButton = new JPanel();
        panelButton.add(btnThem);
        panelButton.add(btnSua);
        panelButton.add(btnXoa);

        // Bảng hiển thị dữ liệu
        model = new DefaultTableModel(new String[]{"Mã Nhập", "Ngày Nhập"}, 0);
        tblNhapHang = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(tblNhapHang);

        // Thêm thành phần vào giao diện chính
        add(panelTop, BorderLayout.NORTH);
        add(panelButton, BorderLayout.CENTER);
        add(scrollPane, BorderLayout.SOUTH);

        // Sự kiện Thêm
        btnThem.addActionListener(e -> {
            String ma = txtMaNhapHang.getText().trim();
            String ngay = txtNgayNhap.getText().trim();
            
            if (ma.isEmpty() || ngay.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Vui lòng nhập đầy đủ thông tin!");
                return;
            }
            
            try {
                Date date = Date.valueOf(ngay);
                NhapHang nh = new NhapHang(ma, date);
                if (bus.them(nh)) {
                    JOptionPane.showMessageDialog(this, "Thêm thành công!");
                    loadTable();
                    clearForm();
                } else {
                    JOptionPane.showMessageDialog(this, "Thêm thất bại!");
                }
            } catch (IllegalArgumentException ex) {
                JOptionPane.showMessageDialog(this, "Định dạng ngày không hợp lệ! Vui lòng nhập theo định dạng yyyy-mm-dd");
            }
        });

        // Sự kiện Sửa
        btnSua.addActionListener(e -> {
            int row = tblNhapHang.getSelectedRow();
            if (row >= 0) {
                String ma = txtMaNhapHang.getText().trim();
                String ngay = txtNgayNhap.getText().trim();
                
                if (ma.isEmpty() || ngay.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Vui lòng nhập đầy đủ thông tin!");
                    return;
                }
                
                try {
                    Date date = Date.valueOf(ngay);
                    NhapHang nh = new NhapHang(ma, date);
                    if (bus.sua(nh)) {
                        JOptionPane.showMessageDialog(this, "Sửa thành công!");
                        loadTable();
                        clearForm();
                    } else {
                        JOptionPane.showMessageDialog(this, "Sửa thất bại!");
                    }
                } catch (IllegalArgumentException ex) {
                    JOptionPane.showMessageDialog(this, "Định dạng ngày không hợp lệ! Vui lòng nhập theo định dạng yyyy-mm-dd");
                }
            } else {
                JOptionPane.showMessageDialog(this, "Vui lòng chọn mục để sửa.");
            }
        });

        // Sự kiện Xóa
        btnXoa.addActionListener(e -> {
            int row = tblNhapHang.getSelectedRow();
            if (row >= 0) {
                String ma = model.getValueAt(row, 0).toString();
                int confirm = JOptionPane.showConfirmDialog(this, 
                    "Bạn có chắc muốn xóa nhập hàng này?", 
                    "Xác nhận xóa", 
                    JOptionPane.YES_NO_OPTION);
                    
                if (confirm == JOptionPane.YES_OPTION) {
                    if (bus.xoa(ma)) {
                        JOptionPane.showMessageDialog(this, "Xóa thành công!");
                        loadTable();
                        clearForm();
                    } else {
                        JOptionPane.showMessageDialog(this, "Xóa thất bại!");
                    }
                }
            } else {
                JOptionPane.showMessageDialog(this, "Vui lòng chọn mục để xóa.");
            }
        });
        
        // Sự kiện chọn dòng trong bảng
        tblNhapHang.getSelectionModel().addListSelectionListener(e -> {
            int row = tblNhapHang.getSelectedRow();
            if (row >= 0) {
                txtMaNhapHang.setText(model.getValueAt(row, 0).toString());
                txtNgayNhap.setText(model.getValueAt(row, 1).toString());
            }
        });
    }
    
    private void clearForm() {
        txtMaNhapHang.setText("");
        txtNgayNhap.setText("");
        tblNhapHang.clearSelection();
    }

    // Tải lại dữ liệu vào bảng
    private void loadTable() {
        try {
            model.setRowCount(0);
            List<NhapHang> list = bus.getAll();
            for (NhapHang nh : list) {
                model.addRow(new Object[]{nh.getMaNhapHang(), nh.getNgayNhap()});
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, 
                "Lỗi tải dữ liệu: " + e.getMessage(), 
                "Lỗi", 
                JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }
}
