package gui;
import bus.HoaDonBUS;
import bus.ChiTietHoaDonBUS;
import bus.KhachHangBUS;
import bus.ThuocBUS;
import dao.HoaDonDAO;
import entity.User;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import utils.GUIUtils;
import entity.Thuoc;
import entity.KhachHang;
import entity.HoaDon;
import entity.ChiTietHoaDon;
import java.util.List;
import java.util.ArrayList;

public class MainGUI extends JFrame {
    private User currentUser;
    private JPanel mainPanel;
    private JPanel contentPanel;
    private JPanel sidebar;
    private JLabel pageTitleLabel;
    private JLabel userNameLabel;  // Added to update user info
    private JLabel roleLabel;      // Added to update user info
    private HoaDonBUS hoaDonBUS;
    private HoaDonDAO dao;
    
    private Color primaryColor = new Color(41, 128, 185);
    private Color sidebarColor = new Color(52, 73, 94);
    private Color accentColor = new Color(41, 128, 185);
    private Color textColor = new Color(236, 240, 241);
    private Color hoverColor = new Color(44, 62, 80);
    private Font titleFont = new Font("Segoe UI", Font.BOLD, 24);
    private Font menuFont = new Font("Segoe UI", Font.PLAIN, 14);
    private Font labelFont = new Font("Segoe UI", Font.BOLD, 13);
    // Icons for sidebar - initialized to null for safety
    private Icon dashboardIcon = null;
    private Icon medicineIcon = null;
    private Icon customerIcon = null;
    private Icon invoiceIcon = null;
    private Icon importIcon = null;
    private Icon userIcon = null;
    private Icon logoutIcon = null;
    
    public MainGUI() {
        GUIUtils.setupGUI();
        loadIcons();
        initComponents();
        showLoginDialog();
    }
    
    private void loadIcons() {
        // Safely load icons - if resources are missing, icons remain null
        try {
            dashboardIcon = new ImageIcon(getClass().getResource("/images/dashboard.png"));
            medicineIcon = new ImageIcon(getClass().getResource("/images/medicine.png"));
            customerIcon = new ImageIcon(getClass().getResource("/images/customer.png"));
            invoiceIcon = new ImageIcon(getClass().getResource("/images/invoice.png"));
            importIcon = new ImageIcon(getClass().getResource("/images/import.png"));
            userIcon = new ImageIcon(getClass().getResource("/images/user.png"));
            logoutIcon = new ImageIcon(getClass().getResource("/images/logout.png"));
        } catch (Exception e) {
            System.out.println("Could not load some icons");
        }
    }
    
    private void initComponents() {
        setTitle("Quản Lý Bán Thuốc");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1280, 800);
        setLocationRelativeTo(null);
        setMinimumSize(new Dimension(1024, 768));
        
        // Main container panel
        mainPanel = new JPanel(new BorderLayout(0, 0));
        mainPanel.setBackground(Color.WHITE);
        
        // Create sidebar and content panel
        createSidebar();
        createContentPanel();
        
        // Add components to main panel
        mainPanel.add(sidebar, BorderLayout.WEST);
        mainPanel.add(contentPanel, BorderLayout.CENTER);
        
        // Add to frame
        add(mainPanel);
    }
    
    private void createSidebar() {
        // Create sidebar panel with gradient background
        sidebar = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
                int w = getWidth();
                int h = getHeight();
                GradientPaint gp = new GradientPaint(0, 0, sidebarColor, w, h, new Color(44, 62, 80));
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, w, h);
            }
        };
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setPreferredSize(new Dimension(250, 0));
        sidebar.setBorder(BorderFactory.createEmptyBorder(20, 15, 20, 15));
        
        // App title panel
        JPanel titlePanel = new JPanel();
        titlePanel.setLayout(new BoxLayout(titlePanel, BoxLayout.Y_AXIS));
        titlePanel.setOpaque(false);
        titlePanel.setBorder(new EmptyBorder(0, 0, 30, 0));
        
        // Add logo if available
        try {
            ImageIcon logoIcon = new ImageIcon(getClass().getResource("/images/pharmacy_logo_small.png"));
            if (logoIcon.getIconWidth() > 0) {
                Image scaledImage = logoIcon.getImage().getScaledInstance(60, 60, Image.SCALE_SMOOTH);
                JLabel logoLabel = new JLabel(new ImageIcon(scaledImage));
                logoLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
                titlePanel.add(logoLabel);
                titlePanel.add(Box.createVerticalStrut(15));
            }
        } catch (Exception e) {
            // Logo not found, use text only
        }
        
        // App title
        JLabel appTitle = new JLabel("Quản Lý Bán Thuốc");
        appTitle.setFont(titleFont);
        appTitle.setForeground(textColor);
        appTitle.setAlignmentX(Component.CENTER_ALIGNMENT);
        titlePanel.add(appTitle);
        
        sidebar.add(titlePanel);
        sidebar.add(Box.createVerticalStrut(20));
        
        // Add separator
        JSeparator separator = new JSeparator();
        separator.setForeground(new Color(70, 90, 101));
        separator.setMaximumSize(new Dimension(220, 1));
        sidebar.add(separator);
        sidebar.add(Box.createVerticalStrut(20));
    }
    
    private void createContentPanel() {
        contentPanel = new JPanel(new BorderLayout());
        contentPanel.setBackground(Color.WHITE);
        
        // Add a top bar
        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setBackground(Color.WHITE);
        topBar.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(229, 229, 229)),
            BorderFactory.createEmptyBorder(15, 20, 15, 20)
        ));
        
        // Add page title (will be updated when switching pages)
        pageTitleLabel = new JLabel("Dashboard");
        pageTitleLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        pageTitleLabel.setForeground(new Color(44, 62, 80));
        topBar.add(pageTitleLabel, BorderLayout.WEST);
        
        // Add user info to top bar
        JPanel userInfo = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        userInfo.setOpaque(false);
        
        // Initialize user info labels (empty initially)
        userNameLabel = new JLabel("");
        userNameLabel.setFont(new Font("Segoe UI", Font.BOLD, 13));
        userNameLabel.setForeground(new Color(44, 62, 80));
        
        roleLabel = new JLabel("");
        roleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        roleLabel.setForeground(new Color(108, 117, 125));
        
        // Add current time
        JLabel timeLabel = new JLabel();
        timeLabel.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        timeLabel.setForeground(new Color(108, 117, 125));
        
        // Update time every second
        Timer timer = new Timer(1000, e -> {
            SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
            timeLabel.setText(sdf.format(new Date()));
        });
        timer.start();
        
        userInfo.add(userNameLabel);
        userInfo.add(roleLabel);
        userInfo.add(new JSeparator(JSeparator.VERTICAL) {
            {
                setPreferredSize(new Dimension(1, 20));
                setForeground(new Color(229, 229, 229));
            }
        });
        userInfo.add(timeLabel);
        topBar.add(userInfo, BorderLayout.EAST);
        
        contentPanel.add(topBar, BorderLayout.NORTH);
        
        // Main content area with card layout for better page management
        JPanel mainContent = new JPanel(new CardLayout());
        mainContent.setBackground(new Color(245, 247, 250));
        mainContent.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        contentPanel.add(mainContent, BorderLayout.CENTER);
    }

private void showLoginDialog() {
    DangNhapGUI loginDialog = new DangNhapGUI(this);
    loginDialog.setVisible(true);

    if (loginDialog.isLoginSuccess()) {
            // Create user with role based on login result
            currentUser = new User();
            currentUser.setTenUser(loginDialog.getTenDangNhap());
            currentUser.setMaUser(loginDialog.getMaUser());
            currentUser.setVaiTro(loginDialog.isAdmin() ? "ADMIN" : "USER");
            
            // Update UI elements with user info
            userNameLabel.setText(currentUser.getTenUser());
            roleLabel.setText("(" + currentUser.getVaiTro() + ")");
            
            updateUIForUser(); // Update interface based on role
    } else {
        System.exit(0);
    }
}

    private void updateUIForUser() {
    // Update window title
    setTitle("Quản Lý Bán Thuốc - " + currentUser.getTenUser());

    // Clear existing sidebar menu items
    sidebar.removeAll();

    // Recreate sidebar with updated user info
    createSidebar();

    // Add navigation menu items with modern styling
    addMenuSection("TỔNG QUAN");
    addSidebarButton("Dashboard", dashboardIcon, e -> showDashboard());

    // Add management section
    addMenuSection("QUẢN LÝ");

    // Người dùng thường (USER) chỉ xem được thuốc và hóa đơn
    addSidebarButton("Quản lý thuốc", medicineIcon, e -> showThuocGUI());
    addSidebarButton("Quản lý hóa đơn", invoiceIcon, e -> showHoaDonGUI());

        if ("ADMIN".equalsIgnoreCase(currentUser.getVaiTro())) {
        addSidebarButton("Quản lý khách hàng", customerIcon, e -> showKhachHangGUI());
        addSidebarButton("Nhập hàng", importIcon, e -> showNhapHangGUI());

        // Add admin section
        addMenuSection("QUẢN TRỊ");
        addSidebarButton("Quản lý người dùng", userIcon, e -> showUserManagement());
    }

    sidebar.revalidate();
    sidebar.repaint();

    // Add user profile and logout at bottom
    sidebar.add(Box.createVerticalGlue());

    JPanel userPanel = new JPanel();
    userPanel.setLayout(new BoxLayout(userPanel, BoxLayout.Y_AXIS));
    userPanel.setOpaque(false);
    userPanel.setBorder(BorderFactory.createCompoundBorder(
        BorderFactory.createMatteBorder(1, 0, 0, 0, new Color(70, 90, 101)),
        BorderFactory.createEmptyBorder(15, 0, 0, 0)
    ));

    JLabel userLabel = new JLabel(currentUser.getTenUser());
    userLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
    userLabel.setForeground(textColor);
    userLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
    userPanel.add(userLabel);

    JLabel roleLabel = new JLabel(currentUser.getVaiTro());
    roleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
    roleLabel.setForeground(new Color(189, 195, 199));
    roleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
    userPanel.add(roleLabel);
    userPanel.add(Box.createVerticalStrut(10));

    JButton logoutButton = createStyledButton("Đăng xuất", logoutIcon);
    logoutButton.addActionListener(e -> logout());
    userPanel.add(logoutButton);

    sidebar.add(userPanel);

    // Show dashboard as default view
    showDashboard();

    sidebar.revalidate();
    sidebar.repaint();
}

private void addMenuSection(String title) {
    JLabel sectionLabel = new JLabel(title);
    sectionLabel.setFont(labelFont);
    sectionLabel.setForeground(new Color(189, 195, 199));
    sectionLabel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 0));
    sidebar.add(sectionLabel);
    sidebar.add(Box.createVerticalStrut(10));
}

private void addSidebarButton(String title, Icon icon, ActionListener action) {
    JButton button = createStyledButton(title, icon);
    button.addActionListener(action);
    sidebar.add(button);
    sidebar.add(Box.createVerticalStrut(10));
}

    private JButton createStyledButton(String text, Icon icon) {
        JButton button = new JButton(text);
        button.setFont(menuFont);
        button.setForeground(textColor);
        button.setIcon(icon);
        button.setHorizontalAlignment(SwingConstants.LEFT);
        button.setIconTextGap(10);
        button.setBorderPainted(false);
        button.setContentAreaFilled(false);
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setMaximumSize(new Dimension(220, 40));
        button.setPreferredSize(new Dimension(220, 40));
        
        // Add hover effect
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(hoverColor);
                button.setContentAreaFilled(true);
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                button.setContentAreaFilled(false);
            }
        });
        
        return button;
    }
    
    private void showDashboard() {
        updatePageTitle("Dashboard");
        // Clear content panel
        contentPanel.removeAll();
        
        // Create dashboard panel
        JPanel dashboardPanel = new JPanel(new BorderLayout(0, 20));
        dashboardPanel.setOpaque(false);
        
        // Header panel with welcome message and date
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setOpaque(false);
        
        String welcomeText = "ADMIN".equalsIgnoreCase(currentUser.getVaiTro()) ? 
            "Dashboard" : "Thông tin của bạn";
        JLabel welcomeLabel = GUIUtils.createHeadingLabel(welcomeText);
        welcomeLabel.setFont(GUIUtils.TITLE_FONT);
        
        SimpleDateFormat dateFormat = new SimpleDateFormat("EEEE, dd MMMM yyyy");
        JLabel dateLabel = new JLabel(dateFormat.format(new Date()));
        dateLabel.setFont(GUIUtils.FIELD_FONT);
        dateLabel.setForeground(new Color(120, 120, 120));
        
        headerPanel.add(welcomeLabel, BorderLayout.WEST);
        headerPanel.add(dateLabel, BorderLayout.EAST);
        
        // Stats cards
        JPanel statsPanel = new JPanel(new GridLayout(2, 2, 20, 20));
        statsPanel.setOpaque(false);
        
        if ("ADMIN".equalsIgnoreCase(currentUser.getVaiTro())) {
            // Admin sees all statistics
            statsPanel.add(GUIUtils.createDashboardCard("Tổng số thuốc", getTotalMedicines(), new Color(41, 128, 185), null));
            statsPanel.add(GUIUtils.createDashboardCard("Khách hàng", getTotalCustomers(), new Color(39, 174, 96), null));
            statsPanel.add(GUIUtils.createDashboardCard("Đơn hàng", getTotalOrders(), new Color(142, 68, 173), null));
            statsPanel.add(GUIUtils.createDashboardCard("Doanh thu", getTotalRevenue(), new Color(211, 84, 0), null));
        } else {
            // Regular user sees their own statistics
            statsPanel.add(GUIUtils.createDashboardCard("Đơn hàng của bạn", getUserOrders(), new Color(142, 68, 173), null));
            statsPanel.add(GUIUtils.createDashboardCard("Chi tiêu của bạn", getUserSpending(), new Color(211, 84, 0), null));
            statsPanel.add(GUIUtils.createDashboardCard("Đơn gần nhất", getLastOrderDate(), new Color(41, 128, 185), null));
            statsPanel.add(GUIUtils.createDashboardCard("Trạng thái", getUserStatus(), new Color(39, 174, 96), null));
        }
        
        // Recent transactions panel
        JPanel recentPanel = GUIUtils.createCardPanel();
        recentPanel.setLayout(new BorderLayout(0, 15));
        
        JLabel recentLabel = GUIUtils.createSubtitleLabel("Giao dịch gần đây");
        
        // Sample table for recent transactions - filtered by user role
        String[] columnNames = {"Mã HĐ", "Khách hàng", "Ngày", "Tổng tiền", "Trạng thái"};
        Object[][] data = getRecentTransactions(); // This method should filter based on user role
        
        JTable table = new JTable(data, columnNames);
        GUIUtils.styleTable(table);
        JScrollPane scrollPane = new JScrollPane(table);
        GUIUtils.styleScrollPane(scrollPane);
        
        recentPanel.add(recentLabel, BorderLayout.NORTH);
        recentPanel.add(scrollPane, BorderLayout.CENTER);
        
        // Quick actions panel
        JPanel actionsPanel = GUIUtils.createCardPanel();
        actionsPanel.setLayout(new BorderLayout(0, 15));
        
        JLabel actionsLabel = GUIUtils.createSubtitleLabel("Thao tác nhanh");
        
        JPanel buttonsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        buttonsPanel.setOpaque(false);
        
        addQuickActionButtons(buttonsPanel);
        
        actionsPanel.add(actionsLabel, BorderLayout.NORTH);
        actionsPanel.add(buttonsPanel, BorderLayout.CENTER);
        
        // Add components to dashboard
        JPanel centerPanel = new JPanel(new GridBagLayout());
        centerPanel.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.weightx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        centerPanel.add(statsPanel, gbc);
        
        gbc.insets = new Insets(20, 0, 0, 0);
        centerPanel.add(recentPanel, gbc);
        
        gbc.insets = new Insets(20, 0, 0, 0);
        centerPanel.add(actionsPanel, gbc);
        
        dashboardPanel.add(headerPanel, BorderLayout.NORTH);
        dashboardPanel.add(centerPanel, BorderLayout.CENTER);
        
        // Add dashboard to content panel
        contentPanel.add(dashboardPanel);
        
        // Refresh UI
        contentPanel.revalidate();
        contentPanel.repaint();
    }
    
    // Helper methods to get statistics
    private String getTotalMedicines() {
        try {
            ThuocBUS thuocBUS = new ThuocBUS();
            List<Thuoc> dsThuoc = thuocBUS.getAll();
            return dsThuoc != null ? String.valueOf(dsThuoc.size()) : "0";
        } catch (Exception e) {
            e.printStackTrace();
            return "0";
        }
    }

    private String getTotalCustomers() {
        try {
            KhachHangBUS khachHangBUS = new KhachHangBUS();
            List<KhachHang> dsKhachHang = khachHangBUS.getAll();
            return dsKhachHang != null ? String.valueOf(dsKhachHang.size()) : "0";
        } catch (Exception e) {
            e.printStackTrace();
            return "0";
        }
    }

    private String getTotalOrders() {
        try {
            if (hoaDonBUS == null) {
                hoaDonBUS = new HoaDonBUS();
            }
            List<HoaDon> dsHoaDon = hoaDonBUS.getAll();
            return dsHoaDon != null ? String.valueOf(dsHoaDon.size()) : "0";
        } catch (Exception e) {
            e.printStackTrace();
            return "0";
        }
    }

    private double calculateOrderTotal(HoaDon hoaDon) {
        try {
            ChiTietHoaDonBUS chiTietBUS = new ChiTietHoaDonBUS();
            return chiTietBUS.tinhTongTien(hoaDon.getMaHD());
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    private String getTotalRevenue() {
        try {
            HoaDonBUS hoaDonBUS = new HoaDonBUS();
            double totalRevenue = 0;
            
            List<HoaDon> hoaDons = hoaDonBUS.getAll();
            if (hoaDons != null) {
                for (HoaDon hoaDon : hoaDons) {
                    try {
                        totalRevenue += calculateOrderTotal(hoaDon);
                    } catch (Exception e) {
                        // Skip failed calculations
                        e.printStackTrace();
                    }
                }
            }
            
            return String.format("%,.0f đ", totalRevenue);
        } catch (Exception e) {
            e.printStackTrace();
            return "0 đ";
        }
    }

    private String getUserOrders() {
        try {
            if (hoaDonBUS == null) {
                hoaDonBUS = new HoaDonBUS();
            }
            List<HoaDon> userOrders = hoaDonBUS.getByUser(currentUser);
            return userOrders != null ? String.valueOf(userOrders.size()) : "0";
        } catch (Exception e) {
            e.printStackTrace();
            return "0";
        }
    }

    private String getUserSpending() {
        try {
            if (hoaDonBUS == null) {
                hoaDonBUS = new HoaDonBUS();
            }
            double totalSpending = hoaDonBUS.getTotalSpendingByUser(currentUser);
            return String.format("%,.0f đ", totalSpending);
        } catch (Exception e) {
            e.printStackTrace();
            return "0 đ";
        }
    }

    private String getLastOrderDate() {
        try {
            if (hoaDonBUS == null) {
                hoaDonBUS = new HoaDonBUS();
            }
            return hoaDonBUS.getLastOrderDateByUser(currentUser);
        } catch (Exception e) {
            return "Chưa có đơn hàng";
        }
    }
    public List<HoaDon> getByUser(User user) {
        if (user == null || user.getMaUser() == null) {
            return new ArrayList<>();
        }
        try {
            return dao.getByKhachHang(user.getMaUser());
        } catch (Exception e) {
            System.out.println("Lỗi lấy danh sách hóa đơn của khách hàng: " + e.getMessage());
            e.printStackTrace();
            return new ArrayList<>();
        }
    }
    public int countOrdersByUser(User user)
    {
        return getByUser(user).size();
    }
    private String getUserStatus() {
        try {
            HoaDonBUS hoaDonBUS = new HoaDonBUS();
            int orderCount = hoaDonBUS.countOrdersByUser(currentUser);
            if (orderCount > 10) {
                return "VIP";
            } else if (orderCount > 5) {
                return "Thành viên thân thiết";
            } else {
                return "Thành viên mới";
            }
        } catch (Exception e) {
            return "Thành viên";
        }
    }

    private Object[][] getRecentTransactions() {
        try {
            HoaDonBUS hoaDonBUS = new HoaDonBUS();
            List<HoaDon> orders;
            
            if ("ADMIN".equals(currentUser.getVaiTro())) {
                orders = hoaDonBUS.getAll();
            } else {
                orders = hoaDonBUS.getByUser(currentUser);
            }
            
            if (orders == null || orders.isEmpty()) {
                return new Object[][] {
                    {"", "Chưa có giao dịch nào", "", "", ""}
                };
            }
            
            // Sort by date descending
            orders.sort((a, b) -> b.getNgayTao().compareTo(a.getNgayTao()));
            
            // Take only the first 5 orders
            List<HoaDon> recentOrders = orders.size() > 5 ? orders.subList(0, 5) : orders;
            
            Object[][] data = new Object[recentOrders.size()][5];
            KhachHangBUS khachHangBUS = new KhachHangBUS();
            
            for (int i = 0; i < recentOrders.size(); i++) {
                HoaDon hd = recentOrders.get(i);
                String customerName = "Khách vãng lai";
                double total = 0;
                
                try {
                    // Get customer name
                    KhachHang kh = khachHangBUS.getByMa(hd.getMaKH());
                    if (kh != null) {
                        customerName = kh.getTenKhachHang() != null ? kh.getTenKhachHang() : kh.getMaKhachHang();
                    }
                    
                    // Calculate order total
                    total = calculateOrderTotal(hd);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                
                data[i] = new Object[]{
                    hd.getMaHD(),
                    customerName,
                    new SimpleDateFormat("dd/MM/yyyy HH:mm").format(hd.getNgayTao()),
                    String.format("%,.0f đ", total),
                    "Hoàn thành"
                };
            }
            return data;
        } catch (Exception e) {
            e.printStackTrace();
            return new Object[][] {
                {"", "Lỗi khi tải dữ liệu", "", "", ""}
            };
        }
    }
    
    private void showUserManagement() {
        updatePageTitle("Quản lý người dùng");
        // Clear content panel
        contentPanel.removeAll();
        
        // Create a card panel for user management
        JPanel userManagementPanel = GUIUtils.createCardPanel();
        userManagementPanel.setLayout(new BorderLayout(0, 15));
        
        JLabel titleLabel = GUIUtils.createSubtitleLabel("Quản lý người dùng");
        userManagementPanel.add(titleLabel, BorderLayout.NORTH);
        
        JLabel infoLabel = new JLabel("Chức năng quản lý người dùng đang được phát triển");
        infoLabel.setHorizontalAlignment(JLabel.CENTER);
        userManagementPanel.add(infoLabel, BorderLayout.CENTER);
        
        // Add to content panel
        contentPanel.add(userManagementPanel);
        
        // Refresh UI
        contentPanel.revalidate();
        contentPanel.repaint();
    }
    
    private void showUserProfile() {
        JOptionPane.showMessageDialog(this, "Chức năng đang được phát triển");
    }
    
    private void logout() {
        int choice = JOptionPane.showConfirmDialog(this,
            "Bạn có chắc muốn đăng xuất?",
            "Xác nhận",
            JOptionPane.YES_NO_OPTION);
            
        if (choice == JOptionPane.YES_OPTION) {
            currentUser = null;
            showLoginDialog();
        }
    }
    
    private void showThuocGUI() {
        updatePageTitle("Quản lý thuốc");
        // Clear content panel
        contentPanel.removeAll();
        
        // Create and add ThuocGUI
        ThuocGUI thuocGUI = new ThuocGUI(currentUser);
        contentPanel.add(thuocGUI);
        
        // Refresh UI
        contentPanel.revalidate();
        contentPanel.repaint();
    }
    
    private void showKhachHangGUI() {
        // Kiểm tra quyền truy cập
        if (!"ADMIN".equalsIgnoreCase(currentUser.getVaiTro())) {
            JOptionPane.showMessageDialog(this,
                "Bạn không có quyền truy cập vào chức năng này!",
                "Lỗi phân quyền",
                JOptionPane.ERROR_MESSAGE);
            return;
        }

        updatePageTitle("Quản lý khách hàng");
        // Clear content panel
        contentPanel.removeAll();
        
        // Create and add KhachHangGUI
        KhachHangGUI khachHangGUI = new KhachHangGUI(currentUser);
        contentPanel.add(khachHangGUI);
        
        // Refresh UI
        contentPanel.revalidate();
        contentPanel.repaint();
    }
    
    private void showHoaDonGUI() {
        updatePageTitle("Quản lý hóa đơn");
        // Clear content panel
        contentPanel.removeAll();
        
        // Create and add HoaDonGUI
        HoaDonGUI hoaDonGUI = new HoaDonGUI(currentUser);
        contentPanel.add(hoaDonGUI);
        
        // Refresh UI
        contentPanel.revalidate();
        contentPanel.repaint();
    }
    
    private void showNhapHangGUI() {
        updatePageTitle("Nhập hàng");
        // Clear content panel
        contentPanel.removeAll();
        
        // Create and add NhapHangGUI
        NhapHangGUI nhapHangGUI = new NhapHangGUI();
        contentPanel.add(nhapHangGUI);
        
        // Refresh UI
        contentPanel.revalidate();
        contentPanel.repaint();
    }
    
    private void updatePageTitle(String title) {
        if (pageTitleLabel != null) {
            pageTitleLabel.setText(title);
        }
    }
    
    private void addQuickActionButtons(JPanel buttonsPanel) {
        JButton addMedicineBtn = new JButton("Thêm thuốc mới");
        JButton createInvoiceBtn = new JButton("Tạo hóa đơn");
        
        GUIUtils.stylePrimaryButton(addMedicineBtn);
        GUIUtils.styleSecondaryButton(createInvoiceBtn);
        
        // Add event handlers with improved error handling and user feedback
        addMedicineBtn.addActionListener(e -> {
            try {
                showThuocGUI();
                Component comp = contentPanel.getComponent(0);
                if (comp instanceof ThuocGUI) {
                    ((ThuocGUI) comp).showAddDialog();
                } else {
                    throw new Exception("Could not access ThuocGUI");
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this,
                    "Không thể mở form thêm thuốc: " + ex.getMessage(),
                    "Lỗi",
                    JOptionPane.ERROR_MESSAGE);
            }
        });
        
        createInvoiceBtn.addActionListener(e -> {
            try {
                showHoaDonGUI();
                Component comp = contentPanel.getComponent(0);
                if (comp instanceof HoaDonGUI) {
                    ((HoaDonGUI) comp).showAddDialog();
                } else {
                    throw new Exception("Could not access HoaDonGUI");
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this,
                    "Không thể mở form tạo hóa đơn: " + ex.getMessage(),
                    "Lỗi",
                    JOptionPane.ERROR_MESSAGE);
            }
        });
        
        // Only show admin actions if user is admin
        if ("ADMIN".equalsIgnoreCase(currentUser.getVaiTro())) {
            buttonsPanel.add(addMedicineBtn);
        }
        buttonsPanel.add(createInvoiceBtn);
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new MainGUI().setVisible(true);
        });
    }
}
