/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

/**
 *
 * @author Cao Thi Han
 */
import entity.NhapHang;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import database.DatabaseConnection; // nếu lớp ở package 'util'
import javax.swing.JOptionPane;

public class NhapHangDAO {

    public NhapHangDAO() throws SQLException {
    }

    public boolean them(NhapHang nh) {
        String sql = "INSERT INTO NhapHang (maNhapHang, ngayNhap) VALUES (?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, nh.getMaNhapHang());
            ps.setDate(2, nh.getNgayNhap());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean sua(NhapHang nh) {
        String sql = "UPDATE NhapHang SET ngayNhap = ? WHERE maNhapHang = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setDate(1, nh.getNgayNhap());
            ps.setString(2, nh.getMaNhapHang());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean xoa(String maNhapHang) {
        String sql = "DELETE FROM nhapHang WHERE maNhapHang = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, maNhapHang);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<NhapHang> getAll() {
        List<NhapHang> list = new ArrayList<>();
        String sql = "SELECT * FROM NhapHang";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                String ma = rs.getString("maNhapHang");
                Date ngay = rs.getDate("ngayNhap");
                list.add(new NhapHang(ma, ngay));
            }
            System.out.println("[DEBUG] Số lượng Nhập Hàng lấy được: " + list.size());
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public NhapHang getByMa(String maNhapHang) {
        String sql = "SELECT * FROM NhapHang WHERE maNhapHang = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, maNhapHang);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new NhapHang(
                    rs.getString("maNhapHang"),
                    rs.getDate("ngayNhap")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void themNhapHang(String ma, String ngay) {
        if (ma.isEmpty() || ngay.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Vui lòng nhập đầy đủ thông tin!");
            return;
        }
        try {
            Date date = Date.valueOf(ngay); // sẽ báo lỗi nếu sai định dạng
            NhapHang nh = new NhapHang(ma, date);
            if (them(nh)) {
                JOptionPane.showMessageDialog(null, "Thêm thành công!");
                // loadData();
            } else {
                JOptionPane.showMessageDialog(null, "Thêm thất bại! Có thể mã đã tồn tại.");
            }
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(null, "Định dạng ngày không hợp lệ! Vui lòng nhập theo định dạng yyyy-mm-dd");
        }
    }
}
