package dao;

import database.DatabaseConnection;
import entity.ChiTietHoaDon;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ChiTietHoaDonDAO {
    public List<ChiTietHoaDon> getAll() {
        List<ChiTietHoaDon> list = new ArrayList<>();
        String sql = "SELECT cthd.maHoaDon, cthd.maThuoc, thuoc.tenThuoc, cthd.soLuong " +
                     "FROM ChiTietHoaDon cthd " +
                     "JOIN Thuoc thuoc ON cthd.maThuoc = thuoc.maThuoc";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                list.add(new ChiTietHoaDon(
                    rs.getString("maHoaDon"),
                    rs.getString("maThuoc"),
                    rs.getString("tenThuoc"), // Thêm tenThuoc
                    rs.getInt("soLuong")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

      public boolean insert(ChiTietHoaDon cthd) {
       String sql = "INSERT INTO ChiTietHoaDon (maHoaDon, maThuoc, soLuong) VALUES (?, ?, ?)";
       try (Connection conn = DatabaseConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql)) {
           ps.setString(1, cthd.getMaHoaDon());
           ps.setString(2, cthd.getMaThuoc());
           ps.setInt(3, cthd.getSoLuong());
           return ps.executeUpdate() > 0;
       } catch (SQLException e) {
           e.printStackTrace();
           return false;
       }
   }
    public boolean delete(String maHD, String maThuoc) {
        String sql = "DELETE FROM ChiTietHoaDon WHERE maHoaDon = ? AND maThuoc = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, maHD);
            ps.setString(2, maThuoc);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
      public boolean sua(ChiTietHoaDon cthd) {
       String sql = "UPDATE ChiTietHoaDon SET soLuong = ? WHERE maHoaDon = ? AND maThuoc = ?";
       try (Connection conn = DatabaseConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql)) {
           ps.setInt(1, cthd.getSoLuong());
           ps.setString(2, cthd.getMaHoaDon());
           ps.setString(3, cthd.getMaThuoc());
           return ps.executeUpdate() > 0;
       } catch (SQLException e) {
           e.printStackTrace();
           return false;
       }
      }
}
