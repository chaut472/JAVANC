package dao;

import database.DatabaseConnection;
import entity.User;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UserDAO {
    private Connection conn;
    
    public UserDAO() throws SQLException {
        try {
            conn = DatabaseConnection.getConnection();
            if (conn == null) {
                throw new SQLException("Không thể kết nối đến database");
            }
        } catch (SQLException e) {
            System.out.println("Lỗi kết nối database: " + e.getMessage());
            e.printStackTrace();
            throw e;
        }
    }
    
    public boolean themUser(User user) {
        String sql = "INSERT INTO Users (MaUser, TenUser, MatKhau, Email, SoDienThoai, VaiTro, NgayTao, TrangThai) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, user.getMaUser());
            stmt.setString(2, user.getTenUser());
            stmt.setString(3, user.getMatKhau());
            stmt.setString(4, user.getEmail());
            stmt.setString(5, user.getSoDienThoai());
            stmt.setString(6, user.getVaiTro());
            stmt.setDate(7, new java.sql.Date(user.getNgayTao().getTime()));
            stmt.setBoolean(8, user.isTrangThai());
            
            int result = stmt.executeUpdate();
            System.out.println("Thêm user thành công: " + user.getMaUser());
            return result > 0;
        } catch (SQLException e) {
            System.out.println("Lỗi thêm user: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    public User timUserTheoMa(String maUser) {
        String sql = "SELECT * FROM Users WHERE MaUser = ?";
        
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, maUser);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return taoUserTuResultSet(rs);
                }
            }
        } catch (SQLException e) {
            System.out.println("Lỗi tìm user theo mã: " + e.getMessage());
            e.printStackTrace();
        }
        
        return null;
    }
    
    public User timUserTheoEmail(String email) {
        String sql = "SELECT * FROM Users WHERE Email = ?";
        
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, email);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return taoUserTuResultSet(rs);
                }
            }
        } catch (SQLException e) {
            System.out.println("Lỗi tìm user theo email: " + e.getMessage());
            e.printStackTrace();
        }
        
        return null;
    }
    
    public List<User> layTatCaUsers() {
        List<User> users = new ArrayList<>();
        String sql = "SELECT * FROM Users";
        
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                users.add(taoUserTuResultSet(rs));
            }
        } catch (SQLException e) {
            System.out.println("Lỗi lấy danh sách users: " + e.getMessage());
            e.printStackTrace();
        }
        
        return users;
    }
    
    public boolean capNhatUser(User user) {
        String sql = "UPDATE Users SET TenUser = ?, MatKhau = ?, Email = ?, " +
                    "SoDienThoai = ?, VaiTro = ?, TrangThai = ? WHERE MaUser = ?";
        
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, user.getTenUser());
            stmt.setString(2, user.getMatKhau());
            stmt.setString(3, user.getEmail());
            stmt.setString(4, user.getSoDienThoai());
            stmt.setString(5, user.getVaiTro());
            stmt.setBoolean(6, user.isTrangThai());
            stmt.setString(7, user.getMaUser());
            
            int result = stmt.executeUpdate();
            System.out.println("Cập nhật user thành công: " + user.getMaUser());
            return result > 0;
        } catch (SQLException e) {
            System.out.println("Lỗi cập nhật user: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    public boolean xoaUser(String maUser) {
        String sql = "DELETE FROM Users WHERE MaUser = ?";
        
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, maUser);
            int result = stmt.executeUpdate();
            System.out.println("Xóa user thành công: " + maUser);
            return result > 0;
        } catch (SQLException e) {
            System.out.println("Lỗi xóa user: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    private User taoUserTuResultSet(ResultSet rs) throws SQLException {
        User user = new User();
        user.setMaUser(rs.getString("MaUser"));
        user.setTenUser(rs.getString("TenUser"));
        user.setMatKhau(rs.getString("MatKhau"));
        user.setEmail(rs.getString("Email"));
        user.setSoDienThoai(rs.getString("SoDienThoai"));
        user.setVaiTro(rs.getString("VaiTro"));
        user.setNgayTao(rs.getDate("NgayTao"));
        user.setTrangThai(rs.getBoolean("TrangThai"));
        return user;
    }
} 