package dao;

import entity.ChiTietNhapHang;
import database.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ChiTietNhapHangDAO {
    private Connection conn;

    public ChiTietNhapHangDAO() {
        try {
            conn = DatabaseConnection.getConnection();
            if (conn == null) {
                throw new SQLException("Unable to connect to the database.");
            }
        } catch (SQLException e) {
            System.err.println("Error initializing ChiTietNhapHangDAO: " + e.getMessage());
            e.printStackTrace();
        }
    }

        public List<ChiTietNhapHang> getAll() {
        List<ChiTietNhapHang> list = new ArrayList<>();
        String sql = "SELECT * FROM ChiTietNhapHang";
        try {
            if (conn == null || conn.isClosed()) {
                conn = DatabaseConnection.getConnection(); // Re-establish connection
            }
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(sql)) {
                while (rs.next()) {
                    ChiTietNhapHang ct = new ChiTietNhapHang(
                        rs.getString("maNhapHang"),
                        rs.getString("maThuoc"),
                        rs.getInt("soLuong"),
                        rs.getDouble("giaNhap")
                    );
                    list.add(ct);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving ChiTietNhapHang list: " + e.getMessage());
            e.printStackTrace();
        }
        return list;
    }
    

    public boolean add(ChiTietNhapHang ct) {
        String sql = "INSERT INTO ChiTietNhapHang (maNhapHang, maThuoc, soLuong, giaNhap) VALUES (?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, ct.getMaNhapHang());
            ps.setString(2, ct.getMaThuoc());
            ps.setInt(3, ct.getSoLuong());
            ps.setDouble(4, ct.getGiaNhap());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error adding ChiTietNhapHang: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    public boolean update(ChiTietNhapHang ct) {
        String sql = "UPDATE ChiTietNhapHang SET soLuong = ?, giaNhap = ? WHERE maNhapHang = ? AND maThuoc = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, ct.getSoLuong());
            ps.setDouble(2, ct.getGiaNhap());
            ps.setString(3, ct.getMaNhapHang());
            ps.setString(4, ct.getMaThuoc());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error updating ChiTietNhapHang: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    public boolean delete(String maNhapHang, String maThuoc) {
        String sql = "DELETE FROM ChiTietNhapHang WHERE maNhapHang = ? AND maThuoc = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, maNhapHang);
            ps.setString(2, maThuoc);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error deleting ChiTietNhapHang: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    public ChiTietNhapHang getByMa(String maNhapHang, String maThuoc) {
        String sql = "SELECT * FROM ChiTietNhapHang WHERE maNhapHang = ? AND maThuoc = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, maNhapHang);
            ps.setString(2, maThuoc);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new ChiTietNhapHang(
                        rs.getString("maNhapHang"),
                        rs.getString("maThuoc"),
                        rs.getInt("soLuong"),
                        rs.getDouble("giaNhap")
                    );
                }
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving ChiTietNhapHang: " + e.getMessage());
            e.printStackTrace();
        }
        return null;
    }
}
