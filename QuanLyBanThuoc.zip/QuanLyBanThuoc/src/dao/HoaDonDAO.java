package dao;

import database.DatabaseConnection;
import static database.DatabaseConnection.getConnection;
import entity.HoaDon;
import entity.User;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class HoaDonDAO {
    private Connection conn;

    public HoaDonDAO() throws SQLException {
        conn = DatabaseConnection.getConnection();
        if (conn == null) {
            throw new SQLException("Unable to connect to the database.");
        }
    }

    public List<HoaDon> getAll() {
        List<HoaDon> list = new ArrayList<>();
        String sql = "SELECT * FROM HoaDon";
        try {
            if (conn == null || conn.isClosed()) {
                conn = DatabaseConnection.getConnection(); // Re-establish connection if closed
            }
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(sql)) {
                while (rs.next()) {
                    HoaDon hd = new HoaDon(
                        rs.getString("maHD"),
                        rs.getDate("ngayTaoHoaDon"),
                        rs.getString("maKH"),
                        rs.getString("diaChiDatHang"),
                        rs.getString("diaChiGiaoHang")
                    );
                    list.add(hd);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving HoaDon list: " + e.getMessage());
            e.printStackTrace();
        }
        return list;
    }

    public boolean insert(HoaDon hd) {
        if (hd == null || hd.getMaHD() == null || hd.getMaHD().trim().isEmpty()) {
            return false;
        }

        String diaChiDatHang = "Đà Nẵng";
        String diaChiGiaoHang = hd.getDiaChiGiaoHang();

        String sql = "INSERT INTO HoaDon (maHD, ngayTaoHoaDon, maKH, diaChiDatHang, diaChiGiaoHang) VALUES (?, ?, ?, ?, ?)";
        try {
            if (conn == null || conn.isClosed()) {
                conn = DatabaseConnection.getConnection(); // Re-establish connection if closed
            }
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, hd.getMaHD());
                ps.setDate(2, hd.getNgayTao());
                ps.setString(3, hd.getMaKH());
                ps.setString(4, diaChiDatHang);
                ps.setString(5, diaChiGiaoHang);
                return ps.executeUpdate() > 0;
            }
        } catch (SQLException e) {
            System.err.println("Error inserting HoaDon: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    public boolean update(HoaDon hd) {
        if (hd == null || hd.getMaHD() == null || hd.getMaHD().trim().isEmpty()) {
            return false;
        }

        String sql = "UPDATE HoaDon SET ngayTaoHoaDon=?, maKH=?, diaChiDatHang=?, diaChiGiaoHang=? WHERE maHD=?";
        try {
            if (conn == null || conn.isClosed()) {
                conn = DatabaseConnection.getConnection(); // Re-establish connection if closed
            }
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setDate(1, hd.getNgayTao());
                ps.setString(2, hd.getMaKH());
                ps.setString(3, hd.getDiaChiDatHang());
                ps.setString(4, hd.getDiaChiGiaoHang());
                ps.setString(5, hd.getMaHD());
                return ps.executeUpdate() > 0;
            }
        } catch (SQLException e) {
            System.err.println("Error updating HoaDon: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    public boolean delete(String maHD) {
    if (maHD == null || maHD.trim().isEmpty()) {
        return false;
    }

    // First, delete all ChiTietHoaDon associated with the HoaDon
    String deleteChiTietSQL = "DELETE FROM ChiTietHoaDon WHERE maHoaDon = ?"; // Updated column name
    try {
        if (conn == null || conn.isClosed()) {
            conn = DatabaseConnection.getConnection(); // Re-establish connection if closed
        }
        try (PreparedStatement ps = conn.prepareStatement(deleteChiTietSQL)) {
            ps.setString(1, maHD);
            ps.executeUpdate(); // Execute deletion of ChiTietHoaDon
        }
    } catch (SQLException e) {
        System.err.println("Error deleting ChiTietHoaDon: " + e.getMessage());
        e.printStackTrace();
        return false;
    }

    // Now delete the HoaDon itself
    String sql = "DELETE FROM HoaDon WHERE maHD=?";
    try {
        if (conn == null || conn.isClosed()) {
            conn = DatabaseConnection.getConnection(); // Re-establish connection if closed
        }
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, maHD);
            return ps.executeUpdate() > 0;
        }
    } catch (SQLException e) {
        System.err.println("Error deleting HoaDon: " + e.getMessage());
        e.printStackTrace();
        return false;
    }
}

public List<HoaDon> getByKhachHang(String maKH) {
        List<HoaDon> list = new ArrayList<>();
        String sql = "SELECT hd.* FROM HoaDon hd " +
                    "JOIN KhachHang kh ON hd.maKH = kh.maKhachHang " +
                    "WHERE kh.maKhachHang = ?";
                    
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, maKH);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    HoaDon hd = new HoaDon(
                        rs.getString("maHD"),
                        rs.getDate("ngayTaoHoaDon"),
                        rs.getString("maKH"),
                        rs.getString("diaChiDatHang"),
                        rs.getString("diaChiGiaoHang")
                    );
                    list.add(hd);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public HoaDon getByMa(String maHD) {
        if (maHD == null || maHD.trim().isEmpty()) {
            return null;
        }

        String sql = "SELECT * FROM HoaDon WHERE maHD = ?";
        try {
            if (conn == null || conn.isClosed()) {
                conn = DatabaseConnection.getConnection(); // Re-establish connection if closed
            }
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, maHD);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        return new HoaDon(
                            rs.getString("maHD"),
                            rs.getDate("ngayTaoHoaDon"),
                            rs.getString("maKH"),
                            rs.getString("diaChiDatHang"),
                            rs.getString("diaChiGiaoHang")
                        );
                    }
                }
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving HoaDon: " + e.getMessage());
            e.printStackTrace();
        }
        return null;
    }
}
