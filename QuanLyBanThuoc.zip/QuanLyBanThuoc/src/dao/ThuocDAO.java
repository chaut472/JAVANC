/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

/**
 *
 * @author Cao Thi Han
 */

import entity.Thuoc;
import java.sql.*;
import java.util.*;
import java.text.SimpleDateFormat;
import database.DatabaseConnection; // tên package chứa class kết nối

public class ThuocDAO {

    public List<Thuoc> getAll() {
        List<Thuoc> ds = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "SELECT * FROM Thuoc";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Thuoc t = new Thuoc(
                    rs.getString("MaThuoc"),
                    rs.getString("TenThuoc"),
                    rs.getDouble("GiaBan"),
                    rs.getInt("SoLuongTonKho"),
                    rs.getDate("NgaySanXuat"),
                    rs.getInt("HanSuDung"),
                    rs.getString("LinkAnh"),
                    rs.getString("MaNhaSanXuat"),
                    rs.getString("DonViTinh"),
                    rs.getString("XuatXu")
                );
                ds.add(t);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return ds;
    }

    public boolean themMoi(Thuoc t) {
        String sql = "INSERT INTO Thuoc VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, t.getMaThuoc());
            ps.setString(2, t.getTenThuoc());
            ps.setDouble(3, t.getGiaBan());
            ps.setInt(4, t.getSoLuongTonKho());
            ps.setDate(5, new java.sql.Date(t.getNgaySanXuat().getTime()));
            ps.setInt(6, t.getHanSuDung());
            ps.setString(7, t.getLinkAnh());
            ps.setString(8, t.getMaNhaSanXuat());
            ps.setString(9, t.getDonViTinh());
            ps.setString(10, t.getXuatXu());
            return ps.executeUpdate() > 0;
        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
    }
    public boolean capNhat(Thuoc t) {
        String sql = "UPDATE Thuoc SET TenThuoc = ?, GiaBan = ?, SoLuongTonKho = ?, " +
                     "NgaySanXuat = ?, HanSuDung = ?, LinkAnh = ?, MaNhaSanXuat = ?, " +
                     "DonViTinh = ?, XuatXu = ? WHERE MaThuoc = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, t.getTenThuoc());
            ps.setDouble(2, t.getGiaBan());
            ps.setInt(3, t.getSoLuongTonKho());
            ps.setDate(4, new java.sql.Date(t.getNgaySanXuat().getTime()));
            ps.setInt(5, t.getHanSuDung());
            ps.setString(6, t.getLinkAnh());
            ps.setString(7, t.getMaNhaSanXuat());
            ps.setString(8, t.getDonViTinh());
            ps.setString(9, t.getXuatXu());
            ps.setString(10, t.getMaThuoc());

            return ps.executeUpdate() > 0;
        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
    }

    public boolean xoa(String maThuoc) {
        String sql = "DELETE FROM Thuoc WHERE MaThuoc = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, maThuoc);
            return ps.executeUpdate() > 0;
        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
    }
    
    public Thuoc getByMa(String maThuoc) {
        String sql = "SELECT * FROM Thuoc WHERE MaThuoc = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, maThuoc);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new Thuoc(
                    rs.getString("MaThuoc"),
                    rs.getString("TenThuoc"),
                    rs.getDouble("GiaBan"),
                    rs.getInt("SoLuongTonKho"),
                    rs.getDate("NgaySanXuat"),
                    rs.getInt("HanSuDung"),
                    rs.getString("LinkAnh"),
                    rs.getString("MaNhaSanXuat"),
                    rs.getString("DonViTinh"),
                    rs.getString("XuatXu")
                );
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

    public boolean capNhatSoLuong(String maThuoc, int soLuongMoi) {
        String sql = "UPDATE Thuoc SET SoLuongTonKho = ? WHERE MaThuoc = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, soLuongMoi);
            ps.setString(2, maThuoc);
            return ps.executeUpdate() > 0;
        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
    }
}
