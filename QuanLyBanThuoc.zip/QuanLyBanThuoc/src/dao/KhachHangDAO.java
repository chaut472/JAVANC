/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

/**
 *
 * @author Cao Thi Han
 */


import database.DatabaseConnection;
import entity.KhachHang;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class KhachHangDAO {

    public boolean kiemTraDangNhap(String tenDangNhap, String matKhau) {
        String sql = "SELECT * FROM KhachHang WHERE tenDangNhap = ? AND matKhau = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, tenDangNhap);
            stmt.setString(2, matKhau);
            ResultSet rs = stmt.executeQuery();
            return rs.next();
        } catch (Exception e) {
            System.err.println("❌ Lỗi đăng nhập: " + e.getMessage());
            return false;
        }
    }


 
    public boolean dangKy(KhachHang kh) {
        String sql = "INSERT INTO KhachHang VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, kh.getMaKhachHang());
            stmt.setString(2, kh.getTenKhachHang());
            stmt.setString(3, kh.getDiaChi());
            stmt.setString(4, kh.getTenDangNhap());
            stmt.setString(5, kh.getMatKhau());
            stmt.setString(6, kh.getSoDienThoai());
            stmt.setDate(7, new java.sql.Date(kh.getNgaySinh().getTime()));
            stmt.setString(8, kh.getEmail());
            stmt.setBoolean(9, kh.isAdmin());
            return stmt.executeUpdate() > 0;
        } catch (Exception e) {
            System.err.println("❌ Lỗi đăng ký: " + e.getMessage());
            return false;
        }
    }
    public KhachHang getByMa(String maKH) {
        if (maKH == null) {
            return null;
        }
        
        String sql = "SELECT DISTINCT kh.* FROM KhachHang kh " +
                    "LEFT JOIN HoaDon hd ON kh.maKhachHang = hd.maKH " +
                    "WHERE kh.maKhachHang = ?";
                    
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, maKH);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    KhachHang kh = new KhachHang(
                        rs.getString("maKhachHang"),
                        rs.getString("tenKhachHang"),
                        rs.getString("diaChi"),
                        rs.getString("tenDangNhap"),
                        rs.getString("matKhau"),
                        rs.getString("soDienThoai"),
                        rs.getDate("ngaySinh"),
                        rs.getString("email")
                    );
                    kh.setAdmin(rs.getBoolean("isAdmin"));
                    return kh;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    // Lấy danh sách khách hàng
    public List<KhachHang> getAll() {
        List<KhachHang> list = new ArrayList<>();
        String sql = "SELECT * FROM KhachHang";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                KhachHang kh = new KhachHang(
                    rs.getString("maKhachHang"),
                    rs.getString("tenKhachHang"),
                    rs.getString("diaChi"),
                    rs.getString("tenDangNhap"),
                    rs.getString("matKhau"),
                    rs.getString("soDienThoai"),
                    rs.getDate("ngaySinh"),
                    rs.getString("email")
                );
                kh.setAdmin(rs.getBoolean("isAdmin"));
                list.add(kh);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    // Cập nhật thông tin khách hàng
    public boolean sua(KhachHang kh) {
        String sql = "UPDATE KhachHang SET tenKhachHang = ?, diaChi = ?, tenDangNhap = ?, matKhau = ?, soDienThoai = ?, ngaySinh = ?, email = ?, isAdmin = ? WHERE maKhachHang = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {

            pst.setString(1, kh.getTenKhachHang());
            pst.setString(2, kh.getDiaChi());
            pst.setString(3, kh.getTenDangNhap());
            pst.setString(4, kh.getMatKhau());
            pst.setString(5, kh.getSoDienThoai());
            pst.setDate(6, new java.sql.Date(kh.getNgaySinh().getTime()));
            pst.setString(7, kh.getEmail());
            pst.setBoolean(8, kh.isAdmin());
            pst.setString(9, kh.getMaKhachHang());

            int rowsAffected = pst.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Thêm khách hàng mới
    public boolean insert(KhachHang kh) {
        String sql = "INSERT INTO KhachHang (maKhachHang, tenKhachHang, diaChi, tenDangNhap, matKhau, soDienThoai, ngaySinh, email, isAdmin) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, kh.getMaKhachHang());
            ps.setString(2, kh.getTenKhachHang());
            ps.setString(3, kh.getDiaChi());
            ps.setString(4, kh.getTenDangNhap());
            ps.setString(5, kh.getMatKhau());
            ps.setString(6, kh.getSoDienThoai());
            ps.setDate(7, new java.sql.Date(kh.getNgaySinh().getTime()));
            ps.setString(8, kh.getEmail());
            ps.setBoolean(9, kh.isAdmin());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Xóa khách hàng
    public boolean delete(String maKhachHang) {
        String sql = "DELETE FROM KhachHang WHERE maKhachHang = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, maKhachHang);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
