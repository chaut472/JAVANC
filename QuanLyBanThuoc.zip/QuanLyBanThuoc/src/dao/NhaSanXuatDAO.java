/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

/**
 *
 * @author Cao Thi Han
 */

import entity.NhaSanXuat;
import database.DatabaseConnection;

import java.sql.*;
import java.util.*;

public class NhaSanXuatDAO {
    
    // Lấy tất cả nhà sản xuất
    public List<NhaSanXuat> getAll() {
        List<NhaSanXuat> list = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "SELECT * FROM NhaSanXuat";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                ResultSet rs = stmt.executeQuery();
                while (rs.next()) {
                    list.add(new NhaSanXuat(
                            rs.getString("maNhaSanXuat"),
                            rs.getString("tenNhaSanXuat"),
                            rs.getString("diaChi"),
                            rs.getString("SDT")
                    ));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    // Cập nhật nhà sản xuất
    public boolean sua(NhaSanXuat nsx) {
        String sql = "UPDATE NhaSanXuat SET tenNhaSanXuat = ?, diaChi = ?, sdt = ? WHERE maNhaSanXuat = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, nsx.getTenNhaSanXuat());
            stmt.setString(2, nsx.getDiaChi());
            stmt.setString(3, nsx.getSdt());
            stmt.setString(4, nsx.getMaNhaSanXuat());
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    // Thêm nhà sản xuất mới
    public boolean insert(NhaSanXuat nsx) {
        String sql = "INSERT INTO NhaSanXuat (maNhaSanXuat, tenNhaSanXuat, diaChi, SDT) VALUES (?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, nsx.getMaNhaSanXuat());
            ps.setString(2, nsx.getTenNhaSanXuat());
            ps.setString(3, nsx.getDiaChi());
            ps.setString(4, nsx.getSdt());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // Xóa nhà sản xuất theo mã
    public boolean delete(String maNSX) {
        String sql = "DELETE FROM NhaSanXuat WHERE maNhaSanXuat = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, maNSX);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
