/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

/**
 *
 * @author Cao Thi Han
 */

import java.sql.Date;

public class HoaDon {

    public String getMaHD() {
        return maHD;
    }

    public void setMaHD(String maHD) {
        this.maHD = maHD;
    }

    public Date getNgayTao() {
        return ngayTao;
    }

    public void setNgayTao(Date ngayTao) {
        this.ngayTao = ngayTao;
    }

    public String getMaKH() {
        return maKH;
    }

    public void setMaKH(String maKH) {
        this.maKH = maKH;
    }

    public String getDiaChiDatHang() {
        return diaChiDatHang;
    }

    public void setDiaChiDatHang(String diaChiDatHang) {
        this.diaChiDatHang = diaChiDatHang;
    }

    public String getDiaChiGiaoHang() {
        return diaChiGiaoHang;
    }

    public void setDiaChiGiaoHang(String diaChiGiaoHang) {
        this.diaChiGiaoHang = diaChiGiaoHang;
    }
    private String maHD;
    private Date ngayTao;
    private String maKH;
    private String diaChiDatHang;
    private String diaChiGiaoHang;

    public HoaDon(String maHD, Date ngayTao, String maKH, String diaChiDatHang, String diaChiGiaoHang) {
        this.maHD = maHD;
        this.ngayTao = ngayTao;
        this.maKH = maKH;
        this.diaChiDatHang = diaChiDatHang;
        this.diaChiGiaoHang = diaChiGiaoHang;
    }

   
}

