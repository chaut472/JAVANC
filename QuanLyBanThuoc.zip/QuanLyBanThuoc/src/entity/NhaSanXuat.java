/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

/**
 *
 * @author Cao Thi Han
 */

public class NhaSanXuat {
    private String maNhaSanXuat;
    private String tenNhaSanXuat;
    private String diaChi;
    private String sdt;

    public NhaSanXuat(String ma, String ten, String diaChi, String sdt) {
        this.maNhaSanXuat = ma;
        this.tenNhaSanXuat = ten;
        this.diaChi = diaChi;
        this.sdt = sdt;
    }

    // Getters & Setters

    public String getMaNhaSanXuat() {
        return maNhaSanXuat;
    }

    public void setMaNhaSanXuat(String maNhaSanXuat) {
        this.maNhaSanXuat = maNhaSanXuat;
    }

    public String getTenNhaSanXuat() {
        return tenNhaSanXuat;
    }

    public void setTenNhaSanXuat(String tenNhaSanXuat) {
        this.tenNhaSanXuat = tenNhaSanXuat;
    }

    public String getDiaChi() {
        return diaChi;
    }

    public void setDiaChi(String diaChi) {
        this.diaChi = diaChi;
    }

    public String getSdt() {
        return sdt;
    }

    public void setSdt(String sdt) {
        this.sdt = sdt;
    }
 
}

