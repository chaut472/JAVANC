/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;
/**
 *
 * @author Cao Thi Han
 */
public class ChiTietNhapHang {

    public String getMaNhapHang() {
        return maNhapHang;
    }

    public void setMaNhapHang(String maNhapHang) {
        this.maNhapHang = maNhapHang;
    }

    public String getMaThuoc() {
        return maThuoc;
    }

    public void setMaThuoc(String maThuoc) {
        this.maThuoc = maThuoc;
    }

    public int getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(int soLuong) {
        this.soLuong = soLuong;
    }

    public double getGiaNhap() {
        return giaNhap;
    }

    public void setGiaNhap(double giaNhap) {
        this.giaNhap = giaNhap;
    }
    private String maNhapHang;
    private String maThuoc;
    private int soLuong;
    private double giaNhap;

    public ChiTietNhapHang(String maNhapHang, String maThuoc, int soLuong, double giaNhap) {
        this.maNhapHang = maNhapHang;
        this.maThuoc = maThuoc;
        this.soLuong = soLuong;
        this.giaNhap = giaNhap;
    }
}
