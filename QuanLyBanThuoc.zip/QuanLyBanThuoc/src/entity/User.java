package entity;

import java.util.Date;

public class User {
    private String maUser;
    private String tenUser;
    private String matKhau;
    private String email;
    private String soDienThoai;
    private String vaiTro;
    private Date ngayTao;
    private boolean trangThai;

    public User() {
        this.ngayTao = new Date();
        this.trangThai = true;
        this.vaiTro = "USER";
    }

    public User(String maUser, String tenUser, String matKhau, String email, String soDienThoai) {
        this();
        this.maUser = maUser;
        this.tenUser = tenUser;
        this.matKhau = matKhau;
        this.email = email;
        this.soDienThoai = soDienThoai;
    }

    // Getters and Setters
    public String getMaUser() {
        return maUser;
    }

    public void setMaUser(String maUser) {
        this.maUser = maUser;
    }

    public String getTenUser() {
        return tenUser;
    }

    public void setTenUser(String tenUser) {
        this.tenUser = tenUser;
    }

    public String getMatKhau() {
        return matKhau;
    }

    public void setMatKhau(String matKhau) {
        this.matKhau = matKhau;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSoDienThoai() {
        return soDienThoai;
    }

    public void setSoDienThoai(String soDienThoai) {
        this.soDienThoai = soDienThoai;
    }

    public String getVaiTro() {
        return vaiTro;
    }

    public void setVaiTro(String vaiTro) {
        this.vaiTro = vaiTro;
    }

    public Date getNgayTao() {
        return ngayTao;
    }

    public void setNgayTao(Date ngayTao) {
        this.ngayTao = ngayTao;
    }

    public boolean isTrangThai() {
        return trangThai;
    }

    public void setTrangThai(boolean trangThai) {
        this.trangThai = trangThai;
    }

    @Override
    public String toString() {
        return "User{" +
                "maUser='" + maUser + '\'' +
                ", tenUser='" + tenUser + '\'' +
                ", email='" + email + '\'' +
                ", vaiTro='" + vaiTro + '\'' +
                '}';
    }
} 