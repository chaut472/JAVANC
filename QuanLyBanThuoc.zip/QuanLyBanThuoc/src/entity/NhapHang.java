/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

/**
 *
 * @author Cao Thi Han
 */

import java.sql.Date;

public class NhapHang {
    private String maNhapHang;
    private Date ngayNhap;

    public NhapHang(String maNhapHang, Date ngayNhap) {
        this.maNhapHang = maNhapHang;
        this.ngayNhap = ngayNhap;
    }

    public String getMaNhapHang() {
        return maNhapHang;
    }

    public void setMaNhapHang(String maNhapHang) {
        this.maNhapHang = maNhapHang;
    }

    public Date getNgayNhap() {
        return ngayNhap;
    }

    public void setNgayNhap(Date ngayNhap) {
        this.ngayNhap = ngayNhap;
    }
}
