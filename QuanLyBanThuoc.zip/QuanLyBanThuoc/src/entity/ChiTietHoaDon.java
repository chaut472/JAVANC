package entity;

/**
 *
 * @author Cao Thi Han
 */
public class ChiTietHoaDon {

    private String maHoaDon;
    private String maThuoc;
    private String tenThuoc;
    private int soLuong;

    public ChiTietHoaDon(String maHoaDon, String maThuoc, String tenThuoc, int soLuong) {
        this.maHoaDon = maHoaDon;
        this.maThuoc = maThuoc;
        this.tenThuoc = tenThuoc; 
        this.soLuong = soLuong;
    }
    public String getMaHoaDon() {
        return maHoaDon;
    }
    public void setMaHoaDon(String maHoaDon) {
        this.maHoaDon = maHoaDon;
    }
    public String getMaThuoc() {
        return maThuoc;
    }
    public void setMaThuoc(String maThuoc) {
        this.maThuoc = maThuoc;
    }
    public String getTenThuoc() {
        return tenThuoc;
    }
    public void setTenThuoc(String tenThuoc) { 
        this.tenThuoc = tenThuoc; 
    }
    public int getSoLuong() {
        return soLuong;
    }
    public void setSoLuong(int soLuong) {
        this.soLuong = soLuong;
    }
}
