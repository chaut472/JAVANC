package bus;

import dao.ThuocDAO;
import entity.Thuoc;

import java.util.List;

public class ThuocBUS {
    private ThuocDAO dao = new ThuocDAO();

    public List<Thuoc> getAll() {
        return dao.getAll();
    }
    public boolean capNhat(Thuoc t) {
        return dao.capNhat(t);
    }

    public boolean themMoi(Thuoc t) {
        for (Thuoc thuoc : dao.getAll()) {
            if (thuoc.getMaThuoc().equalsIgnoreCase(t.getMaThuoc())) {
                return false; // Mã đã tồn tại
            }
        }
        return dao.themMoi(t);
    }
public boolean capNhatSoLuong(String maThuoc, int soLuongMoi){
    if(soLuongMoi<0){
    return false;
    }
    return dao.capNhatSoLuong(maThuoc,soLuongMoi);
}
public Thuoc getByMa(String maThuoc)
{
    return dao.getByMa(maThuoc);
}
    public boolean xoa(String maThuoc) {
        return dao.xoa(maThuoc);
    }
}