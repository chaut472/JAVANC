package bus;
import dao.ChiTietHoaDonDAO;
import dao.ThuocDAO;
import entity.ChiTietHoaDon;
import entity.Thuoc;
import java.util.List;
public class ChiTietHoaDonBUS {
    private ChiTietHoaDonDAO dao = new ChiTietHoaDonDAO();
    private ThuocDAO thuocDAO= new ThuocDAO();

    public List<ChiTietHoaDon> getAll() {
        return dao.getAll();
    }

    public boolean them(ChiTietHoaDon cthd) {
        return dao.insert(cthd);
    }

    public boolean xoa(String maHD, String maThuoc) {
        return dao.delete(maHD, maThuoc);
    }
    public boolean sua(ChiTietHoaDon cthd) {
        return dao.sua(cthd);
    }
    public double tinhTongTien(String maHD) {
        try {
            List<ChiTietHoaDon> chiTietList = getByHoaDon(maHD);
            double tongTien = 0;
            
            for (ChiTietHoaDon chiTiet : chiTietList) {
                Thuoc thuoc = thuocDAO.getByMa(chiTiet.getMaThuoc());
                if (thuoc != null) {
                    tongTien += thuoc.getGiaBan() * chiTiet.getSoLuong();
                }
            }
            
            return tongTien;
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }
    public List<ChiTietHoaDon> getByHoaDon(String maHD) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}