package bus;

import dao.NhapHangDAO;
import entity.NhapHang;

import java.util.List;
import java.sql.SQLException;

public class NhapHangBUS {
    private NhapHangDAO dao;

    public NhapHangBUS() throws SQLException {
        dao = new NhapHangDAO();
    }

    public List<NhapHang> getAll() {
        return dao.getAll();
    }
    
    public boolean sua(NhapHang nh) {
        return dao.sua(nh);
    }

    public boolean xoa(String maNhapHang) {
        return dao.xoa(maNhapHang);
    }
    
    public boolean them(NhapHang nh) {
        return dao.them(nh);
    }
    
    public NhapHang getByMa(String maNhapHang) {
        return dao.getByMa(maNhapHang);
    }
}