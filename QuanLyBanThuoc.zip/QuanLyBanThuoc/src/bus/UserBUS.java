package bus;

import dao.UserDAO;
import entity.User;
import java.util.List;
import java.sql.SQLException;

public class UserBUS {
    private UserDAO userDAO;
    
    public UserBUS() throws Exception {
        try {
            userDAO = new UserDAO();
            if (userDAO == null) {
                throw new Exception("Không thể khởi tạo UserDAO");
            }
        } catch (SQLException e) {
            System.out.println("Lỗi kết nối database: " + e.getMessage());
            e.printStackTrace();
            throw e;
        } catch (Exception e) {
            System.out.println("Lỗi khởi tạo UserBUS: " + e.getMessage());
            e.printStackTrace();
            throw e;
        }
    }
    
    public boolean dangKy(User user) {
        try {
            // Kiểm tra email đã tồn tại chưa
            if (userDAO.timUserTheoEmail(user.getEmail()) != null) {
                System.out.println("Email đã tồn tại: " + user.getEmail());
                return false;
            }
            
            // Thêm user mới
            boolean result = userDAO.themUser(user);
            if (result) {
                System.out.println("Đăng ký thành công cho user: " + user.getEmail());
            } else {
                System.out.println("Đăng ký thất bại cho user: " + user.getEmail());
            }
            return result;
        } catch (Exception e) {
            System.out.println("Lỗi đăng ký: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    public User dangNhap(String email, String matKhau) {
        try {
            System.out.println("Đang đăng nhập với email: " + email);
            
            // Tìm user theo email
            User user = userDAO.timUserTheoEmail(email);
            
            if (user == null) {
                System.out.println("Không tìm thấy user với email: " + email);
                return null;
            }
            
            // Kiểm tra mật khẩu
            if (!user.getMatKhau().equals(matKhau)) {
                System.out.println("Mật khẩu không đúng cho user: " + email);
                return null;
            }
            
            // Kiểm tra trạng thái
            if (!user.isTrangThai()) {
                System.out.println("Tài khoản đã bị khóa: " + email);
                return null;
            }
            
            System.out.println("Đăng nhập thành công cho user: " + email);
            return user;
        } catch (Exception e) {
            System.out.println("Lỗi đăng nhập: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }
    
    public boolean capNhatThongTin(User user) {
        try {
            // Kiểm tra user tồn tại
            User existingUser = userDAO.timUserTheoMa(user.getMaUser());
            if (existingUser == null) {
                System.out.println("Không tìm thấy user để cập nhật: " + user.getMaUser());
                return false;
            }
            
            // Kiểm tra email mới có bị trùng không
            User userWithEmail = userDAO.timUserTheoEmail(user.getEmail());
            if (userWithEmail != null && !userWithEmail.getMaUser().equals(user.getMaUser())) {
                System.out.println("Email đã tồn tại: " + user.getEmail());
                return false;
            }
            
            // Cập nhật thông tin
            boolean result = userDAO.capNhatUser(user);
            if (result) {
                System.out.println("Cập nhật thông tin thành công cho user: " + user.getMaUser());
            } else {
                System.out.println("Cập nhật thông tin thất bại cho user: " + user.getMaUser());
            }
            return result;
        } catch (Exception e) {
            System.out.println("Lỗi cập nhật thông tin: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    public boolean doiMatKhau(String maUser, String matKhauCu, String matKhauMoi) {
        try {
            // Tìm user
            User user = userDAO.timUserTheoMa(maUser);
            if (user == null) {
                System.out.println("Không tìm thấy user để đổi mật khẩu: " + maUser);
                return false;
            }
            
            // Kiểm tra mật khẩu cũ
            if (!user.getMatKhau().equals(matKhauCu)) {
                System.out.println("Mật khẩu cũ không đúng cho user: " + maUser);
                return false;
            }
            
            // Cập nhật mật khẩu mới
            user.setMatKhau(matKhauMoi);
            boolean result = userDAO.capNhatUser(user);
            if (result) {
                System.out.println("Đổi mật khẩu thành công cho user: " + maUser);
            } else {
                System.out.println("Đổi mật khẩu thất bại cho user: " + maUser);
            }
            return result;
        } catch (Exception e) {
            System.out.println("Lỗi đổi mật khẩu: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    public List<User> layTatCaUsers() {
        try {
            return userDAO.layTatCaUsers();
        } catch (Exception e) {
            System.out.println("Lỗi lấy danh sách users: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }
    
    public boolean xoaUser(String maUser) {
        try {
            boolean result = userDAO.xoaUser(maUser);
            if (result) {
                System.out.println("Xóa user thành công: " + maUser);
            } else {
                System.out.println("Xóa user thất bại: " + maUser);
            }
            return result;
        } catch (Exception e) {
            System.out.println("Lỗi xóa user: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    public User timUserTheoMa(String maUser) {
        try {
            return userDAO.timUserTheoMa(maUser);
        } catch (Exception e) {
            System.out.println("Lỗi tìm user theo mã: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }
} 