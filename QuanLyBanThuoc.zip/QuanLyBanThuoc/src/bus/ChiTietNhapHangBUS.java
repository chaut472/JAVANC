package bus;
import dao.ChiTietNhapHangDAO;
import entity.ChiTietNhapHang;
import java.util.List;
public class ChiTietNhapHangBUS {
    private ChiTietNhapHangDAO dao;
    public ChiTietNhapHangBUS() {
        dao = new ChiTietNhapHangDAO();
    }
    public List<ChiTietNhapHang> getAll() {
        return dao.getAll();
    }
    public boolean add(ChiTietNhapHang ct) {
        if (ct == null) {
            System.out.println("Invalid data for ChiTietNhapHang.");
            return false;
        }
        return dao.add(ct);
    }
    public boolean update(ChiTietNhapHang ct) {
        if (ct == null) {
            System.out.println("Invalid data for ChiTietNhapHang.");
            return false;
        }
        return dao.update(ct);
    }
    public boolean delete(String maNhapHang, String maThuoc) {
        if (maNhapHang == null || maThuoc == null) {
            System.out.println("Invalid MaNhapHang or MaThuoc.");
            return false;
        }
        return dao.delete(maNhapHang, maThuoc);
    }
}
