package bus;

import dao.NhaSanXuatDAO;
import entity.NhaSanXuat;

import java.util.List;

public class NhaSanXuatBUS {
    private NhaSanXuatDAO dao = new NhaSanXuatDAO();

    public List<NhaSanXuat> getAll() {
        return dao.getAll();
    }
    public boolean sua(NhaSanXuat nsx) {
        return dao.sua(nsx);
    }
    public boolean themMoi(NhaSanXuat nsx) {
        return dao.insert(nsx);
    }

    public boolean xoa(String ma) {
        return dao.delete(ma);
    }
}