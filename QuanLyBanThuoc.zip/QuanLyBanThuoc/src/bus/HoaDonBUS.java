package bus;

import dao.HoaDonDAO;
import entity.HoaDon;
import entity.User;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class HoaDonBUS {
    private HoaDonDAO dao;
    private ChiTietHoaDonBUS chiTietHoaDonBUS = new ChiTietHoaDonBUS();
    public HoaDonBUS() throws SQLException {
        try {
            dao = new HoaDonDAO();
        } catch (SQLException e) {
            System.out.println("Lỗi kết nối database: " + e.getMessage());
            e.printStackTrace();
            throw e;
        }
    }

    public List<HoaDon> getAll() {
        try {
            return dao.getAll();
        } catch (Exception e) {
            System.out.println("Lỗi lấy danh sách hóa đơn: " + e.getMessage());
            e.printStackTrace();
            return new ArrayList<>();
        }
    }
   public int countOrdersByUser(User user) {
        return getByUser(user).size();
    }

    public double getTotalSpendingByUser(User user) {
        try {
            List<HoaDon> userOrders = getByUser(user);
            double totalSpending = 0;
            
            for (HoaDon hoaDon : userOrders) {
                try {
                    totalSpending += chiTietHoaDonBUS.tinhTongTien(hoaDon.getMaHD());
                } catch (Exception e) {
                    // Skip failed calculations
                    System.out.println("Lỗi tính tổng tiền cho hóa đơn " + hoaDon.getMaHD() + ": " + e.getMessage());
                    e.printStackTrace();
                }
            }
            
            return totalSpending;
        } catch (Exception e) {
            System.out.println("Lỗi tính tổng chi tiêu: " + e.getMessage());
            e.printStackTrace();
            return 0.0;
        }
    }
    public boolean them(HoaDon hd) {
        try {
            return dao.insert(hd);
        } catch (Exception e) {
            System.out.println("Lỗi thêm hóa đơn: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    public boolean sua(HoaDon hd) {
        try {
            return dao.update(hd);
        } catch (Exception e) {
            System.out.println("Lỗi cập nhật hóa đơn: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    public boolean xoa(String maHD) {
        try {
            return dao.delete(maHD);
        } catch (Exception e) {
            System.out.println("Lỗi xóa hóa đơn: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
   
    public String getLastOrderDateByUser(User user) {
        List<HoaDon> userOrders = getByUser(user);
        if (!userOrders.isEmpty()) {
            // Sort by date descending and get the first one
            userOrders.sort((a, b) -> b.getNgayTao().compareTo(a.getNgayTao()));
            return userOrders.get(0).getNgayTao().toString();
        }
        return "Chưa có đơn hàng";
    }
    public HoaDon getByMa(String maHD) {
        try {
            return dao.getByMa(maHD);
        } catch (Exception e) {
            System.out.println("Lỗi tìm hóa đơn theo mã: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }

    public List<HoaDon> getByUser(User currentUser) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
