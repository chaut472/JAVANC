package bus;
import java.sql.Connection;
import dao.KhachHangDAO;
import database.DatabaseConnection;
import entity.KhachHang;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.List;

public class KhachHangBUS {
    private KhachHangDAO dao = new KhachHangDAO();

     public boolean kiemTraDangNhap(String tenDangNhap, String matKhau) {
        return dao.kiemTraDangNhap(tenDangNhap, matKhau);
    }
    public List<KhachHang> getAll() {
        return dao.getAll();
    }

    public boolean them(KhachHang kh) {
        return dao.insert(kh);
    }
    public boolean sua(KhachHang kh) {
        return dao.sua(kh);
    }

    public boolean xoa(String maKH) {
        return dao.delete(maKH);
    }
public boolean dangKy(KhachHang kh) {
        return dao.dangKy(kh);
    }
public String taoMaKhachHangTuDong() {
    String sql = "SELECT MAX(maKhachHang) FROM KhachHang";
    String newMa = null;

    try (Connection conn = DatabaseConnection.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql);
         ResultSet rs = ps.executeQuery()) {

        if (rs.next()) {
            String maxMa = rs.getString(1);
            if (maxMa != null && maxMa.startsWith("KH") && maxMa.length() == 6) {
                try {
                    int num = Integer.parseInt(maxMa.substring(2));
                    num++;
                    newMa = String.format("KH%04d", num);
                } catch (NumberFormatException ex) {
                    ex.printStackTrace();
                    // Nếu lỗi parse, newMa vẫn là null
                }
            }
        }
        if (newMa == null) {
            newMa = "KH0001";
        }
    } catch (SQLException e) {
        e.printStackTrace();
        newMa = "KH0001"; // fallback nếu lỗi DB
    }

    return newMa;
}
public KhachHang getByMa(String maKH)
 {
     if(maKH==null||maKH.trim().isEmpty()){
         return null;
     }
     return dao.getByMa(maKH);
 }
}