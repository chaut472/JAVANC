-- Xóa database nếu tồn tại
USE master;
GO

IF EXISTS (SELECT name FROM sys.databases WHERE name = N'QUANLY_QUAYTHUOC')
BEGIN
    ALTER DATABASE QUANLY_QUAYTHUOC SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE QUANLY_QUAYTHUOC;
END
GO

-- Tạo lại database
CREATE DATABASE QUANLY_QUAYTHUOC;
GO

USE QUANLY_QUAYTHUOC;
GO

-- Bảng NhaSanXuat
CREATE TABLE NhaSanXuat (
    maNhaSanXuat char(10) PRIMARY KEY,
    tenNhaSanXuat NVARCHAR(100),
    diaChi NVARCHAR(200),
    SDT VARCHAR(15)
);

-- Bảng Thuoc
CREATE TABLE Thuoc (
    maThuoc char(10) PRIMARY KEY,
    tenThuoc NVARCHAR(100),
    GiaBan DECIMAL(18,2),
    soLuongTonKho INT,
    ngaySanXuat DATE,
	hanSuDung int,
	linkAnh VARCHAR(100),
    maNhaSanXuat char(10),
    donViTinh NVARCHAR(50),
    XuatXu NVARCHAR(100),
	loaiThuoc nvarchar(50),
    FOREIGN KEY (maNhaSanXuat) REFERENCES NhaSanXuat(maNhaSanXuat)
);

-- Bảng KhachHang
CREATE TABLE KhachHang (
    maKhachHang char(10) PRIMARY KEY,
    tenKhachHang NVARCHAR(100),
    diaChi NVARCHAR(200),
    tenDangNhap NVARCHAR(50),
    matKhau NVARCHAR(100),
	soDienThoai varchar(10),
	ngaySinh date,
	email VARCHAR(50),
	isAdmin bit
);

-- Bảng HoaDon
CREATE TABLE HoaDon (
    maHD char(10) PRIMARY KEY,
    ngayTaoHoaDon DATE,
    maKH char(10),
    diaChiDatHang NVARCHAR(200),
    diaChiGiaoHang NVARCHAR(200),
    FOREIGN KEY (maKH) REFERENCES KhachHang(maKhachHang)
);

-- Bảng NhapHang
CREATE TABLE NhapHang (
    maNhapHang char(10) PRIMARY KEY  ,
    ngayNhap DATE
);

-- Bảng ChiTietNhapHang
CREATE TABLE ChiTietNhapHang (
    maNhapHang char(10),
    maThuoc char(10),
    soLuong INT,
    giaNhap DECIMAL(18,2),
    PRIMARY KEY (maNhapHang, maThuoc),
    FOREIGN KEY (maNhapHang) REFERENCES NhapHang(maNhapHang) ON DELETE NO ACTION,
    FOREIGN KEY (maThuoc) REFERENCES Thuoc(maThuoc) ON DELETE NO ACTION
);

-- Bảng ChiTietHoaDon
CREATE TABLE ChiTietHoaDon (
    maHoaDon char(10),
    maThuoc char(10),
    soLuong INT,
    PRIMARY KEY (maHoaDon, maThuoc),
    FOREIGN KEY (maHoaDon) REFERENCES HoaDon(maHD) ON DELETE NO ACTION,
    FOREIGN KEY (maThuoc) REFERENCES Thuoc(maThuoc) ON DELETE NO ACTION
);


INSERT INTO NhaSanXuat VALUES
('NSX0000001', N'ABC Pharma', N'123 Hùng Vương, Q. Hải Châu, Đà Nẵng', '0901234567'),
('NSX0000002', N'VN Medico', N'456 Nguyễn Văn Linh, Q. Thanh Khê, Đà Nẵng', '0902345678'),
('NSX0000003', N'Song Long', N'789 Trưng Nữ Vương, Q. Hải Châu, Đà Nẵng', '0903456789'),
('NSX0000004', N'Việt Dược', N'321 Ông Ích Khiêm, Q. Hải Châu, Đà Nẵng', '0904567890'),
('NSX0000005', N'Medicare', N'654 Lê Duẩn, Q. Thanh Khê, Đà Nẵng', '0905678901'),
('NSX0000006', N'Pharma Pro', N'987 Tôn Đức Thắng, Q. Liên Chiểu, Đà Nẵng', '0906789012'),
('NSX0000007', N'An Khang', N'159 Nguyễn Tất Thành, Q. Thanh Khê, Đà Nẵng', '0907890123'),
('NSX0000008', N'GreenLife', N'753 Ngô Quyền, Q. Sơn Trà, Đà Nẵng', '0908901234'),
('NSX0000009', N'Kim Long', N'852 Bạch Đằng, Q. Hải Châu, Đà Nẵng', '0909012345'),
('NSX0000010', N'Central Med', N'147 Nguyễn Hữu Thọ, Q. Hải Châu, Đà Nẵng', '0910123456');

INSERT INTO Thuoc 
(maThuoc, tenThuoc, GiaBan, soLuongTonKho, ngaySanXuat, hanSuDung, linkAnh, maNhaSanXuat, donViTinh, XuatXu, loaiThuoc) 
VALUES
('T000000001', N'Paracetamol', 5000, 100, '2026-12-31', 12, './assets/img/img_thuoc/Paracetamol.png', 'NSX0000001', N'Viên', N'Việt Nam', N'Thuốc giảm đau - hạ sốt'),
('T000000002', N'Vitamin C', 3000, 200, '2025-11-30', 12, './assets/img/img_thuoc/VitaminC.png', 'NSX0000002', N'Viên', N'Mỹ', N'Thuốc bổ sung vitamin'),
('T000000003', N'Amoxicillin', 7000, 150, '2026-01-15', 12, './assets/img/img_thuoc/Amoxicillin.png', 'NSX0000003', N'Viên', N'Pháp', N'Kháng sinh'),
('T000000004', N'Oresol', 2000, 300, '2025-10-20', 12, './assets/img/img_thuoc/Oresol.png', 'NSX0000004', N'Gói', N'Việt Nam', N'Thuốc điều trị mất nước'),
('T000000005', N'Cotrim', 8000, 80, '2027-03-01', 12, './assets/img/img_thuoc/Cotrim.png', 'NSX0000005', N'Viên', N'Anh', N'Kháng sinh'),
('T000000006', N'Salbutamol', 9500, 60, '2026-05-10', 12, './assets/img/img_thuoc/Salbutamol.png', 'NSX0000006', N'Ống', N'Đức', N'Thuốc điều trị hen suyễn'),
('T000000007', N'Loratadine', 6000, 90, '2026-09-15', 12, './assets/img/img_thuoc/Loratadine.png', 'NSX0000007', N'Viên', N'Ấn Độ', N'Thuốc chống dị ứng'),
('T000000008', N'Azithromycin', 12000, 50, '2026-07-07', 12, './assets/img/img_thuoc/Azithromycin.png', 'NSX0000008', N'Viên', N'Úc', N'Kháng sinh'),
('T000000009', N'Metoprolol', 15000, 40, '2025-08-20', 12, './assets/img/img_thuoc/Metoprolol.png', 'NSX0000009', N'Viên', N'Canada', N'Thuốc tim mạch'),
('T000000010', N'Omeprazole', 11000, 70, '2026-04-01', 12, './assets/img/img_thuoc/Omeprazole.png', 'NSX0000010', N'Viên', N'Mỹ', N'Thuốc dạ dày');

INSERT INTO KhachHang VALUES
('KH00000001', N'Nguyễn Văn A', N'12 Lê Lợi, Q. Hải Châu, Đà Nẵng', N'nguyenvana', N'123456', '0901111111', '1990-01-01', 'vana@example.com', 0),
('KH00000002', N'Trần Thị B', N'34 Nguyễn Tri Phương, Q. Thanh Khê, Đà Nẵng', N'tranthib', N'abcdef', '0902222222', '1991-02-02', 'thib@example.com', 0),
('KH00000003', N'Lê Văn C', N'56 Trần Cao Vân, Q. Thanh Khê, Đà Nẵng', N'levanc', N'qwerty', '0903333333', '1992-03-03', 'vanc@example.com', 0),
('KH00000004', N'Phạm Thị D', N'78 Điện Biên Phủ, Q. Thanh Khê, Đà Nẵng', N'phamthid', N'zxcvbn', '0904444444', '1993-04-04', 'thid@example.com', 0),
('KH00000005', N'Hoàng Văn E', N'90 Trường Sơn, Q. Cẩm Lệ, Đà Nẵng', N'hoangvane', N'asdfgh', '0905555555', '1994-05-05', 'vane@example.com', 0),
('KH00000006', N'Đỗ Thị F', N'21 Tôn Đức Thắng, Q. Liên Chiểu, Đà Nẵng', N'dothif', N'pass123', '0906666666', '1995-06-06', 'thif@example.com', 0),
('KH00000007', N'Trịnh Văn G', N'33 Ngũ Hành Sơn, Q. Ngũ Hành Sơn, Đà Nẵng', N'trinhvang', N'123abc', '0907777777', '1996-07-07', 'vang@example.com', 0),
('KH00000008', N'Bùi Thị H', N'45 Nguyễn Văn Thoại, Q. Sơn Trà, Đà Nẵng', N'buithih', N'letmein', '0908888888', '1997-08-08', 'thih@example.com', 0),
('KH00000009', N'Cao Văn I', N'67 Lê Văn Hiến, Q. Ngũ Hành Sơn, Đà Nẵng', N'caovani', N'hello123', '0909999999', '1998-09-09', 'vani@example.com', 0),
('KH00000010', N'Lý Thị J', N'89 Hoàng Sa, Q. Sơn Trà, Đà Nẵng', N'lythij', N'welcome', '0910000000', '1999-10-10', 'thij@example.com', 0),
('KH00000011', N'Nguyễn Văn Dương', N'01 Nguyễn Văn Linh, Q. Hải Châu, Đà Nẵng', N'duong2603', N'123456', '0911234567', '1990-03-26', 'duong2603@example.com', 1);


INSERT INTO HoaDon VALUES
('HD00000001', '2025-01-10', 'KH00000001', N'Q. Hải Châu, Đà Nẵng', N'Q. Hải Châu, Đà Nẵng'),
('HD00000002', '2025-01-11', 'KH00000002', N'Q. Thanh Khê, Đà Nẵng', N'Q. Thanh Khê, Đà Nẵng'),
('HD00000003', '2025-01-12', 'KH00000003', N'Q. Thanh Khê, Đà Nẵng', N'Q. Thanh Khê, Đà Nẵng'),
('HD00000004', '2025-01-13', 'KH00000004', N'Q. Thanh Khê, Đà Nẵng', N'Q. Thanh Khê, Đà Nẵng'),
('HD00000005', '2025-01-14', 'KH00000005', N'Q. Cẩm Lệ, Đà Nẵng', N'Q. Cẩm Lệ, Đà Nẵng'),
('HD00000006', '2025-01-15', 'KH00000006', N'Q. Liên Chiểu, Đà Nẵng', N'Q. Liên Chiểu, Đà Nẵng'),
('HD00000007', '2025-01-16', 'KH00000007', N'Q. Ngũ Hành Sơn, Đà Nẵng', N'Q. Ngũ Hành Sơn, Đà Nẵng'),
('HD00000008', '2025-01-17', 'KH00000008', N'Q. Sơn Trà, Đà Nẵng', N'Q. Sơn Trà, Đà Nẵng'),
('HD00000009', '2025-01-18', 'KH00000009', N'Q. Ngũ Hành Sơn, Đà Nẵng', N'Q. Ngũ Hành Sơn, Đà Nẵng'),
('HD00000010', '2025-01-19', 'KH00000010', N'Q. Sơn Trà, Đà Nẵng', N'Q. Sơn Trà, Đà Nẵng');

INSERT INTO NhapHang VALUES
('NH00000001', '2025-01-05'),
('NH00000002', '2025-01-06'),
('NH00000003', '2025-01-07'),
('NH00000004', '2025-01-08'),
('NH00000005', '2025-01-09'),
('NH00000006', '2025-01-10'),
('NH00000007', '2025-01-11'),
('NH00000008', '2025-01-12'),
('NH00000009', '2025-01-13')
;

INSERT INTO ChiTietNhapHang VALUES
('NH00000001', 'T000000001', 100, 3000),
('NH00000002', 'T000000002', 200, 2000),
('NH00000003', 'T000000003', 150, 5000),
('NH00000004', 'T000000004', 300, 1500),
('NH00000005', 'T000000005', 80, 6000),
('NH00000006', 'T000000006', 60, 8000),
('NH00000007', 'T000000007', 90, 4000),
('NH00000008', 'T000000008', 50, 10000);

INSERT INTO ChiTietHoaDon VALUES
('HD00000001', 'T000000001', 2),
('HD00000002', 'T000000002', 3),
('HD00000003', 'T000000003', 1),
('HD00000004', 'T000000004', 5),
('HD00000005', 'T000000005', 2),
('HD00000006', 'T000000006', 1),
('HD00000007', 'T000000007', 4),
('HD00000008', 'T000000008', 2),
('HD00000009', 'T000000009', 1),
('HD00000010', 'T000000010', 3);
go
CREATE TRIGGER p_chiTietNhapHang_Thuoc
ON ChiTietNhapHang
AFTER INSERT
AS 
BEGIN
    SET NOCOUNT ON;
    UPDATE Thuoc
    SET soLuongTonKho = soLuongTonKho + i.soLuong
	from thuoc
    INNER JOIN INSERTED i ON i.maThuoc = Thuoc.maThuoc;
END;
go 
CREATE TRIGGER d_ChiTietNhapHang_NhapHang
ON ChiTietNhapHang
AFTER DELETE
AS 
BEGIN
    SET NOCOUNT ON;
    DELETE n
    FROM NhapHang n
		INNER JOIN DELETED d ON d.maNhapHang = n.maNhapHang;
	UPDATE Thuoc
    SET soLuongTonKho = soLuongTonKho - i.soLuong
	from thuoc
    INNER JOIN INSERTED i ON i.maThuoc = Thuoc.maThuoc;
END;











