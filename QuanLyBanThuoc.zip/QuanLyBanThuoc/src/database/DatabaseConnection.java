package database;

/**
 *
 * @author Cao Thi Han
 */
import java.io.File;
import java.net.URL;
import java.net.URLClassLoader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
    private static final String HOST = "localhost";
    private static final String PORT = "1433";
    private static final String DATABASE = "QUANLY_QUAYTHUOC";
    private static final String USERNAME = "chaut";
    private static final String PASSWORD = "10042005";

    private static final String DRIVER_CLASS = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
    private static final String DRIVER_PATH = "lib/mssql-jdbc-12.4.2.jre8.jar";

    private static Connection conn = null;

    public static Connection getConnection() throws SQLException {
        if (conn == null || conn.isClosed()) {
            loadJDBCDriver();
            conn = tryAllConnections();
        }
        return conn;
    }

    private static void loadJDBCDriver() {
        try {
            File driverFile = new File(DRIVER_PATH);
            if (driverFile.exists()) {
                URL[] urls = { driverFile.toURI().toURL() };
                URLClassLoader classLoader = new URLClassLoader(urls, DatabaseConnection.class.getClassLoader());
                Class.forName(DRIVER_CLASS, true, classLoader);
                System.out.println("Driver đã được tải từ: " + driverFile.getAbsolutePath());
            } else {
                Class.forName(DRIVER_CLASS);
                System.out.println("Driver SQL Server đã được nạp từ classpath.");
            }
        } catch (Exception e) {
            System.err.println("Không thể tải driver SQL Server: " + e.getMessage());
        }
    }

    private static Connection tryAllConnections() throws SQLException {
        String[] connectionStrings = {
            // 1. Dùng encrypt=true
            String.format("jdbc:sqlserver://%s:%s;databaseName=%s;encrypt=true;trustServerCertificate=true;user=%s;password=%s",
                          HOST, PORT, DATABASE, USERNAME, PASSWORD),

            // 2. Dùng encrypt=false
            String.format("jdbc:sqlserver://%s:%s;databaseName=%s;encrypt=false;user=%s;password=%s",
                          HOST, PORT, DATABASE, USERNAME, PASSWORD),

            // 3. Dùng instance name
            String.format("jdbc:sqlserver://%s;instanceName=MSSQLSERVER01;databaseName=%s;encrypt=true;trustServerCertificate=true;user=%s;password=%s",
                          HOST, DATABASE, USERNAME, PASSWORD),

            // 4. Dùng localhost\\SQLEXPRESS
            String.format("jdbc:sqlserver://localhost\\SQLEXPRESS;databaseName=%s;encrypt=true;trustServerCertificate=true;user=%s;password=%s",
                          DATABASE, USERNAME, PASSWORD),

            // 5. Dùng CAOTHIHAN\\MSSQLSERVER01
            String.format("jdbc:sqlserver://CAOTHIHAN\\MSSQLSERVER01;databaseName=%s;encrypt=true;trustServerCertificate=true;user=%s;password=%s",
                          DATABASE, USERNAME, PASSWORD),

            // 6. Integrated Security
            String.format("jdbc:sqlserver://CAOTHIHAN\\MSSQLSERVER01;databaseName=%s;integratedSecurity=true;encrypt=true;trustServerCertificate=true",
                          DATABASE)
        };

        SQLException lastException = null;
        for (String connStr : connectionStrings) {
            try {
                System.out.println("Thử kết nối: " + connStr);
                Connection connection = DriverManager.getConnection(connStr);
                System.out.println("Kết nối thành công!");
                return connection;
            } catch (SQLException e) {
                System.err.println("Thất bại: " + e.getMessage());
                lastException = e;
            }
        }

        throw lastException != null ? lastException : new SQLException("Không thể kết nối tới cơ sở dữ liệu.");
    }

    public static void closeConnection() {
        if (conn != null) {
            try {
                conn.close();
                System.out.println("Kết nối đã được đóng.");
            } catch (SQLException e) {
                System.err.println("Lỗi khi đóng kết nối: " + e.getMessage());
            }
        }
    }

    public static boolean testConnection() {
        try (Connection testConn = getConnection()) {
            return testConn != null && !testConn.isClosed();
        } catch (SQLException e) {
            System.err.println("Lỗi kiểm tra kết nối: " + e.getMessage());
            return false;
        }
    }
}