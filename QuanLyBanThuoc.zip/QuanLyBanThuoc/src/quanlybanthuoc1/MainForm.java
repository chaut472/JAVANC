/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package quanlybanthuoc1;

import entity.User;
import gui.ChiTietHoaDonGUI;
import gui.ChiTietNhapHangGUI;
import gui.DangNhapGUI;
import gui.HoaDonGUI;
import gui.KhachHangGUI;
import gui.NhaSanXuatGUI;
import gui.NhapHangGUI;
import gui.ThuocGUI;
import javax.swing.JFrame;
import javax.swing.JTabbedPane;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

/**
 *
 * @author Cao Thi Han
 */

public class MainForm extends JFrame {
    private User currentUser;
    private JTabbedPane tabbedPane;
    
    public MainForm() {
        initComponents();
        showLoginDialog();
    }
    
    private void initComponents() {
        setTitle("Quản lý bán thuốc");
        setSize(900, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        // Initialize tabbed pane
        tabbedPane = new JTabbedPane();
        add(tabbedPane);
    }
    
    private void showLoginDialog() {
        DangNhapGUI loginDialog = new DangNhapGUI(this);
        loginDialog.setVisible(true);

        if (loginDialog.isLoginSuccess()) {
            // Create a new User object and set its properties
            currentUser = new User();
            currentUser.setTenUser(loginDialog.getTenDangNhap());
            currentUser.setVaiTro(loginDialog.isAdmin() ? "ADMIN" : "USER");

            updateUI();
        } else {
            System.exit(0);
        }
    }

    private void updateUI() {
        setTitle("Quản lý bán thuốc - " + currentUser.getTenUser());
        tabbedPane.removeAll();

        if ("ADMIN".equalsIgnoreCase(currentUser.getVaiTro())) {
            tabbedPane.addTab("Chi Tiết Nhập Hàng", new ChiTietNhapHangGUI());
            tabbedPane.addTab("Chi Tiết Hoá Đơn", new ChiTietHoaDonGUI());
            tabbedPane.addTab("Hoá Đơn", new HoaDonGUI(currentUser));
            tabbedPane.addTab("Khách Hàng", new KhachHangGUI(currentUser));
            tabbedPane.addTab("Nhập Hàng", new NhapHangGUI());
            tabbedPane.addTab("Nhà Sản Xuất", new NhaSanXuatGUI());
            tabbedPane.addTab("Thuốc", new ThuocGUI(currentUser));
        } else {
            tabbedPane.addTab("Hoá Đơn", new HoaDonGUI(currentUser));
            tabbedPane.addTab("Thuốc", new ThuocGUI(currentUser));
        }

        revalidate();
        repaint();
    }

    private void showThuocGUI() {
        ThuocGUI thuocGUI = new ThuocGUI(currentUser);
        thuocGUI.setVisible(true);
    }

    private void showKhachHangGUI() {
        KhachHangGUI khachHangGUI = new KhachHangGUI(currentUser);
        khachHangGUI.setVisible(true);
    }

    private void showHoaDonGUI() {
        HoaDonGUI hoaDonGUI = new HoaDonGUI(currentUser);
        hoaDonGUI.setVisible(true);
    }
    private void showNhapHangGUI() {
        NhapHangGUI nhapHangGUI = new NhapHangGUI();
        nhapHangGUI.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new MainForm().setVisible(true);
            }
        });
    }
}