# Phần Mềm Quản Lý Bán Thuốc

## Hướng dẫn sử dụng giao diện và hệ thống styling

Phần mềm Quản Lý Bán Thuốc sử dụng hệ thống styling thống nhất thông qua lớp `GUIUtils`. Lớp này cung cấp các tiện ích để tạo giao diện người dùng nhất quán và đẹp mắt trong toàn bộ ứng dụng.

### Sử dụng GUIUtils trong form mới

Khi tạo form mới, hãy làm theo các bước sau để sử dụng hệ thống styling:

1. **Import lớp GUIUtils**:

   ```java
   import utils.GUIUtils;
   ```

2. **Khởi tạo hệ thống giao diện**:

   ```java
   GUIUtils.setupGUI();
   ```

3. **Sử dụng các thành phần đã được styling**:

   ```java
   // Tạo panel nền với gradient
   JPanel backgroundPanel = GUIUtils.createGradientPanel();

   // Tạo panel form với layout GridBagLayout
   JPanel formPanel = GUIUtils.createFormPanel();

   // Tạo panel nút với căn giữa
   JPanel buttonPanel = GUIUtils.createButtonPanel();

   // Tạo label tiêu đề
   JLabel titleLabel = GUIUtils.createTitleLabel("TÊN FORM");

   // Tạo label tiêu đề phụ
   JLabel subtitleLabel = GUIUtils.createSubtitleLabel("Tiêu đề phụ");

   // Tạo label cho trường nhập liệu
   JLabel fieldLabel = GUIUtils.createFormLabel("Tên trường:");
   ```

4. **Styling các thành phần giao diện**:

   ```java
   // Styling nút
   JButton primaryButton = new JButton("Lưu");
   GUIUtils.stylePrimaryButton(primaryButton);

   JButton dangerButton = new JButton("Xóa");
   GUIUtils.styleDangerButton(dangerButton);

   JButton warningButton = new JButton("Cảnh báo");
   GUIUtils.styleWarningButton(warningButton);

   // Styling trường nhập liệu
   JTextField textField = new JTextField();
   GUIUtils.styleTextField(textField);

   JPasswordField passwordField = new JPasswordField();
   GUIUtils.stylePasswordField(passwordField);

   JComboBox<String> comboBox = new JComboBox<>();
   GUIUtils.styleComboBox(comboBox);

   // Styling bảng
   JTable table = new JTable();
   GUIUtils.styleTable(table);
   ```

5. **Thêm trường vào form với GridBagLayout**:

   ```java
   GridBagConstraints gbc = new GridBagConstraints();
   gbc.fill = GridBagConstraints.HORIZONTAL;
   gbc.insets = new Insets(8, 10, 8, 10);

   JTextField txtName = new JTextField(20);
   GUIUtils.styleTextField(txtName);

   GUIUtils.addFormField(formPanel, "Tên:", txtName, gbc, 0); // row = 0
   ```

### Bảng màu và font

Hệ thống sử dụng bảng màu và font thống nhất:

- **Màu chính**: `GUIUtils.PRIMARY_COLOR` - Màu xanh dương đậm
- **Màu phụ**: `GUIUtils.SECONDARY_COLOR` - Màu xanh dương nhạt
- **Màu nhấn**: `GUIUtils.ACCENT_COLOR` - Màu xanh lá
- **Màu cảnh báo**: `GUIUtils.WARNING_COLOR` - Màu vàng
- **Màu nguy hiểm**: `GUIUtils.DANGER_COLOR` - Màu đỏ
- **Màu nền**: `GUIUtils.BACKGROUND_COLOR` - Màu xanh nhạt

- **Font tiêu đề**: `GUIUtils.TITLE_FONT` - Segoe UI, Bold, 24pt
- **Font tiêu đề phụ**: `GUIUtils.SUBTITLE_FONT` - Segoe UI, Bold, 18pt
- **Font nhãn**: `GUIUtils.LABEL_FONT` - Segoe UI, Bold, 14pt
- **Font nút**: `GUIUtils.BUTTON_FONT` - Segoe UI, Bold, 14pt
- **Font trường nhập liệu**: `GUIUtils.FIELD_FONT` - Segoe UI, Plain, 14pt

### Ví dụ về form hoàn chỉnh

```java
import javax.swing.*;
import java.awt.*;
import utils.GUIUtils;

public class ExampleForm extends JDialog {
    private JTextField txtName;
    private JButton btnSave;
    private JButton btnCancel;

    public ExampleForm(Frame parent) {
        super(parent, "Ví dụ Form", true);
        GUIUtils.setupGUI();
        initComponents();
    }

    private void initComponents() {
        setSize(500, 400);
        setLocationRelativeTo(getOwner());

        // Main panel
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBorder(BorderFactory.createEmptyBorder(GUIUtils.PADDING, GUIUtils.PADDING, GUIUtils.PADDING, GUIUtils.PADDING));

        // Title
        JLabel lblTitle = GUIUtils.createTitleLabel("FORM VÍ DỤ");
        JPanel titlePanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        titlePanel.setOpaque(false);
        titlePanel.add(lblTitle);

        // Form panel
        JPanel formPanel = GUIUtils.createFormPanel();
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(8, 10, 8, 10);

        txtName = new JTextField(20);
        GUIUtils.styleTextField(txtName);

        GUIUtils.addFormField(formPanel, "Tên:", txtName, gbc, 0);

        // Button panel
        JPanel buttonPanel = GUIUtils.createButtonPanel();

        btnSave = new JButton("Lưu");
        btnCancel = new JButton("Hủy");

        GUIUtils.stylePrimaryButton(btnSave);
        GUIUtils.styleDangerButton(btnCancel);

        buttonPanel.add(btnSave);
        buttonPanel.add(btnCancel);

        // Add panels to main panel
        mainPanel.add(titlePanel, BorderLayout.NORTH);
        mainPanel.add(formPanel, BorderLayout.CENTER);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        // Create gradient background
        JPanel backgroundPanel = GUIUtils.createGradientPanel();
        backgroundPanel.setLayout(new BorderLayout());
        backgroundPanel.add(mainPanel);

        // Add to frame
        add(backgroundPanel);
    }
}
```

### Chức năng nâng cao

Hệ thống styling `GUIUtils` được thiết kế để dễ dàng mở rộng. Bạn có thể thêm các phương thức mới vào lớp này để hỗ trợ styling cho các thành phần giao diện khác nếu cần thiết.
